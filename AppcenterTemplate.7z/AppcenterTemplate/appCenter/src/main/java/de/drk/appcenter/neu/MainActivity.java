package de.drk.appcenter.neu;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;

import de.drk.appcenter.neu.R;
import de.drk.appcenter.neu.Helper.DatabaseHelper;
import de.drk.appcenter.neu.Helper.DatabaseManager;
import de.drk.appcenter.neu.Helper.PluginButton;
import de.drk.appcenter.neu.Helper.RemoteDB;
import de.drk.appcenter.neu.Helper.RemoteToLocal;
import de.drk.template.neu.AppcenterTemplate;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentPagerAdapter;
import android.support.v4.view.ViewPager;
import android.text.Editable;
import android.text.InputType;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.Toast;
import android.widget.LinearLayout;


/** 
 * @mainpage Appcenter
 * 
 * @author Stefan Seifert 
 * 
 * Hinzugefuegt von Peter Ewert:	- ViewPager und Klasse AppSectionsPagerAdapter
 * 								- Klassen FirstLayer, SecondLayer und Thirdlayer
 * 								- Methoden setButtons und remotetolocalConfig
 * 								- TimerTask zur Synchronisation mit der Datenbank
 */ 

/**
 * @class MainActivity
 * @brief Dies ist die HauptActivity mit der die App startet
 * 
 * Hier werden alle weiteren Activities aufgerufen. Auf der linken Seite sind alle 
 * Button mit Icon augelistet und oeffnen bei Druck die entsprechende Activity. Auf der rechten Seite befinden sich 4 Button.
 * Der Button mit dem Haus bringt uns immer wieder auf diese HauptActivity zurueck.
 * Der Zurueckbutton laesst uns immer eine Activity zurueckblaettern. Der Suchbutton, oeffnet eine Activity, in der eine Suche
 * ausgeloest werden kann, welche auf Google.de statt findet.
 */

public class MainActivity extends AppcenterTemplate {									//erbt wie die Plugins vom Template "AppcenterTemplate"

	private final int[] FIRST_POS = {10,20,30};											//erster Positions-Wert auf den drei Startseiten
	private final int PAGE_ROWS = 2;													//Zeilen pro Seite
	private final int BUTTONS_PER_ROW = 4;												//Buttons pro Zeile
	
	private final String SERVER_IP = "http://212.100.43.180";
	private final String SERVER_PLUGIN_DIR = "http://212.100.43.180/appcenterPluginsNeu/";
	
	private DatabaseHelper db = new DatabaseHelper(this);
	private RemoteToLocal remoteToLocal = new RemoteToLocal(this);

	private boolean threadstarted=false;

	private static Timer timer;
	
    private FPAdapter fpAdapter;
    private ViewPager mViewPager;
    
    private static Context context;

    private static View rootViewFirstPage;
    private static View rootViewSecondPage;
    private static View rootViewThirdPage;
    
    private long[] downloadId;
    private DownloadManager downloadManager;
    private BroadcastReceiver downloadReceiver;
    
    private List<RemoteToLocal.PluginData> pluginDataInstall = new ArrayList<RemoteToLocal.PluginData>();
    private List<RemoteToLocal.PluginData> pluginDataUninstall = new ArrayList<RemoteToLocal.PluginData>();
    
    private int buttonSize,
				textSize;
    
    AlertDialog alertDialog;
	
	////////////////////////////////////////////////////////////////////////////////////
	//Methode, die nach Erstellung der Activity aufgerufen wird.
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setLayout(R.layout.activity_main);												//Layout des Haupt-Fensters mithilfe der Methode von "AppcenterTemplate" setzen
		
		clientPreset();
		
		context = this;
		
		setBroadcastReceiver();															//definieren des Broadcast-Receivers
		
		getSize();																		//Groesse der Buttons berechnen
		buildPageLayouts();																//Layout und Buttons auf den einzelnen Seiten setzen
				
        fpAdapter = new FPAdapter(getSupportFragmentManager());							//wird fuer die Erstellung der Seiten, die der ViewPager anzeigt, benoetigt

        mViewPager = (ViewPager)findViewById(R.id.pager);								//ViewPager, der in der Layout-XML gesetzt wurde, holen
        mViewPager.setAdapter(fpAdapter);												//mPagerAdapter als Adapter, der dem ViewPager die anzuzeigenden Seiten uebergibt, festlegen
        mViewPager.setOffscreenPageLimit(2);											//sorgt dafuer, dass die gerade nicht angezeigten Seiten erhalten bleiben und somit nicht neu geladen werden muessen
	}
	
	public void clientPreset(){
		final SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(
				"standard", MODE_PRIVATE);
		int clientId = sharedPreferences.getInt("ClientId", 0);
		if(clientId == 0){
			
			Thread thread = new Thread()
			{
				@Override
				public void run() {
					runOnUiThread(new Runnable() {
					  public void run() {
						
						  final AlertDialog.Builder alert = new AlertDialog.Builder(context);
						  
							alert.setTitle("Identifikationsnummer");
							alert.setMessage("Bitte geben Sie die ID des Patienten ein.");
		
							// Set an EditText view to get user input 
							final EditText input = new EditText(context);
							input.setInputType(InputType.TYPE_CLASS_NUMBER);
							alert.setView(input);
		
							alert.setPositiveButton("Ok", new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog, int whichButton) {
							  Editable value = input.getText();
								Editor editor = sharedPreferences.edit();
								editor.putInt("ClientId", Integer.parseInt(value.toString()));
								Log.d("", "ClientId = " + Integer.parseInt(value.toString()));
								editor.commit();
							  }
							});
		
							alert.setNegativeButton("Abbrechen", new DialogInterface.OnClickListener() {
							  public void onClick(DialogInterface dialog, int whichButton) {
							    // Canceled.
							  }
							});
							alertDialog = alert.create();
						  alertDialog.show();
					  }
					});
				}
			};

			thread.start();
			try {
				thread.join();															//warten, bis der Thread durchgelaufen ist
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		//sync();																			//beim Start eine Synchronisation mit der Server-Datenbank durchfuehren
	}
	
	/**
	 * @brief Methode zum Ausfuehren der Button-Action
	 * 
	 *        Der gedrueckte Button wird mit einer switch-case Anweisung
	 *        abgefragt und der entsprechende Code wird ausgefuehrt.
	 */

	public void onButtonClick(View view) {
		switch (view.getId()) {
		case (R.id.searchButton):			
			final SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(
					"standard", MODE_PRIVATE);
			int clientId = sharedPreferences.getInt("ClientId", 0);
			Intent intent = new Intent();
			intent.putExtra("clientId", clientId);
			intent.setAction("android.intent.action.SEARCH_APPCENTER_NEU");
			finish();
			startActivity(intent);
			overridePendingTransition(0, 0);
			break;
		case (R.id.backButton):
			System.exit(0);
			break;
		default:
			super.onButtonClick(view);
			break;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//FirstPage ist das Fragment, das die erste Seite darstellt.
	////////////////////////////////////////////////////////////////////////////////////
	public static class FirstPage extends Fragment implements OnClickListener{

    	int count = 0;
    	
    	@Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {
      
            FrameLayout hButton = (FrameLayout)rootViewFirstPage.						//definieren eines unsichtbaren Buttons unten rechts auf der ersten Seite
            		findViewById(R.id.frame8E1);
            hButton.setOnClickListener(this);
            
    		return rootViewFirstPage;    												//gibt das Layout der Seite zurueck
    	}

    	@Override
    	public void onClick(View v) {
    		if(v.getId() == R.id.frame8E1){
				if(count < 3){
					count++;
				}
				else{																	//wenn vier mal auf den unsichtbaren Button geklickt wurde
					timer.cancel();														//Timer beenden
					count = 0;
					if(installed("de.drk.plugin.settings.neu")){							//wenn das Plugin "Einstellungen" installiert ist
						Intent intent = new Intent();
						intent.setClassName("de.drk.plugin.settings.neu",
								"de.drk.plugin.settings.neu.MainActivity");
						startActivity(intent);
						getActivity().overridePendingTransition(0, 0);					//"Einstellungen" starten
					}
				}
    		}
    	}
    }
	
	////////////////////////////////////////////////////////////////////////////////////
	//SecondPage ist das Fragment, das die zweite Seite darstellt.
	////////////////////////////////////////////////////////////////////////////////////
    public static class SecondPage extends Fragment{
    	
    	@Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {

    		return rootViewSecondPage;            
    	}
    }
    
	////////////////////////////////////////////////////////////////////////////////////
	//ThirdPage ist das Fragment, das die dritte Seite darstellt.
	////////////////////////////////////////////////////////////////////////////////////
    public static class ThirdPage extends Fragment{

    	@Override
        public View onCreateView(LayoutInflater inflater, ViewGroup container,
                Bundle savedInstanceState) {

    		return rootViewThirdPage; 
    	}
    }
    
	////////////////////////////////////////////////////////////////////////////////////
	//Erstellt die Layouts der einzelnen Seiten und fuegt die Buttons in das Layout.
	////////////////////////////////////////////////////////////////////////////////////
	public void buildPageLayouts(){
		LayoutInflater inflater = LayoutInflater.from(this);
		
		rootViewFirstPage = inflater.inflate(R.layout.fragment_main, null);				//jeder Seite (Fragment) wird dasselbe Layout zugewiesen
		rootViewSecondPage = inflater.inflate(R.layout.fragment_main, null);
		rootViewThirdPage = inflater.inflate(R.layout.fragment_main, null);
		
		placeButtons(rootViewFirstPage, 0, this);										//Aufruf der Methode setButtons zum Positionieren der Buttons
		placeButtons(rootViewSecondPage, 1, this);
		placeButtons(rootViewThirdPage, 2, this);
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//getSize bestimmt die Groesse der ImageButtons und TextViews abhaengig von den 
	//Bilschirmeigenschaften
	////////////////////////////////////////////////////////////////////////////////////
	public void getSize(){
		int screenWidth;
		int scaledDensity;
		
		screenWidth = this.getResources().getDisplayMetrics().widthPixels;				//Ermitteln der Bildschirmeigenschaften
		scaledDensity = (int) this.getResources().getDisplayMetrics().scaledDensity;
		
		buttonSize = screenWidth/6;														//Groesse von ImageButton und TextView berechnen 
		textSize = (screenWidth/37)/scaledDensity;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//setButtons positioniert die Buttons der Plugins auf der uebergebenen Seite an der
	//in der lokalen Datenbank gespeicherten Position
	////////////////////////////////////////////////////////////////////////////////////
    public void placeButtons(View rootView, int page, final Context context) {
		
    	PluginButton button = new PluginButton(context);
    	
    	int[] pluginId = null;
		String[] pluginPackageName = null;
		int[] pluginPosition = null;
		
		pluginId = db.getPluginId();
		pluginPackageName = db.getPluginPackageName();
		pluginPosition = db.getPluginPosition();
    	
        LinearLayout ll;
        FrameLayout flButton;
        
        for(int j=0; j<db.getPluginId().length; j++){
			if(pluginPosition[j] >= FIRST_POS[page] && 										//untersuchen, ob die Position der Seite "page" angehoert
					pluginPosition[j] < FIRST_POS[page]+(PAGE_ROWS*BUTTONS_PER_ROW)){
				try{
					flButton = button.createButtonFromPlugin(pluginPackageName[j],			//Erstellen eines FrameLayout-Buttons mithilfe der Klasse PluginButton
							pluginId[j], buttonSize, textSize);
					
					if(db.getPluginPosition()[j]%10 < 4){									//wenn der Button in der ersten Zeile der Seite positioniert werden soll
						ll = (LinearLayout)rootView.findViewById(R.id.row1);				//LinearLayout, das die erste Zeile der Seite darstellt
						FrameLayout fr = (FrameLayout) ll.getChildAt(pluginPosition[j]%10);	//FrameLayout finden, das an der entsprechenden Stelle liegt (%10 streicht die Zehnerstelle -> aus 27 wird z.B. 7)
	
					    fr.removeAllViews();
					    fr.addView(flButton);												//Button zum FrameLayout hinzufuegen
					}
					else{
						ll = (LinearLayout)rootView.findViewById(R.id.row2);				//zweite Zeile der Seite
						FrameLayout fr = (FrameLayout) ll.getChildAt(pluginPosition[j]%10-4);//hier muss -4 gerechnet werden, da man die Positionen in der Zeile von 0 bis 3 gehen
	
						fr.removeAllViews();
						fr.addView(flButton);
					}
	
					final String currentPluginName = pluginPackageName[j];
					
					flButton.setOnClickListener(new OnClickListener() {						//onClick-Listener setzen 
			            public void onClick(View v) {
			            	timer.cancel();													//Timer beenden
		            		Intent intent = new Intent();
			                intent.setClassName(currentPluginName, currentPluginName + 
			                		".MainActivity");
			                SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(
			        				"standard", MODE_PRIVATE);
			        		int clientId = sharedPreferences.getInt("ClientId", 0);
			        		Log.d("", "clientID: " + clientId);
			                intent.putExtra("clientId", (int)clientId);
			                intent.putExtra("firstStart", 1);
							context.startActivity(intent);									//Activity, auf deren Button geklickt wurde, starten
							((Activity) context).overridePendingTransition(0,0);			
			            }  
			        });
				} catch(Exception e) {
					Log.d("package_not_found", "Das Paket " + pluginPackageName[j] +		//Logging-Message ausgeben, wenn das Paket auf dem Geraet nicht gefunden wurde
						" konnte nicht gefunden werden.");
				}
				
			}
		}
	}
    
	////////////////////////////////////////////////////////////////////////////////////
	//Die Klasse FPAdapter erbt von FragmentPagerAdapter und ist dafuer zustaendig, den
	//ViewPager mit den einzelnen Seiten zu versorgen.
	////////////////////////////////////////////////////////////////////////////////////
	public static class FPAdapter extends FragmentPagerAdapter {

        public FPAdapter(FragmentManager fm) {
            super(fm);
        }

        @Override
        public Fragment getItem(int i) {												//gibt je nach uebergebenem Parameter eine der drei Seiten zurueck
            switch (i) {
                case 0:
                    return new FirstPage();
                case 1:
                	return new SecondPage();
                case 2:
                	return new ThirdPage();
                default:
                	return null;
            }
        }

        @Override
        public int getCount() {															//gibt die Gesamtzahl der Seiten zurueck
            return 3;
        }
    }
	
	////////////////////////////////////////////////////////////////////////////////////
	//Setzt den TimerTask und erstellt einen Timer, der den TimerTask alle 10 Sekunden
    //ausfuehrt.
	////////////////////////////////////////////////////////////////////////////////////
	public void setTimerTask(){
		if(timer != null){
			timer.cancel();
		}
		TimerTask syncTask = new TimerTask() {
	        public void run() {		
				sync();																	//aufruf der Methode sync() zum Abgleich der lokalen Datenbank mit der Server-Datenbank
	        }
	    };
	    timer = new Timer();
	    timer.schedule(syncTask, 0, 10000); 
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Methode zum Synchronisieren von Server-Datenbank und lokaler Datenbank
	////////////////////////////////////////////////////////////////////////////////////
	private void sync(){
		
		SharedPreferences sharedPreferences = getApplicationContext().
				getSharedPreferences("standard", MODE_PRIVATE);
		final int clientId = sharedPreferences.getInt("ClientId", 0);
		
		if(clientId != 0){
			
			Thread thread = new Thread()
			{
				@Override
				public void run() {
		
					if(isServerReachable()){
						savePreferences("timelastsync",
								String.valueOf(System.currentTimeMillis()));
						boolean serverConfigChanged = RemoteDB.checkConfigChanges(clientId, "Plugin");		//ueberpruefen, ob sich die Plugin-Konfigurations-Daten in der Server-Datenbank geaendert haben
						Log.d("", "sync");
						Log.d("", "clientId: " +clientId);
						if(serverConfigChanged){											//wenn die Daten geaendert wurden			
							//remoteToLocal.dataSync();
							RemoteDB.setChangeFlag(clientId,"Plugin",0);
							remotetolocalConfig(clientId);									//Konfigurations-Daten in die lokale Datenbank laden									
							if(pluginDataInstall.size() == 0 && 							//wenn kein Plugin installiert oder deinstalliert werden muss
									pluginDataUninstall.size() == 0){
								if(timer != null){
									timer.cancel();											//Timer beenden
								}
								runOnUiThread(new Runnable(){
									@Override
									public void run(){
										Log.d("", "Activity wurde neu gestartet (in sync())");
										recreate();											//Activity neu starten
									}
								});
							}
						}
					}
					else{
						Log.d("Serververbindung", "Server ist nicht erreichbar.");
					}
					threadstarted=false;
				}
			};
			if(!threadstarted){
				threadstarted=true;
				thread.start();
				try {
					thread.join();															//warten, bis der Thread durchgelaufen ist
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode startet die Anpassung der lokalen Konfiguration an die Konfiguration
	//auf dem Server.
	////////////////////////////////////////////////////////////////////////////////////
	private void remotetolocalConfig(int clientId) {
		
		List<List<RemoteToLocal.PluginData>> changedPlugins = remoteToLocal.		//Aufruf der Methode pluginTabelDifferences() der Klasse RemoteToLocal
				pluginTableDifferences(clientId);									//gibt eine zwei-dimensionale List mit den Daten der Plugins, die installiert/deinstalliert werden muessen, zurueck

		pluginDataInstall = changedPlugins.get(0);
		pluginDataUninstall = changedPlugins.get(1);
		
		for(int i=0; i<pluginDataInstall.size(); i++){
			Log.d("", pluginDataInstall.get(i).getPluginName());
		}
		
		if(pluginDataInstall.size()!=0){
			startDownload();														//starten des Downloads der zu installierenden Plugins
			Log.d("", "Es sind Daten zum Installieren vorhanden");
		}
		else if(pluginDataUninstall.size()!=0){										//wenn keine Plugins installiert werden muessen (sonst wird die Deinstallation in der Methode install() gestartet)
			uninstall(pluginDataUninstall);											// Deinstallation der zu deinstallierenden Plugins starten
			Log.d("", "Es sind Daten zum Deinstallieren vorhanden");
		}

	}

	private void savePreferences(String key, String value) {
		SharedPreferences sharedPreferences = getApplicationContext().
				getSharedPreferences("standard", MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.putString(key, value);
		editor.commit();
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Methode zum Starten der Downloads der als List uebergebenen apk-Dateien
	////////////////////////////////////////////////////////////////////////////////////
	public void startDownload(){
		registerReceiver(downloadReceiver, 												//Anmelden des Download-Broadcast-Receivers
				new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
		downloadId = new long[pluginDataInstall.size()];								//Array zum Hinterlegen der DownloadIds
		downloadManager = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);	//Instanz des Android-DownloadManagers erstellen
		for(int i=0; i<pluginDataInstall.size(); i++){
			String url = SERVER_PLUGIN_DIR + 									//Pfad zur Datei, die heruntergeladen werden soll
					pluginDataInstall.get(i).getPluginApk();	
			Uri uri = Uri.parse(url);												//Uri erstellen
			DownloadManager.Request request = new DownloadManager.Request(uri);		//Request fuer die Uri erstellen
			request.setDestinationInExternalPublicDir(								//Downloadverzeichnis bestimmen
					Environment.DIRECTORY_DOWNLOADS,
					pluginDataInstall.get(i).getPluginApk());						
			downloadId[i] = downloadManager.enqueue(request);							//Download in die Warteschlange stellen. Wird dann automatisch gestartet. Die zurueckgegebene ID im Array downloadId speichern.
		}		
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode setzt den BroadcastReceiver, der dafuer zustaendig ist den Status der 
    //Downloads zu ermitteln
	////////////////////////////////////////////////////////////////////////////////////
    private void setBroadcastReceiver(){
    	downloadReceiver = new BroadcastReceiver() {
    		private int downloadCounter = 0;											//Counter fuer das Zaehlen der erfolgreich beendeten Downloads
    		private List<Uri> apkUri = new ArrayList<Uri>();							//List in der die Pfade der Downloads gespeichert werden
			@Override
			public void onReceive(Context context, Intent intent){
				long id = intent.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1);
				for(int i=0; i<downloadId.length; i++){
					if(downloadId != null){
						if(id == downloadId[i]){
							DownloadManager.Query query = new DownloadManager.Query();			
							query.setFilterById(downloadId[i]);									//Herausfiltern der Downloads mit den Download-IDs des Arrays downloadId
							Cursor cursor = downloadManager.query(query);
							cursor.moveToFirst();												//ersten der gefilteren Downloads auswaehlen 
							
							int columnIndex = cursor.getColumnIndex(DownloadManager.			//ermitteln des Download-Status
									COLUMN_STATUS);
							int status = cursor.getInt(columnIndex);
							
							int fileNameIndex = cursor.getColumnIndex(DownloadManager.			//ermitteln des Pfads der heruntergeladenen Datei
									COLUMN_LOCAL_FILENAME);
							String savedFilePath = cursor.getString(fileNameIndex);
							
							int columnReason = cursor.getColumnIndex(DownloadManager.			//ermitteln der detaillierten Angaben zum Status bei STATUS_FAILED oder STATUS_PAUSED
									COLUMN_REASON);
							int reason = cursor.getInt(columnReason);
							
							switch (status){
							case DownloadManager.STATUS_FAILED:									//wenn der Download fehlgeschlagen ist
								Toast.makeText(context,
										"Datei konnte nicht geladen werden",
										Toast.LENGTH_SHORT).show();
								Log.d("", "Download-Fehler: " + reason);						//Fehler im Logging ausgeben
							case DownloadManager.STATUS_SUCCESSFUL:								//wenn der Download beendet wurde
								downloadCounter++;							
								Uri apk_install = Uri.fromFile(new File(savedFilePath));		//Download-Pfad
								Log.d("", savedFilePath);
								apkUri.add(apk_install);
								Log.d("", "DownloadCounter: " + downloadCounter);
								Log.d("", "DownloadId.length: " + downloadId.length);
								if(downloadCounter == downloadId.length)						//wenn alle Downloads erfolgreich beendet wurden
									install(apkUri);											//Installations-Methode aufrufen
							}
						}
					}
				}
			}
		};
    }
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode startet die Installation der heruntergeladenen Plugins und danach 
    //die Deinstallation der ausgewaehlten Plugins
	////////////////////////////////////////////////////////////////////////////////////
    private void install(List<Uri> apkUri){
    	unregisterReceiver(downloadReceiver);											//Download-Broadcast-Receiver abmelden
		Intent installIntent = new Intent(Intent.ACTION_VIEW);
		for(int i=0; i<apkUri.size(); i++){
			installIntent.setDataAndType(apkUri.get(i),									//dem Installations-Intent den Pfad der apk-Datei und den Typ uebergeben 
					"application/vnd.android.package-archive");
			startActivityForResult(installIntent, i);									//Install-Intent starten. Bei dessen Beendigung wird die Methode onActivityResult() aufgerufen, der der Wert i uebergeben wird.
		}
		uninstall(pluginDataUninstall);													//Deinstallations-Methode aufrufen
	}
    
	////////////////////////////////////////////////////////////////////////////////////
	//Methode, in der die Deinstallation der Plugins, deren Daten uebergeben werden 
	//gestartet wird.
	////////////////////////////////////////////////////////////////////////////////////
	public void uninstall(List<RemoteToLocal.PluginData> pluginData){
		for(int i=0; i<pluginData.size(); i++){
			if(installed(pluginData.get(i).getPluginPackageName())){
				Uri packageURI = Uri.parse("package:"+
						pluginData.get(i).getPluginPackageName());						//http://stackoverflow.com/questions/10483493/delete-my-application-programmatically-android
				Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI);
				startActivityForResult(uninstallIntent, i+1000);						//Starten der Deinstallation. Danach wird die Methode onActivityResult() aufgerufen. Dieser wird der Wert i+1000 uebergeben.
			}
			else{
				db.deletePlugin(pluginDataUninstall.get(i).getPluginId());
			}
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Wird nach Beendigung eines Intents aufgerufen, der mit startActivityForResult()
	//aufgerufen wurde.
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode >= 0 && requestCode < 1000) {									//wenn der beendete Intent eine Installation war
			Log.d("", "Package-Name: " + pluginDataInstall.get(requestCode).getPluginPackageName() + installed(pluginDataInstall.get(requestCode).getPluginPackageName()));
	    	if(installed(pluginDataInstall.get(requestCode).getPluginPackageName())){	//wenn das Plugin erfolgreich installiert wurde
	    		db.addPlugin(pluginDataInstall.get(requestCode).getPluginId(),			//hinzufuegen des Plugins zur lokalen Datenbank
	    			pluginDataInstall.get(requestCode).getPluginName(), 
	    			pluginDataInstall.get(requestCode).getPluginPackageName(), 
	    			pluginDataInstall.get(requestCode).getPluginPosition());
	    	}
	    	timer.cancel();																//Timer beenden
			recreate();																	//Activity neu starten
			Log.d("", "Activity wurde neu gestartet (in onActivityResult() istall)");
		}
	    else if (requestCode >= 1000){													//wenn der beendete Intent eine Deinstallation war
	    	if(!installed(pluginDataUninstall.get(requestCode-1000).					//wenn das Plugin erfolgreich deinstalliert wurde
	    			getPluginPackageName())){
	    		db.deletePlugin(pluginDataUninstall.get(requestCode-1000).getPluginId());//Plugin aus der lokalen Datenbank loeschen
	    	}
	    	Log.d("", "PluginDataInstall: " + pluginDataInstall.size());
	    	if(pluginDataInstall.size()==0){											//wenn kein Plugin zur Installation ausgewaehlt war
		    	timer.cancel();															//Timer beenden
				recreate();																//Activity neu starten
				Log.d("", "Activity wurde neu gestartet (in onActivityResult() unistall)");
	    	}
	    }
	}
    
	/**
	 * @brief Pruefen, ob eine Netzwerkverbindung vorhanden ist.
	 * 
	 * Gibt einen boolean Wert wieder, ob eine Verbindung zum Internet besteht.
	 * 
	 */
	public boolean isServerReachable() {
		ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnected()) {
			try {
				URL url = new URL(SERVER_IP);   
				HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
				urlc.setConnectTimeout(10 * 1000);          
				urlc.connect();
				if (urlc.getResponseCode() == 200) {        
					return true;
				} else {
					return false;
				}
			} catch (MalformedURLException e1) {
				return false;
			} catch (IOException e) {
				return false;
			}
		}
		return false;
	}	
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode untersucht, ob ein Plugin mit dem uebergebenen Package-Namen
	//instaliert ist und gibt dementsprechend true oder false zurueck.
	////////////////////////////////////////////////////////////////////////////////////
	private static boolean installed(String pluginPackageName){
		PackageManager pm = context.getPackageManager();
		try {
			pm.getPackageInfo(pluginPackageName, PackageManager.GET_ACTIVITIES);
			return true;
		} catch (NameNotFoundException e) {
			return false;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Wird automatisch aufgerufen, wenn die diese App sichtbar wird
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void onStart(){																
		super.onStart();
		setTimerTask(); 																//Erstellung des Timer-Tasks
	}
}
