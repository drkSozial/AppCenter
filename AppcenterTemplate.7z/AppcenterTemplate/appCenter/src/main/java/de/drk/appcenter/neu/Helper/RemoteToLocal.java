package de.drk.appcenter.neu.Helper;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.content.Context;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;

public class RemoteToLocal {
	
	private Context context;
	
	DatabaseHelper db;
	
	/*private JSONArray doc = null;
	private JSONArray values = null;
	private JSONArray bookmarks = null;
	private JSONArray calendar = null;
	private JSONArray pills = null;
	private JSONArray carer = null;*/
	
	public RemoteToLocal(Context context){
		this.context = context;
		this.db = new DatabaseHelper(context);
	}
	
	/**
	 * @brief Daten von dem Remote Server empfangen
	 * 
	 * Diese Methode holt sich ein JSON Objekt mit allen Daten, reinigt die Daten aus der Datenbank und spielt die aktuellen rein.
	 */
	/*public void dataSync() {
		db.resetDatabaseBookmarks();
		//db.resetDatabasePills();
		//db.deleteRemoteEvents();
		//db.deleteDocs();
		//db.deleteCarer();

		//JSON Objekt von einer URL holen
		JSONObject json = RemoteDB.getData();

		//Nun alle Daten rausziehen und in der lokalen Datenbank speichern
		try {		

			//doc = json.getJSONArray("doc");
			bookmarks = json.getJSONArray("bookmark");
			values = json.getJSONArray("value");
			//calendar = json.getJSONArray("calendar");
			pills = json.getJSONArray("pills");
			//carer = json.getJSONArray("carer");

			for(int i = 0; i < pills.length(); i++){
				JSONObject c = pills.getJSONObject(i);
				String name = c.getString("name");
				String weekday = c.getString("weekday");
				String repeat = c.getString("repeat");
				db.addPills(name, weekday, repeat);

			}

			for(int i = 0; i < doc.length(); i++){
				JSONObject c = doc.getJSONObject(i);
				String forename = c.getString("forename");
				String surname = c.getString("surname");
				String phone = c.getString("phone");
				db.addDoc(forename, surname, phone);

			}

			for(int i = 0; i < carer.length(); i++){
				JSONObject c = carer.getJSONObject(i);
				String forename = c.getString("forename");
				String surname = c.getString("surname");
				String phone = c.getString("phone");
				db.addCarer(forename, surname, phone);
			}

			for(int i = 0; i < bookmarks.length(); i++){
				JSONObject c = bookmarks.getJSONObject(i);
				String title = c.getString("title");
				String url = c.getString("url");
				db.addBookmark(title, url);
			}
			for(int i = 0; i < calendar.length(); i++){
				JSONObject c = calendar.getJSONObject(i);
				String caltitle = c.getString("title");
				String alarm = c.getString("alarm");
				String dtstart = c.getString("dtstart");
				String calcolor = c.getString("colorTextview");
				db.addEvent(caltitle, alarm, dtstart, calcolor, "1");
			}

			for(int i = 0; i < values.length(); i++){

				if(i==1){
					JSONObject c = values.getJSONObject(i);
					db.setBookmarkSet(c.getString("value"));
				}else if(i==2){
					JSONObject c = values.getJSONObject(i);
					db.setAlarmTime(c.getString("value"));
				}
			}
		} catch (JSONException e) {
			e.printStackTrace();
		}
	}*/
	////////////////////////////////////////////////////////////////////////////////////
	//Klasse, deren Objekt Daten eines Plugins enthaelt
	////////////////////////////////////////////////////////////////////////////////////
	public static class PluginData {
		
		private int pluginId;
		private String pluginName;
		private String pluginPackageName;
		private String pluginApk;
		private int pluginPosition;
		
		public PluginData(int id, String name, String packageName, 						//Konstruktor fuer das Anlegen eines Plugin-Datensatzes fuer die Installation
				String pluginApk, int position){
			this.pluginId = id;
			this.pluginName = name;
			this.pluginPackageName = packageName;
			this.pluginApk = pluginApk;
			this.pluginPosition = position;
		}
		
		public PluginData(int id, String packageName){									//Konstruktor fuer das Anlegen eines Plugin-Datensatzes fuer die Deinstallation			
			this.pluginId = id;
			this.pluginPackageName = packageName;
		}

		public int getPluginId() {
			return pluginId;
		}

		public void setPluginId(int pluginId) {
			this.pluginId = pluginId;
		}

		public String getPluginName() {
			return pluginName;
		}

		public void setPluginName(String pluginName) {
			this.pluginName = pluginName;
		}

		public String getPluginPackageName() {
			return pluginPackageName;
		}

		public void setPluginPackageName(String pluginPackageName) {
			this.pluginPackageName = pluginPackageName;
		}

		public String getPluginApk() {
			return pluginApk;
		}

		public void setPluginApk(String pluginApk) {
			this.pluginApk = pluginApk;
		}

		public int getPluginPosition() {
			return pluginPosition;
		}

		public void setPluginPosition(int pluginPosition) {
			this.pluginPosition = pluginPosition;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode untersucht die lokale Datenbank des Plugins und die Server-Datenbank
	//auf Unterschiede in der Plugin-Konfiguration des Patienten.
	//Gibt eine zwei-dimensionale List mit den Daten der zu installierenden und zu
	//deinstallierenden Plugins zurueck.
	////////////////////////////////////////////////////////////////////////////////////
	public List<List<PluginData>> pluginTableDifferences(int clientId){
		
		JSONArray plugins = RemoteDB.getUserPlugins(clientId);							//Plugin-Daten des Patienten aus der Server-Datenbank holen
		List<PluginData> install = new ArrayList<PluginData>();							//List fuer die Daten der zu installierenden Plugins	
		List<PluginData> uninstall = new ArrayList<PluginData>();						//List fuer die Daetn der zu deinstallierenden Plugins
		
		List<List<PluginData>> changedPlugins = new ArrayList<List<PluginData>>(2);							
		
		int pluginId = 0;
		String pluginName = null;
		String pluginPackageName = null;
		int pluginPosition = 0;
		String pluginApk = null;
		
		List<String> pluginPackageRemoteDB = new ArrayList<String>();
		
		if(plugins!=null){
			for(int i = 0; i < plugins.length(); i++){									//Plugin-Daten des Patienten, die in der Server-Datenbank gespeichert sind, durchlaufen 
				try {
					JSONObject c = plugins.getJSONObject(i);
					pluginPackageRemoteDB.add(c.getString("PACKAGENAME"));
					pluginId = c.getInt("PLUGIN_ID");
					pluginName = c.getString("NAME");
					pluginPackageName = c.getString("PACKAGENAME");
					pluginPosition = c.getInt("POSITION");
					pluginApk = c.getString("APK");
				} catch (JSONException e) {
					e.printStackTrace();
				}
				if(db.pluginIdExists(pluginId)){										//wenn das Plugin in der lokalen Datenbank existiert
					db.updatePluginPosition(pluginId, pluginPosition);					//Position des Plugins aktualisieren
				}
				else{																	//wenn das Plugin nicht in der lokalen Datenbank existiert
					if(installed(pluginPackageName)){									//wenn das Plugin schon installiert ist
			    		db.addPlugin(pluginId,pluginName,pluginPackageName,pluginPosition);	//hinzufuegen des Plugins zur lokalen Datenbank			
					}
					else{
						PluginData pluginData = new PluginData(pluginId,pluginName,		//neuen Plugin-Datensatz fuer die Installation erstellen
								pluginPackageName,pluginApk,pluginPosition);
						install.add(pluginData);										//Plugin-Datensatz zu der List mit den zu installierenden Plugins hinzufuegen
					}
				}
			}
			String[] pluginPackageLocalDB = db.getPluginPackageName();
			int[] pluginIdLocalDB = db.getPluginId();
			for(int i=0; i<pluginPackageLocalDB.length; i++){							//Package-namen der in der lokalen Datenbank gespeicherten Plugins durchlaufen
				if(!pluginPackageRemoteDB.contains(pluginPackageLocalDB[i])){			//wenn der Package-Name nicht in der Server-Datenbank vorhanden ist
					PluginData pluginData = new PluginData(pluginIdLocalDB[i],			//neuen Plugin-Datensatz fuer die Deinstallation erstellen
							pluginPackageLocalDB[i]);
					uninstall.add(pluginData);											//Plugin-Datensatz zu der List mit den zu deinstallierenden Plugins hinzufuegen
				}
			}
		}
		else{																			//wenn in der Server-Datenbank fuer diesen Patienten keine Plugins gespeichert sind
			for(int i=0;i<db.getPluginId().length;i++){									//alle Plugin-Daten der lokalen Datenbank zur Deinstallations-List hinzufuegen
				PluginData pluginData = new PluginData(db.getPluginId()[i],
						db.getPluginPackageName()[i]);
				uninstall.add(pluginData);												
			}
		}
		changedPlugins.add(install);													//Installations-List zur zwei-dimensionalen List hinzufuegen
		changedPlugins.add(uninstall);													//Deinstallations-List zur zwei-dimensionalen List hinzufuegen
		
		return changedPlugins;											
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode untersucht, ob ein Plugin mit dem uebergebenen Package-Namen
	//instaliert ist und gibt dementsprechend true oder false zurueck.
	////////////////////////////////////////////////////////////////////////////////////
	private boolean installed(String pluginPackageName){
		PackageManager pm = context.getPackageManager();
		try {
			pm.getPackageInfo(pluginPackageName, PackageManager.GET_ACTIVITIES);
			return true;
		} catch (NameNotFoundException e) {
			return false;
		}
	}
}
