package de.drk.appcenter.neu;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.drk.appcenter.neu.Helper.DatabaseHelper;
import de.drk.appcenter.neu.Helper.DatabaseManager;
import de.drk.template.neu.AppcenterTemplate;

/**
 * @class Search
 *
 * @brief Eine Suchfunktion f&uuml;r Plugins
 *
 * Bei jeder Eingabe wird die Suchfunktion austomatisch ausgef&uuml;hrt.
 *
 */

public class Search extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	TextView pluginTV = null;
	EditText editSuchen = null;
	LinearLayout pluginScroll = null;
    int clientId = 0;

	/**
	 * @brief Setup der Activity
	 * 
	 * Sucht Plugins, sobald ein Buchstabe eingetippt wurde und sucht weiter bei jedem weiteren eingetippten
	 * Buchstaben.
	 */

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setLayout(R.layout.activity_search);
		editSuchen = (EditText)findViewById(R.id.search_edit);
		pluginScroll = (LinearLayout)findViewById(R.id.pluginScroll);
		Intent intent = getIntent();
		clientId = intent.getIntExtra("clientId", 0);
		
		editSuchen.addTextChangedListener(new TextWatcher()
		{
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
			public void onTextChanged(CharSequence s, int start, int before, int count) {}
			@Override
			public void afterTextChanged(Editable arg0) {
				readPlugins();
			}
		});

		editSuchen.setOnKeyListener(new OnKeyListener()
		{
			public boolean onKey(View v, int keyCode, KeyEvent event)
			{

				if (keyCode ==  KeyEvent.KEYCODE_ENTER) {
					if (event.getAction() == KeyEvent.ACTION_DOWN) {
					} else if (event.getAction() == KeyEvent.ACTION_UP) {
						InputMethodManager imm = 
								(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
						imm.hideSoftInputFromWindow(editSuchen.getWindowToken(), 0);
					} 
					return true;

				} else {

					return false;
				}
			}

		});
		
		setPluginTV();

	}

	/**
	 * @brief Liest alle Werte ein und zeigt diese an
	 * 
	 * Setzt alle gefundenen Plugins in den ScrollView
	 */

	public void readPlugins(){

		pluginScroll.removeAllViews();
			
		if(!editSuchen.getText().toString().equals(""))
		{
			String [] searchString = db.searchPlugins(editSuchen.getText().toString());
			if(searchString.length != 0){

				TextView[] textViewArray = new TextView[searchString.length];
				
				for(int i = (searchString.length-1); i >= 0; i--) {
					
					textViewArray[i] = new TextView(this);
					textViewArray[i].setBackgroundResource(R.drawable.cell_shape_contacts);
					textViewArray[i].setPadding(10, 15, 10, 15);
					textViewArray[i].setTextAppearance(this, android.R.style.TextAppearance_Large);
					textViewArray[i].setTextColor(getResources().getColor(R.color.textColorWeekdays));						
					textViewArray[i].setTextSize(32);
					textViewArray[i].setClickable(true);
					
					String returnString = searchString[i];
					String[] parts = returnString.split(",");
					textViewArray[i].setId(Integer.parseInt(parts[0]));
					textViewArray[i].setText(parts[1]);
					
					
					textViewArray[i].setOnClickListener(new View.OnClickListener() {  
						@Override         
						public void onClick(View v) { 
							Log.d("", "pluginID: " + v.getId());
							Log.d("", "clientID: " + clientId);
							String packageName = db.getPackageNameToId(v.getId());
							Intent intent = new Intent();
			                intent.setClassName(packageName, packageName + ".MainActivity");	
			                intent.putExtra("clientId", clientId);
							startActivity(intent);							
						}     
					});
					pluginScroll.addView(textViewArray[i]);
				}
			}else{
				setPluginTV();
			}
		}
		else{
			setPluginTV();
		}
	}
	
	private void setPluginTV() {
		pluginTV = new TextView(this);
		pluginTV.setBackgroundResource(R.drawable.cell_shape_contacts);
		pluginTV.setPadding(10, 15, 10, 15);
		pluginTV.setTextAppearance(this, android.R.style.TextAppearance_Large);
		pluginTV.setTextColor(getResources().getColor(R.color.textColorWeekdays));						
		pluginTV.setTextSize(32);
		pluginTV.setText("- Keine Plugins vorhanden -");
		pluginScroll.addView(pluginTV);
	}
	
	public void onButtonClick(View view) {
		switch (view.getId()) {
		case (R.id.backButton):
			if (editSuchen.getText().length() != 0) {
				String text = editSuchen.getText().toString();
				text = text.substring(0, text.length() - 1);
				editSuchen.setText(text);
			}
			else
				super.onButtonClick(view);
			break;
		case (R.id.dbmanagerButton):
			startActivity(new Intent(this, DatabaseManager.class));
			break;
		default:
			super.onButtonClick(view);
			break;
		}
	}

}

