package de.drk.appcenter.neu.Helper;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.ArrayList;

/**
 * @class DatenbankHelfer
 * 
 * @brief Diese Klasse dient als Zwischenschicht fuer die Datenbank und Klassen, die mit der Datenbank arbeiten wollen
 * 
 * In dieser Klasse gibt es einige Getter und Putter Methoden um Daten von und in die Datenbank einzutragen. Auch der Aufbau
 * und spaetere Upgrade einer Datenbank wird hier ausgefuehrt.
 * 
 * Die Datenbank besteht aus zwei Tabellen, Kontakte und Calendar. 
 *
 */

public class DatabaseHelper extends SQLiteOpenHelper {
	private static final String PLUGINID = "pluginId";
	private static final String PLUGINNAME = "pluginName";
	private static final String PLUGINPACKAGENAME = "pluginPackageName";
	private static final String PLUGINPOSITION = "pluginPosition";
	//private static final String FORENAME = "forename";
	//private static final String SURNAME = "surname";
	//private static final String TITLE = "title";
	//private static final String ALARM = "alarm";
	//private static final String DTSTART = "dtstart";
	//private static final String COLOR = "colorTextview";
	//private static final String PHONE = "phone";
	//private static final String PILLSNAME = "name";
	//private static final String PILLSWEEKDAY = "weekday";
	//private static final String PILLSREPEAT = "repeat";
	//private static final String TITLEB = "titleB";
	//private static final String URL = "url";
	//private static final String VALUENAME = "valuename";
	//private static final String VALUE = "value";
	//private static final String REMOTE = "isremote";
	//private static final String ISDOC = "isdoc";
	//private static final String TABLE_CALENDAR = "calendar";
	//private static final String TABLE_PILLS = "pills";
	//private static final String TABLE_CONTACTS = "contact";
	//private static final String TABLE_BOOKMARKS = "bookmark";
	//private static final String TABLE_VALUE = "value";
	private static final String TABLE_PLUGIN = "plugin";
	private static final String DB_NAME = "database.db";
	private static final int DB_VERSION = 1;
	/*private static final String TAB_CREATE_CONTACTS =
			"CREATE TABLE contact ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "forename TEXT,"
					+ "surname TEXT,"
					+ "phone TEXT,"
					+ "isdoc TEXT);";

	private static final String TAB_CREATE_CALENDAR =
			"CREATE TABLE calendar ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "title TEXT,"
					+ "alarm TEXT,"
					+ "dtstart TEXT,"
					+ "colorTextview TEXT,"
					+ "isremote TEXT);";

	private static final String TAB_CREATE_BOOKMARKS =
			"CREATE TABLE bookmark ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "titleB TEXT,"
					+ "url TEXT);";

	private static final String TAB_CREATE_VALUE =
			"CREATE TABLE value ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "valuename TEXT,"
					+ "value TEXT);";

	private static final String TAB_CREATE_PILLS =
			"CREATE TABLE pills ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "name TEXT,"
					+ "weekday TEXT,"
					+ "repeat TEXT);";*/
	
	private static final String TAB_CREATE_PLUGIN =
			"CREATE TABLE plugin ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "pluginId INTEGER,"
					+ "pluginName TEXT,"
					+ "pluginPackageName TEXT,"
					+ "pluginPosition INTEGER);";

	/*private static final String CALENDAR_DROP = 
			"DROP TABLE IF EXISTS calendar";

	private static final String CONTACTS_DROP = 
			"DROP TABLE IF EXISTS contact";

	private static final String VALUE_DROP = 
			"DROP TABLE IF EXISTS value";

	private static final String BOOKMARKS_DROP = 
			"DROP TABLE IF EXISTS bookmark";

	private static final String PILLS_DROP = 
			"DROP TABLE IF EXISTS pills";*/
	
	private static final String PLUGIN_DROP = 
			"DROP TABLE IF EXISTS plugin";


	public DatabaseHelper(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}

	/*public void addBookmark(String titleBook, String urlBook) {
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(TITLEB, titleBook); 
		values.put(URL, urlBook); 
		db.insert(TABLE_BOOKMARKS, null, values);
		db.close();
	}

	public void addContact(String vorname, String nachname, String telefonnummer) {
		SQLiteDatabase db = this.getWritableDatabase();  //Schreibzugang zu der Datenbank
		ContentValues values = new ContentValues();
		values.put(FORENAME, vorname); 
		values.put(SURNAME, nachname); 
		values.put(PHONE, telefonnummer); 
		values.put(ISDOC, "0");
		db.insert(TABLE_CONTACTS, null, values);
		db.close();
	}

	public void addEvent(String title, String alarm, String dtstart, String colorTextview, String isremote) {
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(TITLE, title); 
		values.put(ALARM, alarm); 
		values.put(DTSTART, dtstart);  
		values.put(COLOR, colorTextview); 
		values.put(REMOTE, isremote); 
		db.insert(TABLE_CALENDAR, null, values);
		db.close();
	}

	public void addPills(String name, String weekday, String repeat) {
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(PILLSNAME, name); 
		values.put(PILLSWEEKDAY, weekday); 
		values.put(PILLSREPEAT, repeat);  
		db.insert(TABLE_PILLS, null, values);
		db.close();
	}*/
	
	public void addPlugin(int pluginId, String pluginName, String pluginPackageName, int pluginPosition) {
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(PLUGINID, pluginId); 
		values.put(PLUGINNAME, pluginName);
		values.put(PLUGINPACKAGENAME, pluginPackageName);
		values.put(PLUGINPOSITION, pluginPosition);
		db.insert(TABLE_PLUGIN, null, values);
		db.close();
	}

	/*public void addDoc(String forename, String surname, String phone) {
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(FORENAME, forename); 
		values.put(SURNAME, surname); 
		values.put(PHONE, phone);  
		values.put(ISDOC, "1");
		db.insert(TABLE_CONTACTS, null, values);
		db.close();
	}

	public void addCarer(String forename, String surname, String phone) {
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(FORENAME, forename); 
		values.put(SURNAME, surname); 
		values.put(PHONE, phone);  
		values.put(ISDOC, "2");
		db.insert(TABLE_CONTACTS, null, values);
		db.close();
	}

	public void deleteBookmark(int id){
		SQLiteDatabase db = this.getReadableDatabase();
		String where = "id = " + id;
		db.delete(TABLE_BOOKMARKS, where, null);
	}

	public void deleteContact(int id){
		SQLiteDatabase db = this.getReadableDatabase();
		String where = "id = " + id;
		db.delete(TABLE_CONTACTS, where, null);
	}

	public void deleteEvent(int id){
		SQLiteDatabase db = this.getReadableDatabase();
		String where = "id = " + id;
		db.delete(TABLE_CALENDAR, where, null);
	}

	public void deletePills(int id){
		SQLiteDatabase db = this.getReadableDatabase();
		String where = "id = " + id;
		db.delete(TABLE_PILLS, where, null);
	}*/
	
	public void deletePlugin(int pluginId){
		SQLiteDatabase db = this.getReadableDatabase();
		String where = "pluginId = " + pluginId;
		db.delete(TABLE_PLUGIN, where, null);
	}
	
	public String[] getPluginName(){
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = 
				db.query("plugin", 
						new String[] {"pluginName"}, 
						"", 
						null, 
						null, 
						null, 
						"pluginName ASC");
		
		Cursor.moveToFirst();
		String[] pluginName = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			pluginName[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}
		
		db.close();
		return pluginName;
	}
	
	/*public String getCity(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT city FROM contact WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String city = Cursor.getString(0);
		db.close();
		return city;
	}*/
	
	public String getPackageNameToId(int id){
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = db.rawQuery(
				"SELECT pluginPackageName FROM plugin WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";	
		Cursor.moveToFirst();
		String packageName = Cursor.getString(0);
		db.close();
		return packageName;
	}
	
	public String[] getPluginPackageName(){
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = 
				db.query("plugin", 
						new String[] {"pluginPackageName"}, 
						"", 
						null, 
						null, 
						null, 
						"pluginName ASC");
		
		Cursor.moveToFirst();
		String[] pluginPackageName = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			pluginPackageName[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}
		
		db.close();
		return pluginPackageName;
	}
	
	public int[] getPluginId(){
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = 
				db.query("plugin", 
						new String[] {"pluginId"}, 
						"", 
						null, 
						null, 
						null, 
						"pluginName ASC");
		
		Cursor.moveToFirst();
		int[] pluginId = new int[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			pluginId[i]=Cursor.getInt(0);
			Cursor.moveToNext();
		}
		
		db.close();
		return pluginId;
	}
	
	public int[] getPluginPosition(){
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = 
				db.query("plugin", 
						new String[] {"pluginPosition"}, 
						"", 
						null, 
						null, 
						null, 
						"pluginName ASC");
		
		Cursor.moveToFirst();
		int[] pluginPosition = new int[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			pluginPosition[i]=Cursor.getInt(0);
			Cursor.moveToNext();
		}
		
		db.close();
		return pluginPosition;
	}
	
	public boolean pluginIdExists(int pluginId){
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor=db.rawQuery("SELECT 1 FROM plugin WHERE pluginId = " + pluginId, null);
		
		if(Cursor.getCount()!=0)
			return true;
		
		db.close();
		return false;
	}
	
	public void updatePluginPosition(int pluginId, int pluginPosition){
		SQLiteDatabase db = this.getWritableDatabase();
		
		ContentValues cv = new ContentValues();
		cv.put(PLUGINPOSITION, pluginPosition);
		db.update(TABLE_PLUGIN, cv, PLUGINID + "= " + pluginId, null);
		
		db.close();
	}

	/*public String[] getAlarm(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("calendar", 
						new String[] {"alarm"}, 
						"", 
						null, 
						null, 
						null, 
						"dtstart ASC");



		Cursor.moveToFirst();
		String[] alarm = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			alarm[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return alarm;

	}

	public String getAlarmTime(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("value", 
						new String[] {"value"}, 
						"", 
						null, 
						null, 
						null, 
						null);



		Cursor.moveToPosition(2);
		String alarm_time = Cursor.getString(0);;



		db.close();
		return alarm_time;

	}


	public String[] getBookmarkId(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("bookmark", 
						new String[] {"id"}, 
						"", 
						null, 
						null, 
						null, 
						"titleB ASC");



		Cursor.moveToFirst();
		String[] id = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			id[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return id;

	}




	public void deleteDocs(){

		SQLiteDatabase db = this.getWritableDatabase();     
		db.execSQL("DELETE FROM contact WHERE isdoc='1'");
		db.close();

	}

	public void deleteCarer(){

		SQLiteDatabase db = this.getWritableDatabase();     
		db.execSQL("DELETE FROM contact WHERE isdoc='2'");
		db.close();

	}


	public void deleteRemoteEvents(){

		SQLiteDatabase db = this.getWritableDatabase();     
		db.execSQL("DELETE FROM calendar WHERE isremote='1'");
		db.close();

	}
	public String[] getPillsId(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("pills", 
						new String[] {"id"}, 
						"", 
						null, 
						null, 
						null, 
						"name ASC");



		Cursor.moveToFirst();
		String[] id = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			id[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return id;

	}

	public String[] getPillsName(){


		SQLiteDatabase db = this.getWritableDatabase();     
		Cursor Cursor = 
				db.query("pills", 
						new String[] {"name"}, 
						"", 
						null, 
						null, 
						null, 
						"name ASC");



		Cursor.moveToFirst();
		String[] name = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			name[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return name;

	}

	public String[] getPillsWeekday(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("pills", 
						new String[] {"weekday"}, 
						"", 
						null, 
						null, 
						null, 
						"name ASC");



		Cursor.moveToFirst();
		String[] weekday = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			weekday[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return weekday;

	}

	public String[] getPillsRepeat(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("pills", 
						new String[] {"repeat"}, 
						"", 
						null, 
						null, 
						null, 
						"name ASC");



		Cursor.moveToFirst();
		String[] repeat = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			repeat[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return repeat;

	}


	public String getBookmarkSet(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("value", 
						new String[] {"value"}, 
						"", 
						null, 
						null, 
						null, 
						null);



		Cursor.moveToPosition(1);

		String show_add_bookmark = Cursor.getString(0);;



		db.close();
		return show_add_bookmark;

	}

	public String[] getCalendarId(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("calendar", 
						new String[] {"id"}, 
						"", 
						null, 
						null, 
						null, 
						"dtstart ASC");



		Cursor.moveToFirst();
		String[] id = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			id[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return id;

	}

	public String[] getColor(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("calendar", 
						new String[] {"colorTextview"}, 
						"", 
						null, 
						null, 
						null, 
						"dtstart ASC");



		Cursor.moveToFirst();
		String[] category = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			category[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return category;

	}




	public String[] getContactId(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("contact", 
						new String[] {"id"}, 
						"", 
						null, 
						null, 
						null, 
						"surname ASC");



		Cursor.moveToFirst();
		String[] id = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			id[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return id;

	}

	public String[] getForename(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("contact", 
						new String[] {"forename"}, 
						"", 
						null, 
						null, 
						null, 
						"surname ASC");



		Cursor.moveToFirst();
		String[] vorname = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			vorname[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return vorname;

	}

	public String[] getPhone(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("contact", 
						new String[] {"phone"}, 
						"", 
						null, 
						null, 
						null, 
						"surname ASC");



		Cursor.moveToFirst();
		String[] phone = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			phone[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return phone;

	}


	public String[] getisdoc(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("contact", 
						new String[] {"isdoc"}, 
						"", 
						null, 
						null, 
						null, 
						"surname ASC");



		Cursor.moveToFirst();
		String[] isdoc = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			isdoc[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return isdoc;

	}

	public String[] getStart(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("calendar", 
						new String[] {"dtstart"}, 
						"", 
						null, 
						null, 
						null, 
						"dtstart ASC");



		Cursor.moveToFirst();
		String[] start = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			start[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return start;

	}



	public String getStartTime(int id){

		String starttime="";

		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor CursorID = 
				db.query("calendar", 
						new String[] {"id"}, 
						"", 
						null, 
						null, 
						null, 
						"dtstart ASC");



		CursorID.moveToFirst();
		String[] idString = new String[CursorID.getCount()];
		for (int i = 0; i < CursorID.getCount(); i++) {

			idString[i]=CursorID.getString(0);
			CursorID.moveToNext();

		}

		db.close();

		SQLiteDatabase db2 = this.getReadableDatabase();
		Cursor CursorStart = 
				db2.query("calendar", 
						new String[] {"dtstart"}, 
						"", 
						null, 
						null, 
						null, 
						"dtstart ASC");



		CursorStart.moveToFirst();
		String[] dtstart = new String[CursorStart.getCount()];
		for (int i = 0; i < CursorStart.getCount(); i++) {

			dtstart[i]=CursorStart.getString(0);
			CursorStart.moveToNext();

		}

		for(int i=0;i<dtstart.length;i++){
			if(Integer.valueOf(idString[i])==id){
				starttime=dtstart[i];
			}
		}


		db2.close();
		return starttime;
	}

	public String[] getSurname(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("contact", 
						new String[] {"surname"}, 
						"", 
						null, 
						null, 
						null, 
						"surname ASC");



		Cursor.moveToFirst();
		String[] nachname = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			nachname[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return nachname;

	}

	public String getSync(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("value", 
						new String[] {"value"}, 
						"", 
						null, 
						null, 
						null, 
						null);



		Cursor.moveToFirst();
		String sync = Cursor.getString(0);;



		db.close();
		return sync;

	}




	public String[] getTitle(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("calendar", 
						new String[] {"title"}, 
						"", 
						null, 
						null, 
						null, 
						"dtstart ASC");



		Cursor.moveToFirst();
		String[] title = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			title[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return title;

	}

	public String[] getTitleBook(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("bookmark", 
						new String[] {"titleB"}, 
						"", 
						null, 
						null, 
						null, 
						"titleB ASC");



		Cursor.moveToFirst();
		String[] titleB = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			titleB[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return titleB;

	}


	public String[] searchContact(String name){

		SQLiteDatabase db = this.getReadableDatabase();     

		Cursor Cursor=db.rawQuery("SELECT firstName FROM contact WHERE firstName LIKE '%"+name+"%' OR lastName LIKE '%"+name+"%'", null);
		Cursor Cursor2=db.rawQuery("SELECT lastName FROM contact WHERE firstName LIKE '%"+name+"%' OR lastName LIKE '%"+name+"%'", null);
		Cursor Cursor3=db.rawQuery("SELECT phoneNumber FROM contact WHERE firstName LIKE '%"+name+"%' OR lastName LIKE '%"+name+"%'", null);

		Cursor.moveToFirst();
		Cursor2.moveToFirst();
		Cursor3.moveToFirst();
		String[] value = new String[Cursor.getCount()];
		String[] value2 = new String[Cursor2.getCount()];
		String[] value3 = new String[Cursor3.getCount()];
		String[] ret_string = new String[Cursor.getCount()];


		for (int i = 0; i < Cursor.getCount(); i++) {

			value[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}

		for (int i = 0; i < Cursor2.getCount(); i++) {

			value2[i]=Cursor2.getString(0);
			Cursor2.moveToNext();

		}

		for (int i = 0; i < Cursor3.getCount(); i++) {

			value3[i]=Cursor3.getString(0);
			Cursor3.moveToNext();

		}

		for (int i = 0; i < Cursor.getCount(); i++){

			ret_string[i]=value[i]+", "+value2[i]+" _ "+value3[i];
		}

		db.close();
		return ret_string;

	}

	public String[] searchEvent(String event){

		SQLiteDatabase db = this.getReadableDatabase();


		Cursor Cursor=db.rawQuery("SELECT title FROM calendar WHERE title LIKE '%"+event+"%'", null);
		Cursor Cursor2=db.rawQuery("SELECT startdt FROM calendar WHERE title LIKE '%"+event+"%'", null);

		Cursor.moveToFirst();
		Cursor2.moveToFirst();

		/*int[] stunden = new int[Cursor.getCount()];
		String[] minuten = new String[Cursor.getCount()];
		int[] tag = new int[Cursor.getCount()];
		int[] monat = new int[Cursor.getCount()];
		int[] jahr = new int[Cursor.getCount()];

		String[] value = new String[Cursor.getCount()];
		String[] value2 = new String[Cursor2.getCount()];
		String[] ret_string = new String[Cursor.getCount()];

		for (int i = 0; i < Cursor.getCount(); i++) {

			value[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}

		for (int i = 0; i < Cursor2.getCount(); i++) {
			value2[i]=Cursor2.getString(0);
			/*Calendar now = Calendar.getInstance();
			now.setTimeInMillis(Long.parseLong(value2[i]));		//Aktuelle Zeit gesetzt
			stunden[i]=now.get(Calendar.HOUR_OF_DAY);


			minuten[i]=String.valueOf(now.get(Calendar.MINUTE));
			if(Integer.valueOf(minuten[i])<10){
				minuten[i]="0"+minuten[i];
			}

			tag[i]=now.get(Calendar.DAY_OF_MONTH);
			monat[i]=now.get(Calendar.MONTH)+1;
			jahr[i]=now.get(Calendar.YEAR);

			Cursor2.moveToNext();

		}

		for (int i = 0; i < Cursor.getCount(); i++) {

			//ret_string[i]=value[i]+" am "+tag[i]+"."+monat[i]+"."+jahr[i]+" um "+stunden[i]+":"+minuten[i];  
			ret_string[i]=value[i]+value2[i]; 
		}

		db.close();
		return ret_string;

	}

	public String[] getUrlBook(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("bookmark", 
						new String[] {"url"}, 
						"", 
						null, 
						null, 
						null, 
						"titleB ASC");



		Cursor.moveToFirst();
		String[] url = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			url[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return url;

	}*/
	
	public String[] searchPlugins(String name) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor CursorPluginIds = db.rawQuery(
				"SELECT id FROM plugin WHERE pluginName LIKE '%" + name + "%' ORDER BY pluginName DESC", null);
		Cursor CursorPluginNames = db.rawQuery(
				"SELECT pluginName FROM plugin WHERE pluginName LIKE '%" + name + "%' ORDER BY pluginName DESC", null);
		CursorPluginIds.moveToFirst();
		CursorPluginNames.moveToFirst();
		String[] returnString = new String[CursorPluginIds.getCount()];
		for (int i = 0; i < CursorPluginIds.getCount(); i++) {
			returnString[i] = CursorPluginIds.getString(0) + "," + CursorPluginNames.getString(0);
			CursorPluginIds.moveToNext();
			CursorPluginNames.moveToNext();
		}
		db.close();
		return returnString;
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		//db.execSQL(TAB_CREATE_CONTACTS);
		//db.execSQL(TAB_CREATE_CALENDAR);
		//db.execSQL(TAB_CREATE_VALUE);
		//db.execSQL(TAB_CREATE_BOOKMARKS);
		//db.execSQL(TAB_CREATE_PILLS);
		db.execSQL(TAB_CREATE_PLUGIN);

		/*ContentValues values = new ContentValues();
		values.put(VALUENAME, "lastsync"); 
		values.put(VALUE, "0");  
		db.insert(TABLE_VALUE, null, values);

		ContentValues values2 = new ContentValues();
		values2.put(VALUENAME, "show_bookmark_set"); 
		values2.put(VALUE, "0");  
		db.insert(TABLE_VALUE, null, values2);

		ContentValues values3 = new ContentValues();
		values3.put(VALUENAME, "alarm_time"); 
		values3.put(VALUE, "0");  
		db.insert(TABLE_VALUE, null, values3);*/
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		//Wird ein neuer Datenbankaufbau gebraucht, wird diese Methode aufgerufen in dieser man den Code hinterlegen kann um die
		//Daten in die neue Datenbank zu migrieren. Hier loeschen wir die Datenbank einfach und legen sie neu an.
		//db.execSQL(CALENDAR_DROP);
		//db.execSQL(CONTACTS_DROP);
		//db.execSQL(VALUE_DROP);
		//db.execSQL(BOOKMARKS_DROP);
		//db.execSQL(PILLS_DROP);
		db.execSQL(PLUGIN_DROP);
		onCreate(db);

	}



	/*public void resetDatabaseBookmarks(){


		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(BOOKMARKS_DROP);
		db.execSQL(TAB_CREATE_BOOKMARKS);

	}

	public void resetDatabaseCalendar(){


		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(CALENDAR_DROP);
		db.execSQL(TAB_CREATE_CONTACTS);

	}


	public void resetDatabaseContacts(){


		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(CONTACTS_DROP);
		db.execSQL(TAB_CREATE_CONTACTS);

	}

	public void resetDatabasePills(){


		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(PILLS_DROP);
		db.execSQL(TAB_CREATE_PILLS);

	}


	public void resetDatabaseValue(){


		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(VALUE_DROP);
		db.execSQL(TAB_CREATE_VALUE);

	}*/
	
	public void resetDatabasePlugin(){

		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(PLUGIN_DROP);
		db.execSQL(TAB_CREATE_PLUGIN);

	}

	/*public void setAlarmTime(String set) {

		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(VALUENAME, "alarm_time"); 
		values.put(VALUE, set); 
		db.update(TABLE_VALUE, values, "id = 3", null);

		db.close();
	}

	public void setBookmarkSet(String set) {



		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(VALUENAME, "show_bookmark_set"); 
		values.put(VALUE, set); 
		db.update(TABLE_VALUE, values, "id = 2", null);

		db.close();
	}*/
	
	// Methode wird fuer den Database-Manager waehrend der Entwicklung der
	// App benoetigt.
	public ArrayList<Cursor> getData(String Query) {
		// get writable database
		SQLiteDatabase sqlDB = this.getWritableDatabase();
		String[] columns = new String[] { "message" };
		// an array list of cursor to save two cursors one has results from the
		// query
		// other cursor stores error message if any errors are triggered
		ArrayList<Cursor> alc = new ArrayList<Cursor>(2);
		MatrixCursor Cursor2 = new MatrixCursor(columns);
		alc.add(null);
		alc.add(null);

		try {
			String maxQuery = Query;
			// execute the query results will be save in Cursor c
			Cursor c = sqlDB.rawQuery(maxQuery, null);

			// add value to cursor2
			Cursor2.addRow(new Object[] { "Success" });

			alc.set(1, Cursor2);
			if (null != c && c.getCount() > 0) {
				alc.set(0, c);
				c.moveToFirst();
				return alc;
			}
			return alc;
		} catch (SQLException sqlEx) {
			Log.d("printing exception", sqlEx.getMessage());
			// if any exceptions are triggered save the error message to cursor
			// an return the arraylist
			Cursor2.addRow(new Object[] { "" + sqlEx.getMessage() });
			alc.set(1, Cursor2);
			return alc;
		} catch (Exception ex) {

			Log.d("printing exception", ex.getMessage());

			// if any exceptions are triggered save the error message to cursor
			// an return the arraylist
			Cursor2.addRow(new Object[] { "" + ex.getMessage() });
			alc.set(1, Cursor2);
			return alc;
		}

	}
	
}
