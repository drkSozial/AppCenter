package de.drk.appcenter.neu.Helper;

import android.R.color;
import android.content.ComponentName;
import android.content.Context;
import android.content.pm.ActivityInfo;
import android.content.pm.PackageManager.NameNotFoundException;
import android.graphics.Color;
import android.graphics.drawable.Drawable;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.ImageView.ScaleType;

public class PluginButton{

	private Context context;
	
	public PluginButton(Context context){
		this.context = context;
	}

	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode ermittelt den Namen der App, deren Package-Name uebergeben wird. 
	//Sie erstellt aus dem Namen einen TextView und gibt diesen zurueck. 
	////////////////////////////////////////////////////////////////////////////////////
	public TextView createTextFromPlugin(String plugin, int textSize) 
			throws NameNotFoundException {
	
		String name = null;
		
		ComponentName comp = new ComponentName(plugin, plugin + ".MainActivity");		
		
		ActivityInfo info;
		
		info = context.getPackageManager().getActivityInfo(comp, 0);					//Info zum Plugin des uebergebenen Package-Namens holen
		name = info.loadLabel (context.getPackageManager()).toString ();				//Name des Plugins ermitteln
		
		TextView txt = new TextView(context);
		txt.setText(name);
		FrameLayout.LayoutParams params = new FrameLayout.
				LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
		params.gravity = Gravity.BOTTOM;
		
		txt.setLayoutParams(params);
		txt.setGravity(Gravity.CENTER);
		txt.setTextColor(Color.WHITE);
		txt.setTextSize(textSize);
		txt.setShadowLayer(2, 1, 1, Color.BLACK);
		
		return txt;
	}


	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode holt sich das Icon der App, deren Package-Name uebergeben wird. 
	//Es wird ein neuer ImageButton mit dem Icon als Hintergrund erstellt.
	////////////////////////////////////////////////////////////////////////////////////
	public ImageButton createImageButtonFromPlugin(String plugin, int size) 
			throws NameNotFoundException {
	
		Drawable icon = null; 

		icon = context.getPackageManager().getApplicationIcon(plugin);					//holen des Icons
		
		ImageButton imbt = new ImageButton(context);
		imbt.setImageDrawable(icon);
		imbt.setBackgroundColor(color.transparent);
		FrameLayout.LayoutParams param = new FrameLayout.LayoutParams(size, size);		//Params fuer die Groesse des Icons
		param.gravity = Gravity.CENTER;
		imbt.setLayoutParams(param);
		imbt.setScaleType(ScaleType.CENTER_INSIDE);
		imbt.setClickable(false);														//Clickable ausschalten, sonst reagiert der ImageButton nicht auf das onClick-Event 
	
		return imbt;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode passt die Groesse des Icons und Textes eines Buttons an.
	////////////////////////////////////////////////////////////////////////////////////
	public void resizeButton(FrameLayout flButton, int imageButtonSize, int textSize){
		FrameLayout.LayoutParams paramsButton = new FrameLayout.
				LayoutParams(imageButtonSize,imageButtonSize);
		paramsButton.gravity = Gravity.CENTER;
		
		flButton.getChildAt(0).setLayoutParams(paramsButton);
		TextView txt = (TextView) flButton.getChildAt(1);
		txt.setTextSize(TypedValue.COMPLEX_UNIT_SP, textSize);		
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode erstellt ein FrameLayout, und fuegt Icon und Name des Plugins in 
	//dieses. Das FrameLayout wird zurueckgegeben.
	////////////////////////////////////////////////////////////////////////////////////
	public FrameLayout createButtonFromPlugin(String plugin, int buttonId, 
			int imageButtonSize, int textSize) throws NameNotFoundException{
		
		FrameLayout button = new FrameLayout(context);
		FrameLayout.LayoutParams paramsButton = new FrameLayout.						
				LayoutParams(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
		button.setLayoutParams(paramsButton);
		ImageButton image = createImageButtonFromPlugin(plugin, imageButtonSize);
		TextView txt = createTextFromPlugin(plugin, textSize);
		
		button.addView(image);
		button.addView(txt);
		
		button.setId(buttonId);
		
		return button;
	}
}
