package de.drk.appcenter.neu.Helper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.drk.appcenter.neu.Helper.WebServiceParser;

/**
 * 
 * @author Peter Ewert
 *
 */

public class RemoteDB {

	static String serverAdress = "http://212.100.43.180";

	public static boolean checkConfigChanges(int clientId, String cFlagName) {
		
		JSONObject json;
		JSONArray changeFlag;
		
		//Parser initialisieren
		WebServiceParser jParser = new WebServiceParser();
		
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();

		nameValuePairs.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));
		nameValuePairs.add(new BasicNameValuePair("cFlagName",cFlagName));
		
		json = jParser.sendEntityGetJSONFromUrl(serverAdress + "/changeFlagNeu.php", nameValuePairs);

		if(json != null){
			try {
				changeFlag = json.getJSONArray("changeFlag");
				JSONObject c = changeFlag.getJSONObject(0);
				if(c.getInt("CFLAGSTATUS")==1){
					return true;
				}
				
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
			
		return false;
	}

	public static JSONArray getUserPlugins(int clientId){
		
		JSONObject json;
		JSONArray plugins = null;
		
		WebServiceParser jParser = new WebServiceParser();

		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		 
	   	nameValuePair.add(new BasicNameValuePair("ClientId",Integer.toString(clientId)));
		
		json = jParser.sendEntityGetJSONFromUrl(serverAdress + "/userPluginsNeu.php", nameValuePair);
	
		try {
			plugins = json.getJSONArray("userPlugins");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return plugins;
	}
	
	/*public static JSONObject getData(){
		
		JSONObject json;
		
		//Parser initialisieren
		WebServiceParser jParser = new WebServiceParser();

		//JSON Objekt von einer URL holen
		json = jParser.getJSONFromUrl(serverAdress + "/json/getdata.php");
		
		return json;
	}*/
	
	public static void setChangeFlag(int clientId, String cFlagName, int value){
		
		HttpClient httpclient = new DefaultHttpClient();
		
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		
		nameValuePair.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));
		nameValuePair.add(new BasicNameValuePair("cFlagName",cFlagName));
		nameValuePair.add(new BasicNameValuePair("value",Integer.toString(value)));
	   	
	   	HttpPost httppost = new HttpPost(serverAdress + "/setChangeFlagNeu.php");

		try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair));
			httpclient.execute(httppost);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
