package de.drk.plugin.firstaid.neu;

import android.os.Bundle;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import de.drk.plugin.firstaid.neu.R;
import de.drk.template.neu.AppcenterTemplate;

/**
 * @class Firstaid
 * 
 * @brief Anzeigen von Erste Hilfe Maßnahmen
 *
 * Diese Actvity zeigt die "Erste Hilfe" Seite des DRKes an.
 */

public class MainActivity extends AppcenterTemplate {

	WebView first = null;

	/**
	 * @brief Setup der Activity
	 * 
	 * Wir setzen hier nur ein Webview und rufen die Seite des DRKes auf. 
	 */

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

		setLayout(R.layout.activity_main);

		first = (WebView)findViewById(R.id.browser_view);
		first.loadUrl("http://www.drk.de/angebote/erste-hilfe-und-rettung/erste-hilfe-online.html");
		first.setWebViewClient(new WebViewClient());

	}
	
	
	/**
	 * @brief Wird ein Button gedrueckt wird diese Methode ausgefuehrt.
	 * 
	 * Der entsprechende Button wird mit einer IF Anweisung abgefragt und der entsprechende Code wird ausgefuehrt.
	 */

	public void onButtonClick(View view) {

		super.onButtonClick(view);
		
	}

	
}
