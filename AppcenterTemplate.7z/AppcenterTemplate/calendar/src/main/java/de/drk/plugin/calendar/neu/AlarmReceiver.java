package de.drk.plugin.calendar.neu;

import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import de.drk.plugin.calendar.neu.Helper.DatabaseHelper;
import de.drk.template.neu.AppcenterTemplate;
import de.drk.plugin.calendar.neu.R;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.media.MediaPlayer;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Bundle;
import android.os.PowerManager;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

/**
 * Diese Klasse stellt die Funktionalitaet zur Wiedergabe
 * des Alarmtons bereit; dazu wird insbesondere das Layout mit
 * dem Alarm-Button gesetzt, wo der faellige Termin angezeigt
 * wird; mit einem Klick auf den Button kann die Tonwiedergabe
 * gestoppt werden; alle Buttons der rechten Menueleiste
 * (Template) werden gesperrt um ein anderweitiges Navigieren
 * zu verhindern; verschwindet diese Activity aus dem Vordergrund.
 */

public class AlarmReceiver extends AppcenterTemplate {
	
	private MediaPlayer mp;
	private PowerManager.WakeLock wl;
	ScheduledExecutorService executor = Executors.newSingleThreadScheduledExecutor();
	DatabaseHelper db = new DatabaseHelper(this);

	/**
	 * Wird beim Start der Activity aufgerufen, setzt einen WakeLock und das
	 * Layout, konfiguriert das Layout-Feld (Alarm-Button) und ruft die
	 * Methode zur Wiedergabe des Alarmtons in einem Thread alle 5 Sekunden auf.
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// PowerManager-Objekt erzeugen und WakeLock setzen
		PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
		wl = pm.newWakeLock(PowerManager.FULL_WAKE_LOCK, "My Wake Lock");
		wl.acquire();
		this.requestWindowFeature(Window.FEATURE_NO_TITLE);
		this.getWindow().setFlags(
				WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
				WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON, 
				WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED |
				WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON
				);	
		// Layout fuer diese Activity setzen
		setLayout(R.layout.alarm_receiver);
		// Variablen und Objekte deklarieren sowie initialisieren
		Button alarmButton = (Button) findViewById(R.id.alarmButton);
		int alarmId = getIntent().getIntExtra("alarmid", 0);
		long alarmDt = getIntent().getLongExtra("alarmdt", 0);
		int appointmentId = db.getAppIdByNotId(alarmId);
		Date startDate = null;
		try {
			startDate = new SimpleDateFormat("dd.MM.yyyy HH:mm",
					Locale.GERMANY).parse(db.getStartDt(appointmentId));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		long diffMillis = startDate.getTime() - alarmDt;
		String diffMinutes = Long.toString(diffMillis / (1000 * 60));
		// Text des Alarmfelds setzen, wenn eine gueltige Alarm-ID uebergeben wurde
		if (alarmId != 0)
			alarmButton.setText("Termin " +db.getTitle(appointmentId)+ " faellig in " +diffMinutes+ " min.\n" +
					"Bitte klicken um die Wiedergabe zu stoppen.");
		// Methode playSound fuer Tonwiedergabe in einem separaten Thread alle 5 Sekunden aufrufen
		Runnable notification = new Runnable() {	
			@Override
			public void run() {
				playSound(getApplicationContext(), getAlarmUri()); 
			}		
		};
		executor.scheduleAtFixedRate(notification, 0, 5000, TimeUnit.MILLISECONDS);
	}
	
	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; das
	 * Layout dieser Activity verfuegt ueber einen Button
	 * zum Stoppen der Alarmtonwiedergabe und zum Wechseln in die 
	 * vorhergehende Activity (Alarm-Button); des Weiteren werden 
	 * alle Buttons des Templates neu konfiguriert bzw gesperrt, um ein 
	 * anderweitiges Navigieren zu unterbinden, solange die Wiedergabe
	 * des Alarmtons nicht ueber den dafuer vorgesehenen Button erfolgt.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		// Wiedergabe des Alarmtons stoppen und zur vorhergehenden Activity wechseln
		case (R.id.alarmButton):
			mp.release();
			executor.shutdown();
			finish();
			break;
	    // Buttons der rechten Menueleiste sperren
		case (R.id.phoneButton):
			break;
		case (R.id.homeButton):
			break;
		case (R.id.backButton):
			break;
		case (R.id.searchButton):
			break;
		// Aktionen ausfuehren, die fuer die Buttons im Template konfiguriert wurden
		default:
			super.onButtonClick(view);
			break;
		}
	}

	/**
	 * Der Methode wird der aktuelle Context und die Uri des
	 * Alarmtons als Parameter uebergeben; mit diesen Angaben 
	 * wird die Datenquelle des Media-Players gesetzt und 
	 * die Wiedergabe des Alarmtons gestartet.
	 * @param context ist das Programmumfeld, das benoetigt
	 * wird um Ressourcen anzufordern
	 * @param alert
	 */
	private void playSound(Context context, Uri alert) {
		mp = new MediaPlayer();
		try {
			mp.setDataSource(context, alert);
			final AudioManager am = (AudioManager) context.getSystemService(Context.AUDIO_SERVICE);
			if (am.getStreamVolume(AudioManager.STREAM_ALARM) != 0) {
				mp.setAudioStreamType(AudioManager.STREAM_ALARM);
				mp.prepare();
				mp.start();
			}
		} catch(IOException e) {
			Log.i("AlarmReceiver", "No audio files are found!");
		}
	}
	
	/**
	 * Diese Methode liefert ein Uri-Objekt, mit dem der zu verwendete
	 * Alarmton indentifiziert werden kann; als Alarmton kann entweder 
	 * der Benachrichtigungs-, der Alarm- oder der Klingelton verwendet
	 * werden.
	 * @return gibt das Uri-Objekt des Alarmtons zurueck
	 */
	private Uri getAlarmUri() {
		Uri alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
		if (alert == null)
			alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_ALARM);
			if (alert == null)
				alert = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_RINGTONE);
		return alert;
	}
	
	/**
	 * Die Methode wird ausgefuehrt, wenn die Alarm-Activity
	 * fuer den Benutzer nicht sichtbar wird; hier wird
	 * die onStop-Methode der Superklasse aufgerufen und der
	 * WakeLock freigegeben.
	 */
	@Override
	protected void onStop() {
		super.onStop();
		wl.release(); 
	}
}
