package de.drk.plugin.calendar.neu;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import de.drk.plugin.calendar.neu.Helper.DatabaseHelper;
import de.drk.plugin.calendar.neu.Helper.DatabaseManager;
import de.drk.template.neu.AppcenterTemplate;

/**
 * Diese Klasse stellt die Funktionalitaet zum Durchsuchen von Termindatensaetzen
 * bereit; dazu wird insbesondere das Layout mit dem Suchfeld gesetzt und das 
 * entsprechende Event konfiguriert, um jedesmal die Ergebnisanzeige aktualisieren
 * zu koennen, sobald ein (weiterer) Buchstabe eingetippt wurde. 
 */

public class SearchAppointments extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	TextView appointmentTV = null;
	EditText editSuchen = null;
	LinearLayout appointmentScroll = null;
    int clientId = 0;
    Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen und setzt das Layout; ausserdem wird
	 * ein Event fuer das Suchfeld festgelegt, also die Aktion die beim Eintippen 
	 * von Buchstaben in das Suchfeld ausgefuehrt werden soll; am Ende wird noch das 
	 * TextView, das zu Beginn angezeigt wird (ohne Suchergebnisse), erstellt und 
	 * dem Layout hinzugefuegt.
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// Layout fuer diese Activity setzen
		setLayout(R.layout.search_appointments);
		// Variablen und Objekte deklarieren sowie initialisieren
		editSuchen = (EditText)findViewById(R.id.search_edit);
		appointmentScroll = (LinearLayout)findViewById(R.id.appointmentScroll);
		clientId = getIntent().getIntExtra("clientId", 0);
		// Events fuer das EditText-Feld editSuchen festlegen
		editSuchen.addTextChangedListener(new TextWatcher() {
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
			public void onTextChanged(CharSequence s, int start, int before, int count) {}
			@Override
			public void afterTextChanged(Editable arg0) {
				// Methode fuer das Anzeigen von gefundenenen Terminen aufrufen, sobald ein
				// Buchstabe eingegeben wurde und bei jedem weiteren eingegebenen Buchstaben
				readAppointments();
			}
		});

		editSuchen.setOnKeyListener(new OnKeyListener() {
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if (keyCode ==  KeyEvent.KEYCODE_ENTER) {
					if (event.getAction() == KeyEvent.ACTION_DOWN) {
					} else if (event.getAction() == KeyEvent.ACTION_UP) {
						InputMethodManager imm = 
								(InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
						imm.hideSoftInputFromWindow(editSuchen.getWindowToken(), 0);
					} 
					return true;
				} else
					return false;
			}
		});
		// TextView fuer die nicht vorhandenen Suchergebnisse zu Beginn mit entsprechendem Hinweis
		// erstellen und dem LinearLayout hinzufuegen
		setAppointmentTV();
	}

	/**
	 * Wird jedesmal aufgerufen, sobald ein Buchstabe im Suchfeld
	 * eingegeben wurde; leert die LinearLayout-Inhalte, holt sich 
	 * dann die neuen Ergebnisse (Termindatensaetze) aus der Datenbank 
	 * und fuegt diese dem LinearLayout hinzu.
	 */
	public void readAppointments(){
		// LinearLayout-Inhalte (Suchergebnisse) entfernen
		appointmentScroll.removeAllViews();
		// wenn ein Buchstabe eingegeben wurde, dann das String-Array
		// mit den Ergebnissen aus der Datenbank holen
		if(!editSuchen.getText().toString().equals("")) {
			String[] searchString = db.searchAppointments(editSuchen.getText().toString());
			if(searchString.length != 0){
				// TexView-Array mit der Anzahl der gefundenen Termine erstellen
				TextView[] textViewArray = new TextView[searchString.length];
				// TextViews durchlaufen, Attribute setzen und onClickListener setzen,
				// anschliessend TextViews dem LinearLayout hinzufuegen
				for(int i = (searchString.length-1); i >= 0; i--) {
					textViewArray[i] = new TextView(this);
					textViewArray[i].setBackgroundResource(R.drawable.cell_shape);
					textViewArray[i].setPadding(10, 15, 10, 15);
					textViewArray[i].setTextAppearance(this, android.R.style.TextAppearance_Large);
					textViewArray[i].setTextColor(getResources().getColor(R.color.textColorWeekdays));						
					textViewArray[i].setTextSize(32);
					textViewArray[i].setClickable(true);
					String returnString = searchString[i];
					String[] parts = returnString.split(",");
					String title = parts[1];
					String startdt = parts[2];
					String endtdt = parts[3];
					textViewArray[i].setText(title + " (" + startdt + " - " + endtdt + ")");
					textViewArray[i].setId(Integer.parseInt(parts[0]));
					textViewArray[i].setOnClickListener(new View.OnClickListener() {  
						@Override         
						public void onClick(View v) {
							Log.d("", "appointmentId: " + v.getId());
							intent = new Intent(SearchAppointments.this, AppointmentData.class);
							intent.putExtra("appointmentId", v.getId());
							intent.putExtra("clientId", clientId);
							startActivity(intent);							
						}     
					});
					appointmentScroll.addView(textViewArray[i]);
				}
			}else
				setAppointmentTV();
		}
		else
			setAppointmentTV();
	}
	
	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; da
	 * das Layout dieser Activity ueber keine Buttons verfuegt,
	 * wird lediglich ein Button in der rechten Menueleiste,
	 * die ueber das Template generiert wird, neu konfiguriert;
	 * die Neukonfiguration fuehrt dazu, dass das Betaetigen des
	 * Back-Buttons den zuletzt eingegebenen Buchstaben entfernt.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		case (R.id.backButton):
			// zuletzt eingegebenen Buchstaben des Suchstrings loeschen
			if (editSuchen.getText().length() != 0) {
				String text = editSuchen.getText().toString();
				text = text.substring(0, text.length() - 1);
				editSuchen.setText(text);
			}
			else
				super.onButtonClick(view);
			break;
		// Aktionen ausfuehren, die im Template fuer die Buttons konfiguriert wurden
		default:
			super.onButtonClick(view);
			break;
		}
	}
	
	/**
	 * Diese Methode wird aufgerufen, wenn noch kein Buchstabe im
	 * Suchfeld eingegeben wurde oder der Suchstring zu keinen
	 * Ergebnisse fuehrt; die Methode erstellt ein neues 
	 * TextView-Objekt, setzt dessen Attribute und fuegt es dann 
	 * dem LinearLayout-Objekt hinzu.
	 */
	private void setAppointmentTV() {
		appointmentTV = new TextView(this);
		appointmentTV.setBackgroundResource(R.drawable.cell_shape);
		appointmentTV.setPadding(10, 15, 10, 15);
		appointmentTV.setTextAppearance(this, android.R.style.TextAppearance_Large);
		appointmentTV.setTextColor(getResources().getColor(R.color.textColorWeekdays));						
		appointmentTV.setTextSize(32);
		appointmentTV.setText("- Keine Termine vorhanden -");
		appointmentScroll.addView(appointmentTV);
	}

}

