package de.drk.plugin.calendar.neu;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.format.DateUtils;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import de.drk.plugin.calendar.neu.R;
import de.drk.plugin.calendar.neu.Helper.DatabaseHelper;
import de.drk.plugin.calendar.neu.Helper.DatabaseManager;
import de.drk.plugin.calendar.neu.Helper.RemoteDB;
import de.drk.template.neu.AppcenterTemplate;

/**
 * Diese Klasse zeigt alle in der lokalen Datenbank gespeicherten Termine
 * in einem ScrollView fuer jeden Tag der Woche an, es werden nur der Terminbeginn 
 * und die Terminbezeichnung angezeigt, mit einem Klick auf einen Termin wird in die 
 * Activity zum Anzeigen aller Termindaten gewechselt; es gibt zwei Buttons um
 * zwischen den einzelnen Wochen navigieren zu koennen und ein Button um in die aktuelle
 * Woche zu wechseln; ueber den NewAppointment-Button kann in die Activity zum Anlegen 
 * eines neuen Termins gewechselt werden; es wurde ausserdem der Search-Button konfiguriert, 
 * um in die Such-Activity fuer Termine wechseln zu koennen.
 * @author Alex Wetzler
 */

public class MainActivity extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	boolean threadstarted = false;
	// Differenz zur aktuell angezeigten Woche, resultiert daraus, 
	// wie oft auf WocheVor/WocheZurueck gedrueckt wurde
	int diffWeeks = 0;
	int SCROLLSPEED = 20, appointmentId = 0, clientId = 0;
	private final String SERVER_IP = "http://212.100.43.180";
	private final int NUMBER_OF_ALARMENTRIES = 52;
	// aktuelle Zeit in Millisekunden
	long curMillis; 
	int day = 0;
	LinearLayout mondayScroll = null;
	LinearLayout tuesdayScroll = null;
	LinearLayout wednesdayScroll = null;
	LinearLayout thursdayScroll = null;
	LinearLayout fridayScroll = null;
	LinearLayout saturdayScroll = null;
	LinearLayout sundayScroll = null;
	HorizontalScrollView scrollViewMonday = null;
	HorizontalScrollView scrollViewTuesday = null;
	HorizontalScrollView scrollViewWednesday = null;
	HorizontalScrollView scrollViewThursday = null;
	HorizontalScrollView scrollViewFriday = null;
	HorizontalScrollView scrollViewSaturday = null;
	HorizontalScrollView scrollViewSunday = null;	
	// Text der in dem TextView zur Wochenanzeige steht
	String textWeekTV = ""; 
	TextView weekTV = null;
	Timer syncTimer = null;
	Timer scrollTimer = null;
	Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen, setzt das Layout, konfiguriert
	 * die Layoutelemente, fuehrt fuer den Fall dass die Activiy zum ersten Mal 
	 * aufgerufen wurde (Start der App) einen Datenabgleich durch, aktualisiert 
	 * die Terminlisten (fuer jeden Wochentag der aktuell ausgewaehlten Woche) 
	 * und den Text fuer die Wochenanzeige.
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// Layout fuer diese Activity setzen
		setLayout(R.layout.main_activity);
		// Klienten-ID von der aufgerufenen Activiy uebernehmen
		intent = getIntent();
		clientId = intent.getIntExtra("clientId", 0);
		// beim ersten Start dieser Activity ist die Klienten-ID Null,
		// in diesem Fall remoteToLocal in einem Thread aufrufen 
		// um den Datenabgleich durchzufuehren
		int firstStart = intent.getIntExtra("firstStart", 0);
		if (firstStart == 1) {
			Log.d("", "onCreate mit firstStart");
			Thread thread = new Thread(){
				@Override
				public void run() {
					if(isServerReachable())
							remoteToLocal();
					else
						Log.d("Serververbindung", "Server ist nicht erreichbar.");
					threadstarted=false;
				}
			};
			if(!threadstarted){
				threadstarted=true;
				thread.start();
				try {
					thread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		// Objekte deklarieren, initialisieren und konfigurieren (setOnTochListener)
		mondayScroll = (LinearLayout) findViewById(R.id.mondayScroll);
		scrollViewMonday = (HorizontalScrollView) findViewById(R.id.scrollViewMonday);
		scrollViewMonday.setOnTouchListener(new View.OnTouchListener() {
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
				scroll(10000);
	            return false;
	        }  
        });
		tuesdayScroll = (LinearLayout) findViewById(R.id.tuesdayScroll);
		scrollViewTuesday = (HorizontalScrollView) findViewById(R.id.scrollViewTuesday);
		scrollViewTuesday.setOnTouchListener(new View.OnTouchListener() {
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
				scroll(10000);
	            return false;
	        }
        });
		wednesdayScroll = (LinearLayout) findViewById(R.id.wednesdayScroll);
		scrollViewWednesday = (HorizontalScrollView) findViewById(R.id.scrollViewWednesday);
		scrollViewWednesday.setOnTouchListener(new View.OnTouchListener() {
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
				scroll(10000);
	            return false;
	        }
		});
		thursdayScroll = (LinearLayout) findViewById(R.id.thursdayScroll);
		scrollViewThursday = (HorizontalScrollView) findViewById(R.id.scrollViewThursday);
		scrollViewThursday.setOnTouchListener(new View.OnTouchListener() {
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
				scroll(10000);
	            return false;
	        }
        });
		fridayScroll = (LinearLayout) findViewById(R.id.fridayScroll);
		scrollViewFriday = (HorizontalScrollView) findViewById(R.id.scrollViewFriday);
		scrollViewFriday.setOnTouchListener(new View.OnTouchListener() {
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
				scroll(10000);
	            return false;
	        }
        });
		saturdayScroll = (LinearLayout) findViewById(R.id.saturdayScroll);
		scrollViewSaturday = (HorizontalScrollView) findViewById(R.id.scrollViewSaturday);
		scrollViewSaturday.setOnTouchListener(new View.OnTouchListener() {
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
				scroll(10000);
	            return false;
	        }
        });
		sundayScroll = (LinearLayout) findViewById(R.id.sundayScroll);
		scrollViewSunday = (HorizontalScrollView) findViewById(R.id.scrollViewSunday);
		scrollViewSunday.setOnTouchListener(new View.OnTouchListener() {
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
				scroll(10000);
	            return false;
	        }
        });
		weekTV = (TextView) findViewById(R.id.weekTV);
		// Terminlisten (Views) aktualisieren (Inhalt der aktuell 
		// ausgewaehlten Woche in die Views legen)
		readContent(); 
		// Text fuer die Wochenanzeige aktualisieren
		weekTV.setText(textWeekTV);
	}

	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; das
	 * Layout dieser Activity verfuegt ueber vier Buttons, wovon
	 * drei Buttons (Back-/Fore-/Today-Button) das Navigieren 
	 * zwischen den einzelnen Kalenderwochen ermoeglichen; mit 
	 * dem vierten Button (New-Appointment-Button) kann in die 
	 * Terminanlage-Activity gewechselt werden, um einen neuen
	 * Termin in der lokalen Datenbank anzulegen; ausserdem wird
	 * der Such-Button des Templates konfiguriert, um darueber 
	 * die Such-Activity aufrufen zu koennen. Die Such-Activity 
	 * ist abhaengig von jeweiligen Plugin und damit nicht im 
	 * Template zentral konfiguriert.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		// zur Such-Activity wechseln
		case (R.id.searchButton):	
			intent = new Intent(this, SearchAppointments.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			break;
		// zur Terminanlage-Activity wechseln
		case (R.id.newAppointmentButton):
			intent = new Intent(this, AddEditAppointment1.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			break;
		// zur aktuellen Kalenderwoche wechseln, dabei den
		// Inhalt der TextViews zur Terminanzeige aktualisieren
		case (R.id.todayButton):
			diffWeeks = 0;
			readContent();
			weekTV.setText(textWeekTV);
			break;
		// zur nachfolgenden Kalenderwoche wechseln, dabei den
		// Inhalt der TextViews zur Terminanzeige aktualisieren
		case (R.id.foreButton):
			diffWeeks++;
			readContent();
			weekTV.setText(textWeekTV);
			break;
		// zur vorhergehenden Kalenderwoche wechseln, dabei den
		// Inhalt der TextViews zur Terminanzeige aktualisieren
		case (R.id.backButton):
			diffWeeks--;
			readContent();
			weekTV.setText(textWeekTV);
			break;
		// Aktionen ausfuehren, die fuer die Buttons im Template 
		// konfiguriert wurden	
		default:
			super.onButtonClick(view);
			break;
		}
	}

	/**
	 * Diese Methode findet die jeweilige Woche, die sich ergibt,
	 * wenn die Klicks auf die Button Vor/Zurueck im Layout
	 * beruecksichtigt werden; damit wird zum einen die Variable 
	 * curMillis gesetzt (Datum des Wochenbeginns in Millisekunden)
	 * und zum anderen der TextView im Layout, der die Woche
	 * anzeigt, in der man sich gegenwaertig befindet; wird jedesmal 
	 * in der Methode readContent aufgerufen, also sobald die
	 * Terminanzeige aktualisiert werden soll.
	 */
	private void beginningOfTheWeek() {
		// Calender-Objekt erzeugen und auf die aktuelle Zeit setzen
		Calendar now = Calendar.getInstance();
		now.setTime(now.getTime());
		// Calender-Objekt auf das Datum stellen, dass sich ergibt,
		// wenn die Klicks auf die Buttons Vor/Zurueck beruecksichtigt werden
		now.add(Calendar.DAY_OF_YEAR, diffWeeks * 7);
		// Calender-Objekt auf den Montag der jeweiligen Woche setzen
		now.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		// Dieses Datum als Wochenbeginn in speziellen Format zwischenspeichern
		Date date = now.getTime();
		curMillis = now.getTimeInMillis();
		String mondayOfWeek = new SimpleDateFormat("dd.", Locale.GERMANY)
				.format(date);
		// Calender-Objekt auf den Sonntag der jeweiligen Woche setzen
		now.add(Calendar.DAY_OF_YEAR, 6);
		// Dieses Datum als Wochenende in speziellen Format zwischenspeichern
		date = now.getTime();
		String sundayOfWeek = new SimpleDateFormat("dd. MMMM yyyy",
				Locale.GERMANY).format(date);
		// Aus dem Wochenbeginn- und ende den Text fuer das TextView erzeugen
		textWeekTV = mondayOfWeek + " bis " + sundayOfWeek;
	}

	/**
	 * Diese Methode entfernt alle TextViews mit den
	 * einzelnen Termineintraegen von den LinearLayouts
	 * fuer die aktuell angezeigte Woche.
	 */
	private void clearAppointments() {
		mondayScroll.removeAllViews();
		tuesdayScroll.removeAllViews();
		wednesdayScroll.removeAllViews();
		thursdayScroll.removeAllViews();
		fridayScroll.removeAllViews();
		saturdayScroll.removeAllViews();
		sundayScroll.removeAllViews();
	}

	/**
	 * Diese Methode wird ausgefuehrt wenn die Activity aufgebaut wurde;
	 * der Aufruf der Scroll-Methode wird erst dann ausgefuehrt, wenn alle 
	 * Views aufgebaut sind und damit die Laenge der Views abgefragt werden 
	 * kann; dies ist notwendig weil die Views dynamisch erstellt werden
	 * und deren Groesse vom Inhalt abhaengt.
	 */
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		scroll(0);
	}

	/**
	 * Diese Methode wird beim Start dieser Activity und nach jedem Datenabgleich
	 * aufgerufen, es wird ueber die Methode beginningOfTheWeek die aktuell
	 * ausgewaehlte Woche ermittelt, die Termin-Views ueber die Methode clearAppointments
	 * entfernt, die neuen Termindaten aus der Datenbank geholt und die Termin-Views
	 * abhaengig von der Wiederholungsangabe und der aktuell ausgewaehlten Woche erzeugt;
	 * das Erzeugen der TextViews und die Zuweisung auf die einzelnen LinearLayouts
	 * erfolgt ueber die Methode createTextView.
	 */
	private void readContent() {
		// aktuell ausgewaehlte Woche ermitteln
		beginningOfTheWeek();
		 // Views fuer die einzelnen Termine entfernen
		clearAppointments();
		// aktuelle Termindaten (ID, Bezeichnung, Beschreibung, Telefonnummer,
		// Terminbeginn, Ganztagsangabe, Wiederhoungsangabe, Klassifizierungsangabe)
		// aus der Datenbank holen
		String[] idString = db.getIds();
		String[] titleString = db.getTitles();
		String[] startString = db.getStartDts();
		String[] alldayString = db.getAllDays();
		String[] recurrenceString = db.getRecurrences();
		String[] carerEntryString = db.getCarerEntries();		
		// Fuer jeden Termin abhaengig von der Wiederholungsangabe
		// und der aktuell ausgewaehlten Woche keinen, einen oder
		// sieben TextViews ueber die Methode createTextView erzeugen
		Calendar calStart = Calendar.getInstance();	
		for (int i = 0; i < db.getNumberOfAppointments(); i++) {
			try {
				calStart.setTime(new SimpleDateFormat("dd.MM.yyyy HH:mm",
						Locale.GERMANY).parse(startString[i]));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			// Text des TextViews festlegen
			String hourStart = String.valueOf(calStart.get(Calendar.HOUR_OF_DAY));
			String minuteStart = String.valueOf(calStart.get(Calendar.MINUTE));
			if (calStart.get(Calendar.MINUTE) < 10)
				minuteStart = "0" + minuteStart;
			int dayStart = calStart.get(Calendar.DAY_OF_WEEK)-1;	
			if (dayStart == 0) 
				dayStart = 7; // Sonntag;
			Log.d("", "dayStart/title: " +dayStart+ "/" +titleString[i]);
			String text = "";
			if (alldayString[i].equals("0")) // nicht ganztaetig
				text = hourStart+ ":" +minuteStart+ " - " +titleString[i];
			else if (alldayString[i].equals("1")) // ganztaetig
				text = titleString[i];
			// Termin soll taeglich wiederholt werden, also sieben TextViews erstellen
			if(recurrenceString[i].equals("taeglich")) {
				for(int j=1; j<=7; j++)
					createTextView(Integer.parseInt(idString[i])*10+j, text, carerEntryString[i], j);	
			}
			// Termin soll woechentlich wiederholt werden, also ein TextView erstellen
			else if (recurrenceString[i].equals("woechentlich"))
				createTextView(Integer.parseInt(idString[i])*10, text, carerEntryString[i], dayStart);
			// Termin soll monatlich wiederholt werden, also abhaengig von der aktuell
			// ausgewaehlten Woche ein TextView erstellen oder nicht
			else if (recurrenceString[i].equals("monatlich")) {
				int startDay = calStart.get(Calendar.DAY_OF_MONTH);
				Calendar curWeekStart = Calendar.getInstance();
				curWeekStart.setTimeInMillis(curMillis);
				int curWeekFirstDay = curWeekStart.get(Calendar.DAY_OF_MONTH);
				Calendar curWeekEnd = Calendar.getInstance();
				curWeekEnd.setTimeInMillis(curMillis + 604800000);
				int curWeekLastDay = curWeekEnd.get(Calendar.DAY_OF_MONTH)-1;
				Log.d("", "startDay/curWeekFirstDay/curWeekLastDay: " +startDay+ "/" +curWeekFirstDay+ "/" +curWeekLastDay);
				if (curWeekLastDay > curWeekFirstDay) {
					for(int j=curWeekFirstDay; j<=curWeekLastDay; j++){
						day++;
						if (j == startDay)
							createTextView(Integer.parseInt(idString[i])*10, text, carerEntryString[i], day);
					}
					day = 0;
				}
				else {
					for(int j=curWeekFirstDay; j<=curWeekStart.getActualMaximum(Calendar.DAY_OF_MONTH); j++){
						day++;
						if (j == startDay)
							createTextView(Integer.parseInt(idString[i])*10, text, carerEntryString[i], day);
					}
					for(int j=1; j<=curWeekLastDay; j++) {
						day++;
						if (j == startDay)
							createTextView(Integer.parseInt(idString[i])*10, text, carerEntryString[i], day);
					}
					day = 0;
				}
			}
			// Termin soll jaehrlich wiederholt werden, also abhaengig von der aktuell
			// ausgewaehlten Woche ein TextView erstellen oder nicht
			else if (recurrenceString[i].equals("jaehrlich")) {
				int startDay = calStart.get(Calendar.DAY_OF_MONTH);
				int startMonth = calStart.get(Calendar.MONTH)+1;
				Calendar curWeekStart = Calendar.getInstance();
				curWeekStart.setTimeInMillis(curMillis);
				int curWeekFirstDay = curWeekStart.get(Calendar.DAY_OF_MONTH);
				int curWeekStartMonth = curWeekStart.get(Calendar.MONTH)+1;
				Calendar curWeekEnd = Calendar.getInstance();
				curWeekEnd.setTimeInMillis(curMillis + 604800000);
				int curWeekLastDay = curWeekEnd.get(Calendar.DAY_OF_MONTH)-1;
				int curWeekEndMonth = curWeekEnd.get(Calendar.MONTH)+1;
				Log.d("", "startDay/startMonth/curWeekFirstDay/curWeekStartMont/curWeekLastDay/curWeekEndMonth: " +startDay+ "/" +startMonth+ "/" +curWeekFirstDay+ "/" +curWeekStartMonth+ "/" +curWeekLastDay+ "/" +curWeekEndMonth);
				if (curWeekLastDay > curWeekFirstDay) {
					for(int j=curWeekFirstDay; j<=curWeekLastDay; j++){
						day++;
						if (j == startDay && startMonth == curWeekStartMonth)
							createTextView(Integer.parseInt(idString[i])*10, text, carerEntryString[i], day);
					}
					day = 0;
				}
				else {
					for(int j=curWeekFirstDay; j<=curWeekStart.getActualMaximum(Calendar.DAY_OF_MONTH); j++){
						day++;
						if (j == startDay && startMonth == curWeekStartMonth)
							createTextView(Integer.parseInt(idString[i])*10, text, carerEntryString[i], day);
					}
					for(int j=1; j<=curWeekLastDay; j++) {
						day++;
						if (j == startDay && startMonth == curWeekEndMonth)
							createTextView(Integer.parseInt(idString[i])*10, text, carerEntryString[i], day);
					}
					day = 0;
				}
			}
			// Termin soll nicht wiederholt werden, also ein TextView erstellen
			else if (recurrenceString[i].equals("keine")) {
				if ((calStart.getTimeInMillis() > curMillis)
						&& (calStart.getTimeInMillis() < curMillis + (1000*60*60*24*7)))
					createTextView(Integer.parseInt(idString[i])*10, text, carerEntryString[i], dayStart);	
			}
		}
	}

	/**
	 * Dieser Methode wird die ID, der Text, die Klassifizierung und der Tag
	 * eines zu erstellenden TextView-Objekts uebergeben; daraufhin wird der
	 * TextView erstellt und deren Attribute gesetzt; schliesslich wird das
	 * TextView einem der sieben LinearLayouts (Montag - Freitag) hinzugefuegt.
	 * @param id ist die ID des zu erstellenden TextViews
	 * @param text ist der Text des zu erstellenden TextViews
	 * @param carerentry bestimmt die Hintergrundfarbe des zu erstellenden TextViews
	 * @param day bestimmt zu welchem LinearLayout das zu erstellende TextView
	 * hinzugefuegt wird
	 */
	private void createTextView(int id, String text, String carerentry, int day) {
		// TextView-Objekt erstellen und deren Attribute setzen
		TextView textview = new TextView(this);
		// Farbe des TexViews festlegen
		if (carerentry.equals("0"))
			textview.setBackgroundResource(R.drawable.cell_shape_0);
		else if (carerentry.equals("1"))
			textview.setBackgroundResource(R.drawable.cell_shape_1);
		else if (carerentry.equals("2"))
			textview.setBackgroundResource(R.drawable.cell_shape_2);
		textview.setPadding(10, 15, 10, 15);
		textview.setTextAppearance(this, android.R.style.TextAppearance_Large);
		textview.setTextColor(getResources().getColor(R.color.textColorWeekdays));
		textview.setTextSize(getResources().getDimension(R.dimen.textSizeWeekdays));
		textview.setClickable(true);
		// ID des TextViews festlegen (ist mit der Termin-ID verknuepft)
		textview.setId(id);
		// onClickListener fuer das TextView setzen, damit bei einem Klick
		// zu der Activity fuer die Termindatenanzeige (AppointmentData)
		// gewechselt wird; dieser wird insbes. die Termin-ID uebergeben
		textview.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {		
				intent = new Intent(MainActivity.this, AppointmentData.class);
				intent.putExtra("appointmentId", v.getId()/10);
				intent.putExtra("clientId", clientId);
				startActivity(intent);
			}
		});
		textview.setText(text);
		// TextView je nach Wert von day einem LinearLayout hinzufuegen
		switch (day) {
		case 1:
			mondayScroll.addView(textview);
			break;
		case 2:
			tuesdayScroll.addView(textview);
			break;
		case 3:
			wednesdayScroll.addView(textview);
			break;
		case 4:
			thursdayScroll.addView(textview);
			break;
		case 5:
			fridayScroll.addView(textview);
			break;
		case 6:
			saturdayScroll.addView(textview);
			break;
		case 7:
			sundayScroll.addView(textview);
			break;
		// ungueltigen Wert fuer day abfangen und Meldung
		// fuer den Benutzer ausgeben
		default:
			Toast toast = Toast.makeText(
					getApplicationContext(),
					"Die Termine koennen aufgrund eines Fehlers nicht angezeigt werden!",
					Toast.LENGTH_LONG);
			LinearLayout toastLayout = (LinearLayout) toast.getView();
			TextView toastTV = (TextView) toastLayout.getChildAt(0);
			toastTV.setTextSize(34);
			toast.show();
			break;
		}
	}

	/**
	 * Diese Methode sorgt fuer das automatischen Scrollen der Termin-Views
	 * in einer bestimmten Geschwindigkeit; das Scrollen wird ueber einen
	 * Timer alle x Sekunden (wird ueber die Konstante SCROLLSPEED festgelegt)
	 * im UI-Thread ausgefuehrt; zusaetzlich kann ueber den Parameter delay die
	 * Ausfuehrung verzoegert werden; fuer das Scrollen wird der View mit der
	 * maximalen Laenge gesucht, damit sich alle Termin-Views auf derselben
	 * Hoehe befinden.
	 * @param delay gibt die Verzoegerung des Timers in Millisekunden an
	 */
	public void scroll(long delay) {
		// wenn der Timer fuer den Scroll-Task schon eingerichtet
		// wurde, diesen beenden und neu einrichten
		if(scrollTimer != null)
			scrollTimer.cancel();
		// TimerTask-Objekt erstellen und im UI-Thread laufen lassen
		TimerTask scrollTask = new TimerTask() {
			int i = 0;
			boolean right = true;
			int[] longestView = new int[7];
			int maxView = 0;
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						// View mit der groessten Laenge ermitteln
						longestView[0] = mondayScroll.getWidth()
								- scrollViewMonday.getMaxScrollAmount() - 300;
						longestView[1] = tuesdayScroll.getWidth()
								- scrollViewTuesday.getMaxScrollAmount() - 300;
						longestView[2] = wednesdayScroll.getWidth()
								- scrollViewWednesday.getMaxScrollAmount() - 300;
						longestView[3] = thursdayScroll.getWidth()
								- scrollViewThursday.getMaxScrollAmount() - 300;
						longestView[4] = fridayScroll.getWidth()
								- scrollViewFriday.getMaxScrollAmount() - 300;
						longestView[5] = saturdayScroll.getWidth()
								- scrollViewSaturday.getMaxScrollAmount() - 300;
						longestView[6] = sundayScroll.getWidth()
								- scrollViewSunday.getMaxScrollAmount() - 300;
						for (int j = 0; j < longestView.length; j++) {
							if (maxView < longestView[j])
								maxView = longestView[j];
						}
						// naechste x-Position ermitteln (links oder rechts)
						if (right == true && i <= maxView)
							i++;
						else {
							right = false;
							i--;
							if (i == 0)
								right = true;
						}
						// Scroll-Views auf die naechste Position bewegen
						// i entspricht der x-Position
						scrollViewMonday.scrollTo(i, 0);
						scrollViewTuesday.scrollTo(i, 0);
						scrollViewWednesday.scrollTo(i, 0);
						scrollViewThursday.scrollTo(i, 0);
						scrollViewFriday.scrollTo(i, 0);
						scrollViewSaturday.scrollTo(i, 0);
						scrollViewSunday.scrollTo(i, 0);
					}
				});
			}
		};
		// Timer-Objekt erzeugen und mit dem Scroll-Task konfigurieren
	    scrollTimer = new Timer();
	    scrollTimer.schedule(scrollTask, delay, SCROLLSPEED);
	}
	
	/**
	 * Diese Methode setzt einen TimerTask fuer das regelmaessige
	 * Ausfuehren der sync-Methode, die den Datenabgleich steuert;
	 * regelmaessig bedeutet, dass die Methode in einem separaten
	 * Thread alle 10 Sekunden aufgerufen wird; zu Beginn wird
	 * ueberprueft, ob dieser TimerTask schon existiert, ist dies
	 * der Fall, wird er beendet und neu angelegt.
	 */
	public void setSyncTask(){
		if(syncTimer != null)
			syncTimer.cancel();
		TimerTask syncTask = new TimerTask() {
			public void run() {		
				sync();														
			}
		};
		syncTimer = new Timer();
		syncTimer.schedule(syncTask, 0, 10000); 
	}
	
	/**
	 * Diese Methode erstellt zu Beginn einen neuen Thread
	 * und ueberprueft darin ob eine Verbindung zum Server
	 * besteht, ist dies der Fall, wird ueberprueft, ob sich
	 * die Daten fuer den jeweiligen Klienten in der
	 * Serverdatenbank geaendert haben, also das Flag gesetzt
	 * ist, ist dies der Fall, wird die lokale Datenbank
	 * aktualisiert; anschliessend wird die Terminansicht
	 * aktualisiert, indem die TextViews fuer die Termine
	 * geloescht und neu angelegt werden.
	 */
	private void sync(){
		// ist die Klienten-ID gueltig, d.h. ungleich Null,
		// wird das �berpruefen auf Datenaenderung und der
		// Datenabgleich in einem separaten Thread durchgefuehrt
		if(clientId != 0){
			Thread thread = new Thread() {
				@Override
				public void run() {
					// besteht eine Verbindung zum Server, wird ueberprueft
					// ob sich die Daten fuer den jeweiligen Klienten
					// in der Serverdatenbank geaendert haben
					if(isServerReachable()){
						boolean serverConfigChanged = RemoteDB.checkConfigChanges(clientId, "Appointment");
						Log.d("", "sync");
						Log.d("", "clientId: " +clientId);
						// haben sich die Daten gaendert, wird die Methode
						// remotToLocal aufgerufen, um zu den Datenabgleich
						// durchzufuehren
						if(serverConfigChanged){
							Log.d("", "serverConfigChanged");
							RemoteDB.setChangeFlag(clientId,"Appointment",0);		
							remoteToLocal();
							// nach dem Datenabgleich werden die TextViews ueber die
							// Methode readContent neu erstellt (muss in einem
							// separaten Thread ausgefuehrt werden, weil es die UI
							// betrifft)
							runOnUiThread(new Runnable(){
								@Override
								public void run(){
									readContent();
								}
							});
						}
					}
					else
						Log.d("Serververbindung", "Server ist nicht erreichbar.");
					threadstarted=false;
				}
			};
			// ist der Thread fuer die �berpruefung und den Datenabgleich
			// noch nicht gestartet, wird er gestartet und es wird
			// gewartet bis er beendet wurde
			if(!threadstarted){
				threadstarted=true;
				thread.start();
				try {
					thread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Diese Methode prueft, ob das Geraet eine Verbindung zum Server
	 * herstellen kann und liefert true, wenn die Verbindung zu
	 * stande kommt, andernfalls false. 
	 * @return gibt true oder false zurueck, je nachdem ob die
	 * Verbindung besteht oder nicht
	 */
	public boolean isServerReachable() {
		// ConnectivityManager-Objekt erzeugen, um damit wiedderum
		// ein NetworkInfo-Objekt erzeugen zu koennen, das zurueckliefern
		// kann, ob eine Netzwerkverbindung besteht oder nicht
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		// besteht eine Netzwerkverbindung, dann ein HttpURLConnection-
		// Objekt erzeugen, um sich mit der IP-Adresse des Servers
		// verbinden zu koennen, kommt eine Verbindung zu stande wird
		// true zurueckgeliefert, andernfalls false
		if (netInfo != null && netInfo.isConnected()) {
			try {
				URL url = new URL(SERVER_IP);
				HttpURLConnection urlc = (HttpURLConnection) url
						.openConnection();
				urlc.setConnectTimeout(10 * 1000);
				urlc.connect();
				if (urlc.getResponseCode() == 200)
					return true;
				else
					return false;
			} catch (MalformedURLException e1) {
				return false;
			} catch (IOException e) {
				return false;
			}
		}
		return false;
	}

	/**
	 * Diese Methode loescht alle Termine aus der lokalen Datenbank,
	 * die vom Server kommen (Klienten- und Gruppentermine) sowie 
	 * deren Alarmeintraege; anschliessend werden die Termine mit Hilfe der 
	 * RemoteDB-Klasse erneut vom Server bezogen, um die aktuellen Daten 
	 * zu erhalten; schliesslich werden sie mit Hilfe der DatabaseHelper-Klasse
	 * zu der lokalen Datenbank hinzugefuegt als auch die Alarmeintraege erstellt.
	 */
	private void remoteToLocal() {
		// Methoden removeCarerAlarms und deleteCarerAppointments aufrufen
		// um alle Alarm- und Termineintraege fuer diejenigen Termine zu 
		// loeschen, die vom Server kommen (Klienten-/Gruppentermine)
		removeCarerAlarms();
		db.deleteCarerAppointments();
		// Ist die gegenwaertige Klienten-ID gueltig, dann Klienten- und
		// Gruppentermine ueber die RemoteDB-Klasse neu beziehen
		// (als JSONArray-Objekt), die jeweiligen Daten extrahieren
		// und ueber die addAppointment-Methode der DatabaseHelper-Klasse
		// in der lokalen Datenbank anlegen
		if(clientId != 0){
			JSONArray userAppointments = RemoteDB.getUserAppointments(clientId);
			JSONArray groupAppointments = RemoteDB.getGroupAppointments(clientId);
		    Random randomGenerator = new Random();
			try {
				// Kliententermine
				if (userAppointments != null) {
					for (int i = 0; i < userAppointments.length(); i++) {
						// Termin hinzufuegen
						JSONObject c = userAppointments.getJSONObject(i);
						String notification = c.getString("NOTIFICATION");
						int notId = randomGenerator.nextInt(10000000);
						db.addAppointment(c.getString("TITLE"),
								c.getString("DESCRIPTION"), c.getString("LOCATION"),
								c.getString("PRIORITY"), c.getString("STARTDT"), 
								c.getString("ENDDT"), notification,
								Integer.toString(notId), "0", c.getString("RECURRENCE"), "1");
						// Alarm hinzufuegen
						SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
						Date date = new Date();
				    	try {
							if(db.getRecurrenceByNotId(notId).equals("taeglich")) {
								Calendar notCal = Calendar.getInstance();
								notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
								for(int i1=0; i1<NUMBER_OF_ALARMENTRIES; i1++) {
									if(notCal.getTime().compareTo(date) > 0) {
										addAlarm(notId+i1, notCal.getTime());
										notCal.add(Calendar.DATE, 1);
									}
								}
							}
							else if (db.getRecurrenceByNotId(notId).equals("woechentlich")) {
								Calendar notCal = Calendar.getInstance();
								notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
								for(int i1=0; i1<NUMBER_OF_ALARMENTRIES; i1++) {
									if(notCal.getTime().compareTo(date) > 0) {
										addAlarm(notId+i1, notCal.getTime());
										notCal.add(Calendar.WEEK_OF_YEAR, 1);
									}
								}
							}
							else if (db.getRecurrenceByNotId(notId).equals("monatlich")) {
								Calendar notCal = Calendar.getInstance();
								notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
								for(int i1=0; i1<NUMBER_OF_ALARMENTRIES; i1++) {
									if(notCal.getTime().compareTo(date) > 0) {
										addAlarm(notId+i1, notCal.getTime());
										notCal.add(Calendar.MONTH, 1);
									}
								}
							}
							else if (db.getRecurrenceByNotId(notId).equals("jaehrlich")) {
								Calendar notCal = Calendar.getInstance();
								notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
								for(int i1=0; i1<NUMBER_OF_ALARMENTRIES; i1++) {
									if(notCal.getTime().compareTo(date) > 0) {
										addAlarm(notId+i1, notCal.getTime());
										notCal.add(Calendar.YEAR, 1);
									}
								}
							}
							else if(sdf.parse(db.getNotDtByNotId(notId)).compareTo(date) > 0)
								addAlarm(notId, sdf.parse(db.getNotDtByNotId(notId)));
						} catch (ParseException e) {
							e.printStackTrace();
						}
					}
				}
				// Gruppentermine
				if (groupAppointments != null) {
					for (int i = 0; i < groupAppointments.length(); i++) {
						// Termin hinzufuegen
						JSONObject c = groupAppointments.getJSONObject(i);
						if (!db.groupAppointmentExists(c.getString("TITLE"), c.getString("STARTDT"), c.getString("ENDDT"))) {
							String notification = c.getString("NOTIFICATION");
							int notId = randomGenerator.nextInt(10000000);
							db.addAppointment(c.getString("TITLE"),
									c.getString("DESCRIPTION"), c.getString("LOCATION"),
									c.getString("PRIORITY"), c.getString("STARTDT"), 
									c.getString("ENDDT"), notification,
									Integer.toString(notId), "0", c.getString("RECURRENCE"), "2");
							// Alarm hinzufuegen
							SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
							Date date = new Date();
					    	try {
								if(db.getRecurrenceByNotId(notId).equals("taeglich")) {
									Calendar notCal = Calendar.getInstance();
									notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
									for(int i1=0; i1<NUMBER_OF_ALARMENTRIES; i1++) {
										if(notCal.getTime().compareTo(date) > 0) {
											addAlarm(notId+i1, notCal.getTime());
											notCal.add(Calendar.DATE, 1);
										}
									}
								}
								else if (db.getRecurrenceByNotId(notId).equals("woechentlich")) {
									Calendar notCal = Calendar.getInstance();
									notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
									for(int i1=0; i1<NUMBER_OF_ALARMENTRIES; i1++) {
										if(notCal.getTime().compareTo(date) > 0) {
											addAlarm(notId+i1, notCal.getTime());
											notCal.add(Calendar.WEEK_OF_YEAR, 1);
										}
									}
								}
								else if (db.getRecurrenceByNotId(notId).equals("monatlich")) {
									Calendar notCal = Calendar.getInstance();
									notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
									for(int i1=0; i1<NUMBER_OF_ALARMENTRIES; i1++) {
										addAlarm(notId+i1, notCal.getTime());
										notCal.add(Calendar.MONTH, 1);
									}
								}
								else if (db.getRecurrenceByNotId(notId).equals("jaehrlich")) {
									Calendar notCal = Calendar.getInstance();
									notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
									for(int i1=0; i1<NUMBER_OF_ALARMENTRIES; i1++) {
										if(notCal.getTime().compareTo(date) > 0) {
											addAlarm(notId+i1, notCal.getTime());
											notCal.add(Calendar.YEAR, 1);
										}
									}
								}
								else if(sdf.parse(db.getNotDtByNotId(notId)).compareTo(date) > 0)
									addAlarm(notId, sdf.parse(db.getNotDtByNotId(notId)));
							} catch (ParseException e) {
								e.printStackTrace();
							}
					}
				}
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		else
			Log.d("", "Client-ID == 0");
		
	}
	
	/**
	 * Dise Methode erstellt einen einzelnen Alarmeintrag (Pending-Intent)
	 * fuer einen Termin; dazu werden die Alarm-ID und das Alarmdatum als 
	 * Parameter uebergeben.
	 * @param alarmid ist die ID des Alarms, der angelegt werden soll
	 * @param alarmdt ist das Datum des Alarms, der angelegt werden soll
	 */
	private void addAlarm(int alarmid, Date alarmdt) {
		// Intent zum Wechseln in die Alarm-Activity erstellen
		Intent intent = new Intent(this, AlarmReceiver.class);
		// Daten zum Intent hinzufuegen (Alarm-ID/-Datum)
		intent.putExtra("alarmid", alarmid);
		intent.putExtra("alarmdt", alarmdt.getTime());
		// aus dem angelegten Intent ein Pending-Intent erstellen
		PendingIntent pIntent = PendingIntent.getActivity(this, alarmid, intent, 
				PendingIntent.FLAG_CANCEL_CURRENT);
		// AlarmManager-Objekt erstellen und damit den Alarm einstellen
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		am.set(AlarmManager.RTC_WAKEUP, alarmdt.getTime(), pIntent);
		Log.d("", "Benachrichtigung eingestellt fuer Alarm-ID " +alarmid+ " am " +alarmdt+ "!");
	}
	
	/**
	 * Dise Methode loescht die Alarmeintraege (Pending-Intents) fuer Servertermine,
	 * also Klienten- und Gruppentermine; handelt es sich bei dem jeweiligen Termin 
	 * um einen Serientermin (wird periodisch wiederholt), werden insgesamt 52 
	 * Alarmeintraege geloescht (diese Anzahl von Alarmeintraegen wird beim Erstellen 
	 * eines Serientermins automatisch angelegt). 
	 */
	private void removeCarerAlarms() {
		// Intent zum Wechseln in die Alarm-Activity erstellen
		Intent intent = new Intent(this, AlarmReceiver.class);
		// AlarmManager-Objekt erstellen
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		// Alarm-IDs zu Serverterminen (Klienten-/Gruppenterminen) holen
		ArrayList<Integer> notIds = db.getCarerNotIds();
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
		Date date = new Date();
		// ueber die Alarm-IDs iterieren und die Alarmeintraege loeschen
		for(int i = 0; i < notIds.size(); i++) {
	    	try {
	    		// Termin wird periodisch wiederholt
	    		if(!db.getRecurrenceByNotId(notIds.get(i)).equals("keine")) {
	    			for(int j=0; j<NUMBER_OF_ALARMENTRIES; j++) {
	    				PendingIntent pIntent = PendingIntent.getActivity(this, notIds.get(i)+j, intent, 0);
	    				am.cancel(pIntent);
	    				Log.d("", "Benachrichtigung mit Alarm-ID " +notIds.get(i)+j+ " faellig am " +db.getNotDtByNotId(notIds.get(i))+ " geloescht!");
	    			}
				}
	    		// Termin wird nicht periodisch wiederholt
	    		else if((sdf.parse(db.getNotDtByNotId(notIds.get(i))).compareTo(date) > 0)) {
					Log.d("", "Benachrichtigung mit Alarm-ID " +notIds.get(i)+ " faellig am " +db.getNotDtByNotId(notIds.get(i))+ " geloescht!");
					PendingIntent pIntent = PendingIntent.getActivity(this, notIds.get(i), intent, 0);
					am.cancel(pIntent);
				}
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}	
	}

	/**
	 * Die Methode wird ausgefuehrt, wenn die Main-Activity
	 * fuer den Benutzer sichtbar wird; hier wird die 
	 * onStart-Methode der Superklasse aufgerufen als auch die
	 * Methode zur Erstellung des Tasks fuer den Datenabgleich.
	 */
	@Override
	public void onStart(){																
		super.onStart();
		setSyncTask();
	}
	
	/**
	 * Die Methode wird ausgefuehrt, wenn die Main-Activity
	 * fuer den Benutzer nicht sichtbar wird; hier wird
	 * die onStart-Methode der Superklasse aufgerufen und der
	 * Timer fuer die Datenabgleich mit dem Server gestoppt.
	 */
	@Override
	public void onStop(){																
		super.onStart();
		if(syncTimer != null)
			syncTimer.cancel();															
	}
}
