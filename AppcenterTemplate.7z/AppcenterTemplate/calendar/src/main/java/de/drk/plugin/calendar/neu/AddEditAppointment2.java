package de.drk.plugin.calendar.neu;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Spinner;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.Random;

import de.drk.plugin.calendar.neu.Helper.DatabaseHelper;
import de.drk.template.neu.AppcenterTemplate;

/**
 * Diese Klasse stellt den zweiten Teil der Funktionalitaet zum Hinzufuegen,
 * Editieren und Loeschen von einzelnen Terminen bereit; dazu wird
 * insbesondere das Layout mit den entsprechenden Datenfeldern und
 * Buttons gesetzt; mit den Buttons kann entweder zur vorhergehenden
 * Activity gewechselt werden, um einige Terminfelder zu veraendern
 * oder den Prozess abzubrechen; mit einem anderen Button koennen
 * die eingegebenen Werte in der lokalen Datenbank gespeichert
 * und zur Main-Activity gewechselt werden.
 */

public class AddEditAppointment2 extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	int appointmentId = 0, clientId = 0;
	private final int NUMBER_OF_ALARMENTRIES = 52;
	ImageButton backButton = null;
	ImageButton saveButton = null;
	EditText locationET = null;
	Spinner prioritySpinner = null;
	Spinner notificationSpinner = null;
	Spinner durationSpinner = null;
	Spinner recurrenceSpinner = null;
	Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen, setzt das Layout, konfiguriert
	 * die Layout-Felder und holt sich, fuer den Fall dass ein Termin bearbeitet
	 * werden soll, die Daten dieses Termins aus der lokalen Datenbank; 
	 * anschliessend werden die entsprechenden Layoutfelder mit diesen Daten gefuellt. 
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// sorgt dafuer, dass die Tastatur eingeklappt bleibt
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN); 
		// Layout fuer diese Activity setzen
		setLayout(R.layout.add_edit_appointment_2);
		// Variablen und Objekte deklarieren sowie initialisieren
		appointmentId = getIntent().getIntExtra("appointmentId", 0);
		clientId = getIntent().getIntExtra("clientId", 0);
		backButton = (ImageButton) findViewById(R.id.backButton);
		saveButton = (ImageButton) findViewById(R.id.saveButton);
		locationET = (EditText) findViewById(R.id.locationET);
		prioritySpinner = (Spinner) findViewById(R.id.prioritySpinner);	
		notificationSpinner = (Spinner) findViewById(R.id.notificationSpinner);
		durationSpinner = (Spinner) findViewById(R.id.durationSpinner);
		recurrenceSpinner = (Spinner) findViewById(R.id.recurrenceSpinner);	
		ArrayAdapter adapter = ArrayAdapter.createFromResource(this, R.array.priority_arrays, R.layout.spinner_item);
		adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
		prioritySpinner.setAdapter(adapter);
		adapter = ArrayAdapter.createFromResource(this, R.array.notification_arrays, R.layout.spinner_item);
		adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
		notificationSpinner.setAdapter(adapter);
		adapter = ArrayAdapter.createFromResource(this, R.array.duration_arrays, R.layout.spinner_item);
		adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
		durationSpinner.setAdapter(adapter);
		adapter = ArrayAdapter.createFromResource(this, R.array.recurrence_arrays, R.layout.spinner_item);
		adapter.setDropDownViewResource(R.layout.spinner_dropdown_item);
		recurrenceSpinner.setAdapter(adapter);
		locationET.requestFocus();
		// dieser Activity wurden eine Termin-ID uebergeben, d.h. es soll ein bestehender
		// Termin aus der Datenbank geaendert werden, dazu muessen
		// entsprechende Termindaten geholt und die passenden TextView-Elemente
		// (Terminbezeichnung/-beschreibung/-beginn) gefuellt werden
		if (appointmentId != 0) {
			// Terminstandort setzen
			locationET.setText(db.getLocation(appointmentId));
			// Terminprioritaet setzen
			String[] priorities = getResources().getStringArray(R.array.priority_arrays);
			prioritySpinner.setSelection(Arrays.asList(priorities).indexOf(db.getPriority(appointmentId)));
			// Terminbenachrichtigung setzen
			Date startDate = null;
			Date endDate = null;
			Date notificationDate = null;
			try {
				startDate = new SimpleDateFormat("dd.MM.yyyy HH:mm",
						Locale.GERMANY).parse(db.getStartDt(appointmentId));
				endDate = new SimpleDateFormat("dd.MM.yyyy HH:mm",
						Locale.GERMANY).parse(db.getEndDt(appointmentId));
				notificationDate = new SimpleDateFormat("dd.MM.yyyy HH:mm",
						Locale.GERMANY).parse(db.getNotDtByAppId(appointmentId));
			} catch (ParseException e) {
				e.printStackTrace();
			}
			long diffMillis = startDate.getTime() - notificationDate.getTime();
			String diffMinutes = Long.toString(diffMillis / (1000 * 60));
			String[] notifications = getResources().getStringArray(R.array.notification_arrays);
			notificationSpinner.setSelection(Arrays.asList(notifications).indexOf(diffMinutes));
			// Termindauer setzen
			diffMillis = endDate.getTime() - startDate.getTime();
			Log.d("", "diffMillis:" +diffMillis);
			diffMinutes = Long.toString(diffMillis / (1000 * 60));
			String[] durations = getResources().getStringArray(R.array.duration_arrays);
			durationSpinner.setSelection(Arrays.asList(durations).indexOf(diffMinutes));
			// Angabe zur Terminwiederholung setzen
			String[] recurrences = getResources().getStringArray(R.array.recurrence_arrays);
			recurrenceSpinner.setSelection(Arrays.asList(recurrences).indexOf(db.getRecurrence(appointmentId)));
		}
		// dieser Activity wurden keine Termin-ID uebergeben, d.h. es soll ein neuer
		// Termin angelegt werden, dazu muessen die passenden TextView-Elemente
		// (Terminprioritaet/-benachrichtigung/-dauer/-wiederholung) mit voreingestellten 
		// Werten gefuellt werden
		else {
			String[] priorities = getResources().getStringArray(R.array.priority_arrays);
			prioritySpinner.setSelection(Arrays.asList(priorities).indexOf("normal"));
			String[] notifications = getResources().getStringArray(R.array.notification_arrays);
			notificationSpinner.setSelection(Arrays.asList(notifications).indexOf("30"));
			String[] durations = getResources().getStringArray(R.array.duration_arrays);
			durationSpinner.setSelection(Arrays.asList(durations).indexOf("30"));
			String[] recurrences = getResources().getStringArray(R.array.recurrence_arrays);
			recurrenceSpinner.setSelection(Arrays.asList(recurrences).indexOf("keine"));
		}
	}

	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; das
	 * Layout dieser Activity verfuegt ueber zwei Buttons
	 * zum Wechseln in die vorhergehende Main-Activity (Back-Button) 
	 * und zum Speichern des Termins (Save-Button); des Weiteren werden 
	 * Buttons des Templates neu konfiguriert bzw gesperrt, um ein 
	 * anderweitiges Navigieren zu unterbinden, solange die Terminanlage/
	 * -bearbeitung nicht abgeschlossen ist; der Back-Button des Templates 
	 * wird dahingehend neu konfiguriert, dass ein Bestaetigen zum Loeschen 
	 * des zuletzt eingegebenen Zeichens fuer den Standort des Termins fuehrt.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {	
		// zur vorhergehenden Activity wechseln (AddEdit-Activity-1)
		case (R.id.backButton2):
			finish();
			break;
		// Methode addAppointment ausfuehren und zur Main-Activity wechseln	
		case (R.id.saveButton):
			addAppointment();
			intent = new Intent(this, MainActivity.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			finish();
			break;
		// Buttons der rechten Menueleiste sperren
		case (R.id.homeButton):
			break;
		case (R.id.phoneButton):
			break;
		case (R.id.searchButton):
			break;
		// Back-Button neu konfigurieren, um letztes Zeichen von
		// Terminstandort zu loeschen
		case (R.id.backButton):
			if (locationET.getText().length() != 0) {
				String text = locationET.getText().toString();
				text = text.substring(0, text.length() - 1);
				locationET.setText(text);
			}
			break;
		// Aktionen ausfuehren, die fuer die Buttons im Template konfiguriert wurden
		default:
			super.onButtonClick(view);
			break;
		}
	}

	/**
	 * Diese Methode ermittelt zu Beginn, ob ein bestehender Termin bearbeitet
	 * oder ein neuer Termin angelegt werden soll; im ersten Fall wird zusaetzlich
	 * der Alarm- und Termineintrag geloescht; anschliessend werden die Termindaten
	 * aus den Steuerelementen ausgelesen und der Alarm- und Termineintrag in der
	 * lokalen Datenbank angelegt; handelt es sich bei dem Termin um einen
	 * Serientermin werden zusaetzlich die naechsten 52 Alarmeintraege erstellt.
	 */
	private void addAppointment() {
		// ist die zwischengespeicherte Termin-ID ungleich null, d.h. es wurde
		// ein bestehender Termin bearbeitet, wird der Alarm- und Termineintrag
		// geloescht
		if (appointmentId != 0) {
			// Alarmeintrag loeschen
			SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
			Date date = new Date();
	    	try {
				if(sdf.parse(db.getNotDtByAppId(appointmentId)).compareTo(date) > 0)
					removeAlarm(appointmentId);
			} catch (ParseException e) {
				e.printStackTrace();
			}	
			// Termineintrag loeschen
			db.deleteAppointment(appointmentId);
		}
		// Werte fuer alle Terminfelder aus den Steuerelementen auf der 
		// Benutzeroberflaeche holen
		String title = getIntent().getExtras().getString("title");
		String description = getIntent().getExtras().getString("description");
		String startYear = editString(getIntent().getExtras().getString("startYear"));
		String startMonth = editString(getIntent().getExtras().getString("startMonth"));
		String startDay = editString(getIntent().getExtras().getString("startDay"));
		String startHour = editString(getIntent().getExtras().getString("startHour"));
		String startMinute = editString(getIntent().getExtras().getString("startMinute"));	
		String location = locationET.getText().toString();
		String priority = String.valueOf(prioritySpinner.getSelectedItem());		
		String notification = String.valueOf(notificationSpinner.getSelectedItem());
		String duration = String.valueOf(durationSpinner.getSelectedItem());
		String recurrence = String.valueOf(recurrenceSpinner.getSelectedItem());
		// Werte fuer Terminbenachrichtigung/-ende in speziellem Format zusammenbauen
		Calendar cal = Calendar.getInstance();
		cal.set(Integer.parseInt(startYear), 
				Integer.parseInt(startMonth)-1, 
				Integer.parseInt(startDay),
				Integer.parseInt(startHour),
				Integer.parseInt(startMinute));
		cal.add(Calendar.MINUTE, -Integer.parseInt(notification)); 
		String notificationYear = editString(Integer.toString(cal.get(Calendar.YEAR)));
		String notificationMonth = editString(Integer.toString(cal.get(Calendar.MONTH)+1));
		String notificationDay = editString(Integer.toString(cal.get(Calendar.DAY_OF_MONTH)));
		String notificationHour = editString(Integer.toString(cal.get(Calendar.HOUR_OF_DAY)));
		String notificationMinute = editString(Integer.toString(cal.get(Calendar.MINUTE)));
		cal.add(Calendar.MINUTE, Integer.parseInt(notification)+Integer.parseInt(duration)); 
		String endYear = editString(Integer.toString(cal.get(Calendar.YEAR)));
		String endMonth = editString(Integer.toString(cal.get(Calendar.MONTH)+1));
		String endDay = editString(Integer.toString(cal.get(Calendar.DAY_OF_MONTH)));
		String endHour = editString(Integer.toString(cal.get(Calendar.HOUR_OF_DAY)));
		String endMinute = editString(Integer.toString(cal.get(Calendar.MINUTE)));
		// Wert fuer die Alarm-ID generieren
		Random randomGenerator = new Random();
		int notId = randomGenerator.nextInt(10000000);
		// Termineintrag in der lokalen Datenbank erstellen
		db.addAppointment(title, description, location, priority, 
				startDay+ "." +startMonth + "." +startYear + " " +startHour + ":" +startMinute, 
				endDay+ "." +endMonth + "." +endYear + " " +endHour + ":" +endMinute,
				notificationDay+ "." +notificationMonth + "." +notificationYear + " " +notificationHour + ":" +notificationMinute,
				Integer.toString(notId), "0", recurrence, "0");
		// Alarmeintraege hinzufuegen (bei Wiederholungsterminen werden jeweils 52
		// Alarmeintraege erstellt)
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
		Date date = new Date();
    	try {
    		// Angabe zur Terminwiederholung ist taeglich
			if(db.getRecurrenceByNotId(notId).equals("taeglich")) {
				Calendar notCal = Calendar.getInstance();
				notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
				for(int i=0; i<NUMBER_OF_ALARMENTRIES; i++) {
					addAlarm(notId+i, notCal.getTime());
					notCal.add(Calendar.DATE, 1);
				}
			}
			// Angabe zur Terminwiederholung ist woechentlich
			else if (db.getRecurrenceByNotId(notId).equals("woechentlich")) {
				Calendar notCal = Calendar.getInstance();
				notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
				for(int i=0; i<NUMBER_OF_ALARMENTRIES; i++) {
					addAlarm(notId+i, notCal.getTime());
					notCal.add(Calendar.WEEK_OF_YEAR, 1);
				}
			}
			// Angabe zur Terminwiederholung ist monatlich
			else if (db.getRecurrenceByNotId(notId).equals("monatlich")) {
				Calendar notCal = Calendar.getInstance();
				notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
				for(int i=0; i<NUMBER_OF_ALARMENTRIES; i++) {
					addAlarm(notId+i, notCal.getTime());
					notCal.add(Calendar.MONTH, 1);
				}
			}
			// Angabe zur Terminwiederholung ist jaehrlich
			else if (db.getRecurrenceByNotId(notId).equals("jaehrlich")) {
				Calendar notCal = Calendar.getInstance();
				notCal.setTime(sdf.parse(db.getNotDtByNotId(notId)));
				for(int i=0; i<NUMBER_OF_ALARMENTRIES; i++) {
					addAlarm(notId+i, notCal.getTime());
					notCal.add(Calendar.YEAR, 1);
				}
			}
			// Alarmeintrag erstellen, wenn das Alarmdatum in der Zukunft liegt
			else if(sdf.parse(db.getNotDtByNotId(notId)).compareTo(date) > 0)
				addAlarm(notId, sdf.parse(db.getNotDtByNotId(notId)));
		} catch (ParseException e) {
			e.printStackTrace();
		}
	}

    /**
     * Editiert ggf den uebergebenen String und liefert diesen zurueck; die
     * Methode wird verwendet um die Felder Terminbeginn/-ende/-benachrichtung
     * in einem bestimmten Format setzen zu koennen.
     * @param string ist der uebergebene String, der editiert werden soll
     * @return gibt den editierten String zurueck
     */
	private String editString(String string) {
		if (string.length() == 1)
			string = "0" + string;
		else if (string.length() == 0)
			string = "00";
		return string;
	}
	
	/**
	 * Dise Methode loescht ein oder mehrere Alarmeintraege (Pending-Intents)
	 * fuer einen einzelnen Termin, dessen ID als Parameter uebergeben wurde; 
	 * handelt es sich bei dem Termin um einen Serientermin (wird periodisch 
	 * wiederholt), werden insgesamt 52 Alarmeintraege geloescht (diese Anzahl 
	 * von Alarmeintraegen wird beim Erstellen eines Serientermins automatisch 
	 * angelegt). 
	 * @param appointment_id ist die ID des Termins, dessen Alarm geloescht werden soll 
	 */
	private void removeAlarm(int appointment_id) {
		// Intent zum Wechseln in die Alarm-Activity erstellen
		Intent intent = new Intent(this, AlarmReceiver.class);
		// AlarmManager-Objekt erstellen, mit dem ein Alarm geloescht werden kann
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		// Termin wird periodisch wiederholt
		if(!db.getRecurrence(appointment_id).equals("keine")) {
			// 52 Alarmeintraege (Pending-Intents) loeschen
			for(int i=0; i<NUMBER_OF_ALARMENTRIES; i++) {
				int not_id = Integer.parseInt(db.getNotId(appointment_id))+i;
				PendingIntent pIntent = PendingIntent.getActivity(this, not_id, intent, 0);
				am.cancel(pIntent);
				Log.d("", "Benachrichtigung mit Alarm-ID " +Integer.toString(not_id)+ " faellig am " +db.getNotDtByAppId(appointment_id)+ " geloescht!");
			}
		}
		// Termin wird nicht periodisch wiederholt
		else {
			// Alarm-Eintrag (Pending-Intent) loeschen
			PendingIntent pIntent = PendingIntent.getActivity(this, Integer.parseInt(db.getNotId(appointment_id)), intent, 0);
			am.cancel(pIntent);
			Log.d("", "Benachrichtigung mit Alarm-ID " +db.getNotId(appointment_id)+ " faellig am " +db.getNotDtByAppId(appointment_id)+ " geloescht!");
		}	
	}
	
	/**
	 * Dise Methode erstellt einen einzelnen Alarmeintrag (Pending-Intent)
	 * fuer einen Termin; dazu werden die Alarm-ID und das Alarmdatum als 
	 * Parameter uebergeben.
	 * @param alarmid ist die ID des Alarms, der angelegt werden soll
	 * @param alarmdt ist das Datum des Alarms, der angelegt werden soll
	 */
	private void addAlarm(int alarmid, Date alarmdt) {
		// Intent zum Wechseln in die Alarm-Activity erstellen
		Intent intent = new Intent(this, AlarmReceiver.class);
		// Daten zum Intent hinzufuegen (Alarm-ID/-Datum)
		intent.putExtra("alarmid", alarmid);
		intent.putExtra("alarmdt", alarmdt.getTime());
		// aus dem angelegten Intent ein Pending-Intent erstellen
		PendingIntent pIntent = PendingIntent.getActivity(this, alarmid, intent, 
				PendingIntent.FLAG_CANCEL_CURRENT);
		// AlarmManager-Objekt erstellen und damit den Alarm einstellen
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		am.set(AlarmManager.RTC_WAKEUP, alarmdt.getTime(), pIntent);
		Log.d("", "Benachrichtigung eingestellt fuer Alarm-ID " +alarmid+ " am " +alarmdt+ "!");
	}
}
