/**
* Enthaelt Helper-Klassen, die den Activity-Klassen zahlreiche Methoden zur
* Verfuegung stellen (insbesondere Methoden fuer den Datenbankzugriff und
* den Datenabgleich).
*/
package de.drk.plugin.calendar.neu.Helper;