package de.drk.plugin.calendar.neu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import de.drk.plugin.calendar.neu.Helper.DatabaseHelper;
import de.drk.template.neu.AppcenterTemplate;

/**
 * Diese Klasse stellt den ersten Teil der Funktionalitaet zum Hinzufuegen,
 * Editieren und Loeschen von einzelnen Terminen bereit; dazu wird
 * insbesondere das Layout mit den entsprechenden Datenfeldern und
 * Buttons gesetzt; mit den Buttons kann entweder zur naechsten
 * Activity gewechselt werden, um die Terminbeareitung/-anlage
 * abzuschliessen (dazu werden entsprechende Daten weitergeleitet),
 * oder es kann abgebrochen und damit zur Main-Activity gewechselt
 * werden.
 */

@SuppressWarnings("SpellCheckingInspection")
public class AddEditAppointment1 extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	int appointmentId = 0, clientId = 0;
	ImageButton forwardButton = null;
	ImageButton cancelButton = null;
	DatePicker startdatePicker = null;
	TimePicker starttimePicker = null;
	EditText titleET = null;
	EditText descriptionET = null;
	Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen, setzt das Layout, konfiguriert
	 * die Layout-Felder und holt sich, fuer den Fall dass ein Termin bearbeitet
	 * werden soll, die Daten dieses Termins aus der lokalen Datenbank; 
	 * anschliessend werden die entsprechenden Layoutfelder mit diesen Daten gefuellt. 
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// sorgt dafuer, dass die Tastatur eingeklappt bleibt
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN); 
		// Layout fuer diese Activity setzen
		setLayout(R.layout.add_edit_appointment_1);
		// Variablen und Objekte deklarieren sowie initialisieren
		appointmentId = getIntent().getIntExtra("appointmentId", 0);
		clientId = getIntent().getIntExtra("clientId", 0);
		cancelButton = (ImageButton) findViewById(R.id.cancelButton);
		forwardButton = (ImageButton) findViewById(R.id.forwardButton);
		titleET = (EditText) findViewById(R.id.titleET);
		descriptionET = (EditText) findViewById(R.id.descriptionET);	
		startdatePicker = (DatePicker) findViewById(R.id.startdatePicker);
		starttimePicker = (TimePicker) findViewById(R.id.starttimePicker);
		titleET.requestFocus();
		starttimePicker.setIs24HourView(true);
		// dieser Activity wurden Daten uebergeben, d.h. es soll ein bestehender
		// Termin aus der Datenbank geaendert werden, dazu muessen
		// entsprechende Termindaten geholt und die passenden TextView-Elemente
		// (Terminbezeichnung/-beschreibung/-beginn) gefuellt werden
		if (appointmentId != 0) {
			titleET.setText(db.getTitle(appointmentId));
			descriptionET.setText(db.getDescription(appointmentId));
			// DatePicker fuer den Terminbeginn setzen
			String startString = db.getStartDt(appointmentId);
			String[] startStringParts = startString.split(" ");
			String startDate = startStringParts[0];
			String[] startDateParts = startDate.split("\\.");
			startdatePicker.updateDate(Integer.parseInt(startDateParts[2]), Integer.parseInt(startDateParts[1])-1, 
					Integer.parseInt(startDateParts[0]));
			// TimePicker fuer den Terminbeginn setzen
			String startTime = startStringParts[1];
			String[] startTimeParts = startTime.split(":");
			starttimePicker.setCurrentHour(Integer.parseInt(startTimeParts[0]));
			starttimePicker.setCurrentMinute(Integer.parseInt(startTimeParts[1]));
		}
		// dieser Activity wurden keine Daten uebergeben, d.h. es soll ein neuer
		// Termin angelegt werden, dazu muessen die passenden TextView-Elemente
		// (Terminbeginn) mit voreingestellten Werten gefuellt werden
		else {
			Calendar now = Calendar.getInstance();
			// Kalender auf die aktuelle Zeit setzen	
			now.setTime(now.getTime()); 
			if (((int) now.get(Calendar.HOUR_OF_DAY)) == 23)
				now.add(Calendar.DATE, 1);
			startdatePicker.updateDate(now.get(Calendar.YEAR), now.get(Calendar.MONTH), 
					now.get(Calendar.DAY_OF_MONTH));
			starttimePicker.setCurrentHour(now.get(Calendar.HOUR_OF_DAY)+1);
			starttimePicker.setCurrentMinute(0);
		}
	}
	
	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; das
	 * Layout dieser Activity verfuegt ueber zwei Buttons
	 * zum Wechseln in die Main-Activity (Cancel-Button) und
	 * zum Wechseln in die AddEdit-Activity-2 (Forward-Button);
	 * des Weiteren werden Buttons des Templates neu konfiguriert
	 * bzw gesperrt, um ein anderweitiges Navigieren zu unterbinden, 
	 * solange die Terminanlage/-bearbeitung nicht abgeschlossen ist;
	 * der Back-Button des Templates wird dahingehend neu konfiguriert,
	 * dass ein Bestaetigen zum Loeschen des zuletzt eingegebenen
	 * Zeichen fuer die Terminbezeichnung/-beschreibung fuehrt.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		// Methode forwarData aufrufen, um Daten weiterzuleiten und
		// zur entsprechenden Activity zu wechseln
		case (R.id.forwardButton):
			forwardData();
			break;
		// zur Main-Activity wechseln
		case (R.id.cancelButton):
			intent = new Intent(this, MainActivity.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			finish();
			break;
		// Buttons der rechten Menueleiste sperren	
		case (R.id.homeButton):
			break;
		case (R.id.phoneButton):
			break;
		case (R.id.searchButton):
			break;
		// Back-Button neu konfigurieren, um letztes Zeichen von
		// Terminbzeichnung/-beschreibung zu loeschen
		case (R.id.backButton):
			if (titleET.getText().length() != 0) {
				String text = titleET.getText().toString();
				text = text.substring(0, text.length() - 1);
				titleET.setText(text);
			}
			else if (descriptionET.getText().length() != 0) {
				String text = descriptionET.getText().toString();
				text = text.substring(0, text.length() - 1);
				descriptionET.setText(text);
			}
			break;
		// Aktionen ausfuehren, die fuer die Buttons im Template konfiguriert wurden
		default:
			super.onButtonClick(view);
			break;
		}
	}
	
	/**
	 * Diese Methode holt sich die Werte aus den Steuerelementen
	 * (Terminbezeichnung/-beschreibung/-beginn) und speichert diese
	 * zwischen; anschliessend werden die Werte auf Gueltigkeit
	 * ueberprueft und ggf eine Meldung fuer den Benutzer ausgegeben;
	 * sind die Werte OK, wird die naechste Activity zur Terminanlage/
	 * -bearbeitung gestartet und dieser die entsprechenden Daten
	 * uebergeben.
	 */
	private void forwardData() {
		// Werte der Steuerelemente auf der Benutzeroberflaeche holen
		String title = titleET.getText().toString();
		String description = descriptionET.getText().toString();	
		String startYear = Integer.toString(startdatePicker.getYear());
		String startMonth = Integer.toString(startdatePicker.getMonth()+1);
		String startDay = Integer.toString(startdatePicker.getDayOfMonth());
		String startHour = Integer.toString(starttimePicker.getCurrentHour());
		String startMinute = Integer.toString(starttimePicker.getCurrentMinute());
		String startDate = editString(startDay)+ "." +editString(startMonth)+ "." +editString(startYear)+ " "
					+editString(startHour)+ ":" +editString(startMinute);
		SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
		Date date = new Date();
    	// Fehlerfall abfangen, dass das Feld fuer die Terminbzeichnung leer ist
		if (titleET.getText().length() == 0) {
			Toast toast = Toast.makeText(
					getApplicationContext(),
					"Bitte geben Sie eine Bezeichnung fuer den Termin ein!",
					Toast.LENGTH_LONG);
			LinearLayout toastLayout = (LinearLayout) toast.getView();
			TextView toastTV = (TextView) toastLayout.getChildAt(0);
			toastTV.setTextSize(34);
			toast.show();
		}
		// Fehlerfall abfangen, dass ein Termin mit den eingegebenen Daten bereits
		// in der Datenank existiert
		else if (db.appointmentExists(title, startDate, appointmentId)) {
			Toast toast = Toast.makeText(
					getApplicationContext(),
					"Es ist bereits ein Termin mit dieser Bezeichnung und diesem Terminbeginn vorhanden!",
					Toast.LENGTH_LONG);
			LinearLayout toastLayout = (LinearLayout) toast.getView();
			TextView toastTV = (TextView) toastLayout.getChildAt(0);
			toastTV.setTextSize(34);
			toast.show();
		}
		// naechste Activity zur Terminanlage/-bearbeitung starten und 
		// Termindaten weiterleiten
		else {
			intent = new Intent(this, AddEditAppointment2.class);	
			intent.putExtra("appointmentId", appointmentId);
			intent.putExtra("clientId", clientId);
			intent.putExtra("title", title);
			intent.putExtra("description", description);
			intent.putExtra("startYear", startYear);
			intent.putExtra("startMonth", startMonth);
			intent.putExtra("startDay", startDay);
			intent.putExtra("startHour", startHour);
			intent.putExtra("startMinute", startMinute);
			startActivity(intent);
		}
	}
	
    /**
     * Editiert ggf den uebergebenen String und liefert diesen zurueck; die
     * Methode wird verwendet um die Felder Terminbeginn/-ende/-benachrichtung
     * in einem bestimmten Format setzen zu koennen.
     * @param string ist der uebergebene String, der editiert werden soll
     * @return gibt den editierten String zurueck
     */
	private String editString(String string) {
		if (string.length() == 1)
			string = "0" + string;
		else if (string.length() == 0)
			string = "00";
		return string;
	}

}
