package de.drk.plugin.calendar.neu.Helper;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Diese Klasse enthaelt Methoden fuer den Zugriff auf die lokale Datenbank,
 * also die SQLite-Datenbank, die einzig von dem Kalender-Plugin verwendet wird;
 * dies sind im Einzelnen Methoden zum Abfragen, Hinzufuegen, Bearbeiten und
 * Loeschen von Datensaetzen; der DatabaseHelper wird in saemtlichen Activity-Klassen
 * instanziiert, weil ein Datenbankzugriff zumeist noetig wird, sobald
 * Aktionen auf der Benutzeroberflaeche ausgefuehrt werden.
 * @author Alex Wetzler
 */

public class DatabaseHelper extends SQLiteOpenHelper {
	private static final String CREATE_TABLE = "CREATE TABLE appointment ("
			+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
			+ "title TEXT,"
			+ "description TEXT,"
			+ "location TEXT,"
			+ "priority TEXT,"
			+ "startdt TEXT,"
			+ "enddt TEXT,"
			+ "notdt TEXT,"
			+ "notid TEXT,"
			+ "allday TEXT,"
			+ "recurrence TEXT,"
			+ "carerentry TEXT);";

	/**
	 * Konstruktor, um ein DatabaseHelper-Objekt instanziieren zu koennen.
	 * @param context ist das Programmumfeld, das benoetigt wird um Ressourcen anzufordern
	 */
	public DatabaseHelper(Context context) {
		super(context, "database.db", null, 1);
	}

	/**
	 * Fuegt einen neuen Termindatensatz zur Datenbank (Tabelle appointment) hinzu;
	 * Der Methode werden alle benoetigten Terminfelder per Parameter uebergeben,
	 * dann wird ein SQLiteDatabase-Objekt erzeugt und damit der Datensatz in die 
	 * Datenbank geschrieben.
	 * @param title ist die Bezeichnung des Termins
	 * @param description ist die Beschreibung des Termins
	 * @param location ist der Standort des Termins
	 * @param priority ist die Prioritaet des Termins
	 * @param startdt ist der Beginn (Datum und Uhrzeit) des Termins
	 * @param enddt ist das Ende (Datum und Uhrzeit) des Termins
	 * @param notdt ist die Benachrichtung (Datum und Uhrzeit) des Termins
	 * @param notid ist die ID der Benachrichtung
	 * @param allday ist die Angabe ob, der Termin ganztaetig ist oder nicht
	 * @param recurrence ist die Angabe ueber die Wiederholung des Termins
	 * @param carerentry ist die Angabe ueber die Klassifikation und Herkunft des
	 * Termins (Privattermin, Kliententermin, Gruppentermin)
	 */
	public void addAppointment(String title, String description, String location,
			String priority, String startdt, String enddt, String notdt, String notid, 
			String allday, String recurrence, String carerentry) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put("title", title);
		values.put("description", description);
		values.put("location", location);
		values.put("priority", priority);
		values.put("startdt", startdt);
		values.put("enddt", enddt);
		values.put("notdt", notdt);
		values.put("notid", notid);
		values.put("allday", allday);
		values.put("recurrence", recurrence);
		values.put("carerentry", carerentry);
		db.insert("appointment", null, values);
		db.close();
	}

	/**
	 * Loescht einen bestehenden Termindatensatz aus der Datenbank,
	 * wenn er ueber seine ID, die als Parameter uebergeben wird,
	 * gefunden werden kann.
	 * @param id ist die Termin-ID, nach der gesucht wird
	 */
	public void deleteAppointment(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		db.delete("appointment", "id = " + id, null);
		db.close();
	}

	/**
	 * Loescht alle Termindatensaetze aus der Datenbank,
	 * die aus der Server-Datenbank kommen, also nicht
	 * lokal auf dem Geraet angelegt wurden.
	 */
	public void deleteCarerAppointments() {
		SQLiteDatabase db = this.getReadableDatabase();
		db.delete("appointment", "carerentry != 0", null); 
		db.close();
	}
	
	/**
	 * Liefert die Anzahl der aktuell verfuegbaren
	 * Termindatensaetze in der Datenbank.
	 * @return gibt die Anzahl der Termindatensaetze zurueck
	 */
	public int getNumberOfAppointments() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query("appointment", new String[] { "id" }, null,
				null, null, null, null);
		int number = Cursor.getCount();
		db.close();
		return number;
	}

	/**
	 * Liefert die ID saemtlicher Termindatensaetze als
	 * String-Array, sortiert nach der Bezeichnung der Termine.
	 * @return gibt ein String-Array (IDs) zurueck
	 */
	public String[] getIds() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query("appointment", new String[] { "id" }, null,
				null, null, null, "title ASC");
		Cursor.moveToFirst();
		String[] ids = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			ids[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return ids;
	}

	/**
	 * Liefert die Bezeichnung saemtlicher Termindatensaetze als
	 * String-Array, sortiert nach der Bezeichnung der Termine.
	 * @return gibt ein String-Array (Bezeichnungen) zurueck
	 */
	public String[] getTitles() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query("appointment", new String[] { "title" },
				null, null, null, null, "title ASC");
		Cursor.moveToFirst();
		String[] titles = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			titles[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return titles;
	}
	
	/**
	 * Liefert den Beginn saemtlicher Termindatensaetze als
	 * String-Array, sortiert nach der Bezeichnung der Termine.
	 * @return gibt ein String-Array (Beginn der Termine) zurueck
	 */
	public String[] getStartDts() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query("appointment", new String[] { "startdt" },
				null, null, null, null, "title ASC");
		Cursor.moveToFirst();
		String[] starts = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			starts[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return starts;
	}
	
	/**
	 * Liefert die Wiederholungsangabe saemtlicher Termindatensaetze als
	 * String-Array, sortiert nach der Bezeichnung der Termine.
	 * @return gibt ein String-Array (Wiederholungsangaben) zurueck
	 */
	public String[] getRecurrences() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query("appointment", new String[] { "recurrence" },
				null, null, null, null, "title ASC");
		Cursor.moveToFirst();
		String[] recurrences = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			recurrences[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return recurrences;
	}

	/**
	 * Liefert die Benachrichtigungs-ID der Termindatensaetze, die
	 * vom Server kommen (Klienten-/Gruppentermine) als Integer-Liste,
	 * sortiert nach der Bezeichnung der Termine.
	 * @return gibt eine Liste von Integern (Benachrichtigungs-IDs) zurueck
	 */
	public ArrayList<Integer> getCarerNotIds() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query("appointment", new String[] { "notid" },
				"(carerentry = '1' or carerentry = '2') and allday = '0'", null, null, null, "title ASC");
		Cursor.moveToFirst();
		ArrayList<Integer> notdts = new ArrayList<Integer>();
		for (int i = 0; i < Cursor.getCount(); i++) {
			notdts.add(Integer.parseInt(Cursor.getString(0)));
			Cursor.moveToNext();
		}
		db.close();
		return notdts;
	}
	
	/**
	 * Liefert die Ganztagsangabe saemtlicher Termindatensaetze als
	 * String-Array, sortiert nach der Bezeichnung der Termine.
	 * @return gibt ein String-Array (Ganztagsangaben) zurueck
	 */
	public String[] getAllDays() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query("appointment", new String[] { "allday" },
				null, null, null, null, "title ASC");
		Cursor.moveToFirst();
		String[] alarms = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			alarms[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return alarms;
	}

	/**
	 * Liefert die Klassifikationsangabe saemtlicher Termindatensaetze
	 * als String-Array, sortiert nach der Bezeichnung der Termine.
	 * @return gibt ein String-Array (Klassifikationsangaben) zurueck
	 */
	public String[] getCarerEntries() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query("appointment", new String[] { "carerentry" }, 
				null, null, null, null, "title ASC");
		Cursor.moveToFirst();
		String[] carerEntries = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			carerEntries[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return carerEntries;
	}

	/**
	 * Liefert ggf die Bezeichnung eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Bezeichnung des Termins als String zurueck
	 */
	public String getTitle(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT title FROM appointment WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String title = Cursor.getString(0);
		db.close();
		return title;
	}
	
	/**
	 * Liefert ggf die Beschreibung eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Beschreibung des Termins als String zurueck
	 */
	public String getDescription(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT description FROM appointment WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String description = Cursor.getString(0);
		db.close();
		return description;
	}
	
	/**
	 * Liefert ggf den Standort eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt den Standort des Termins als String zurueck
	 */
	public String getLocation(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT location FROM appointment WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String location = Cursor.getString(0);
		db.close();
		return location;
	}

	/**
	 * Liefert ggf die Prioritaet eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Prioritaet des Termins als String zurueck
	 */
	public String getPriority(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT priority FROM appointment WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String priority = Cursor.getString(0);
		db.close();
		return priority;
	}

	/**
	 * Liefert ggf den Beginn eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt den Beginn des Termins als String zurueck
	 */	
	public String getStartDt(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT startdt FROM appointment WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String startdt = Cursor.getString(0);
		db.close();
		return startdt;
	}

	/**
	 * Liefert ggf das Ende eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt das Ende des Termins als String zurueck
	 */	
	public String getEndDt(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT enddt FROM appointment WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String enddt = Cursor.getString(0);
		db.close();
		return enddt;
	}
	
	/**
	 * Liefert ggf die ID eines Termindatensatzes als Integer,
	 * wobei der Termin ueber den Parameter (Benachrichtigungs-ID) 
	 * in der Datenbank gesucht wird.
	 * @return gibt die ID des Termins als Integer zurueck
	 */	
	public int getAppIdByNotId(int notId) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT id FROM appointment WHERE notid = "
				+ notId, null);
		if (Cursor.getCount() == 0)
			return 0;
		Cursor.moveToFirst();
		int appid = Cursor.getInt(0);
		db.close();
		return appid;
	}

	/**
	 * Liefert ggf die Benachrichtigung eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Benachrichtigungs-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Benachrichtigung des Termins als String zurueck
	 */	
	public String getNotDtByNotId(int notId) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT notdt FROM appointment WHERE notid = "
				+ notId, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String notdt = Cursor.getString(0);
		db.close();
		return notdt;
	}
	
	/**
	 * Liefert ggf die Wiederholungsangabe eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Benachrichtigungs-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Wiederholungsangabe des Termins als String zurueck
	 */	
	public String getRecurrenceByNotId(int notId) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT recurrence FROM appointment WHERE notid = "
				+ notId, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String notdt = Cursor.getString(0);
		db.close();
		return notdt;
	}
	
	/**
	 * Liefert ggf die Benachrichtigung eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Benachrichtigung des Termins als String zurueck
	 */	
	public String getNotDtByAppId(int appId) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT notdt FROM appointment WHERE id = "
				+ appId, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String notdt = Cursor.getString(0);
		db.close();
		return notdt;
	}
	
	/**
	 * Liefert ggf die Benachrichtigungs-ID eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Benachrichtigungs-ID des Termins als String zurueck
	 */	
	public String getNotId(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT notid FROM appointment WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String notid = Cursor.getString(0);
		db.close();
		return notid;
	}

	/**
	 * Liefert ggf die Ganztagsangabe eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Ganztagsangabe des Termins als String zurueck
	 */	
	public String getAllDay(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT allday FROM appointment WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String allday = Cursor.getString(0);
		db.close();
		return allday;
	}
	
	/**
	 * Liefert ggf die Wiederholungsangabe eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Wiederholungsangabe des Termins als String zurueck
	 */	
	public String getRecurrence(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT recurrence FROM appointment WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String recurrence = Cursor.getString(0);
		db.close();
		return recurrence;
	}

	/**
	 * Liefert ggf die Klassifizierungsangabe eines Termindatensatzes als String,
	 * wobei der Termin ueber den Parameter (Termin-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Klassifizierungsangabe des Termins als String zurueck
	 */
	public String getCarerEntry(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT carerentry FROM appointment WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String carerentry = Cursor.getString(0);
		db.close();
		return carerentry;
	}
	
	/**
	 * Liefert true, wenn ein Gruppentermindatensatz ueber die Parameter
	 * (Bezeichnung, Beginn, Ende) in der Datenbank gefunden werden kann,
	 * anderfalls wird false geliefert.
	 * @param title ist die Bezeichnung des Gruppentermins, nach dem gesucht werden soll
	 * @param startdt ist der Beginn des Gruppentermins, nach dem gesucht werden soll
	 * @param enddt ist das Ende des Gruppentermins, nach dem gesucht werden soll
	 * @return gibt true oder false zurueck, je nachdem ob der Datensatz gefunden wurde oder nicht
	 */
	public boolean groupAppointmentExists(String title, String startdt, String enddt) {
		SQLiteDatabase db = this.getReadableDatabase();
		boolean appointmentFound = false;
		Cursor Cursor = db.rawQuery(
				"SELECT id FROM appointment WHERE title = '" + title + 
				"' AND startdt = '" + startdt +
				"' AND enddt = '" + enddt + 
				"' AND carerentry = '2'", null);
		if (Cursor.getCount() > 0) appointmentFound = true;
		db.close();
		return appointmentFound;
	}

	/**
	 * Liefert true, wenn ein Termindatensatz ueber die Parameter
	 * (Bezeichnung, Beginn, ID) in der Datenbank gefunden werden kann,
	 * anderfalls wird false geliefert.
	 * @param title ist die Bezeichnung des Gruppentermins, nach dem gesucht werden soll
	 * @param startDate ist der Beginn des Gruppentermins, nach dem gesucht werden soll
	 * @param appointmentId ist die ID des Gruppentermins, nach der gesucht werden soll
	 * @return gibt true oder false zurueck, je nachdem ob der Datensatz gefunden wurde oder nicht
	 */
	public boolean appointmentExists(String title, String startDate, int appointmentId) {
		SQLiteDatabase db = this.getReadableDatabase();
		boolean appointmentFound = false;
		Cursor Cursor = db.rawQuery(
				"SELECT id FROM appointment WHERE title = '" + title + 
				"' AND startdt = '" + startDate +
				"' AND NOT id = " +appointmentId, null);
		if (Cursor.getCount() > 0) appointmentFound = true;
		db.close();
		return appointmentFound;
	}

	/**
	 * Liefert einige Felder (ID, Bezeichnung, Beginn, Ende) derjenigen
	 * Termindatensaetze zurueck, die ueber den Parameter (Such-String) in der
	 * Datenbank gefunden wurden.
	 * @param name ist der Such-String, nach dem alle Datensaetze durchsucht werden
	 * @return ist ein String-Array mit ID, Bezeichnung, Beginn und Ende
	 * der gefundenen Termindatensaetze
	 */
	public String[] searchAppointments(String name) {
		SQLiteDatabase db = this.getReadableDatabase();
		// passende SQL-Statements ueber die Methode rawQuery des SQLiteDatabase-Objekts db ausfuehren
		Cursor CursorAppointmentIds = db.rawQuery(
				"SELECT id FROM appointment WHERE title LIKE '%" + name
						+ "%' OR description LIKE '%" + name + "%' ORDER BY title DESC", null);
		Cursor CursorTitles = db.rawQuery(
				"SELECT title FROM appointment WHERE title LIKE '%" + name
						+ "%' OR description LIKE '%" + name + "%' ORDER BY title DESC", null);
		Cursor CursorStartDts = db.rawQuery(
				"SELECT startdt FROM appointment WHERE title LIKE '%" + name
						+ "%' OR description LIKE '%" + name + "%' ORDER BY title DESC", null);
		Cursor CursorEndDts = db.rawQuery(
				"SELECT enddt FROM appointment WHERE title LIKE '%" + name 
						+ "%' OR description LIKE '%" + name + "%' ORDER BY title DESC", null);
		// jeweils zum ersten Datensatz navigieren (Cursor)
		CursorAppointmentIds.moveToFirst();
		CursorTitles.moveToFirst();
		CursorStartDts.moveToFirst();
		CursorEndDts.moveToFirst();
		// String-Arrays mit der Anzahl der gefunden Datensaetze erstellen
		int countEntries = CursorAppointmentIds.getCount();
		String[] appointmentIds = new String[countEntries];
		String[] titles = new String[countEntries];
		String[] startDts = new String[countEntries];
		String[] endDts = new String[countEntries];
		// vorhergehende String-Arrays durchlaufen und zu einem neuen String-Array 
		// zusammenbauen, das als Rueckgabe zurueckgeliefert wird
		String[] returnString = new String[countEntries];
		for (int i = 0; i < countEntries; i++) {
			appointmentIds[i] = CursorAppointmentIds.getString(0);
			titles[i] = CursorTitles.getString(0);
			startDts[i] = CursorStartDts.getString(0);
			endDts[i] = CursorEndDts.getString(0);
			returnString[i] = appointmentIds[i] + "," + titles[i] + ","
					+ startDts[i] + "," + endDts[i];
			CursorAppointmentIds.moveToNext();
			CursorTitles.moveToNext();
			CursorStartDts.moveToNext();
			CursorEndDts.moveToNext();
		}

		db.close();
		return returnString;
	}

	/**
	 * Ist eine Callback-Methode und wird nur dann aufgerufen, wenn
	 * die Datenbank noch nicht existiert, hier wird die Methode 
	 * execSQL zum Erstellen der Tabelle appointment ausgefuehrt 
	 * (uebergeben wird dazu das passende SQL-Statement als Konstante).
	 * @param db ist das SQLiteDatabase-Objekt, mit dem die Datenbank
	 * erstellt werden kann
	 */
	@Override
	public void onCreate(SQLiteDatabase db) {
		//db.execSQL("DROP TABLE IF EXISTS appointment");
		db.execSQL(CREATE_TABLE);
	}

	/**
	 * Ist eine Callback-Methode und wird nur dann aufgerufen, wenn die
	 * Datenbank bereits existiert und deren Versionsnummer kleiner ist
	 * als vom Konstruktor angefordert; hier kann der Code zum Migrieren
	 * einer Datenbank ausgefuehrt werden, zur Zeit wird hier allerdings
	 * nur die Datenbank geloescht (ueber execSQL) und neu angelegt (ueber
	 * onCreate).
	 * @param db ist das SQLiteDatabase-Objekt, mit dem die Datenbank
	 * neu erstellt werden kann
	 * @param oldVersion ist die alte Versionsnummer der Datenbank
	 * @param newVersion ist die neue Versionsnummer der Datenbank
	 */
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL("DROP TABLE IF EXISTS appointment");
		onCreate(db);
	}

	 /**
	  * Loescht die Tabelle appointment und legt sie neu an; dazu wird ein
	  * SQLiteDatabase-Objekt erzeugt und dessen Methode execSQL aufgerufen,
	  * dieser werden die passenden SQL-Statements als Parameter uebergeben.
	  */
	public void resetDatabase() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL("DROP TABLE IF EXISTS appointment");
		db.execSQL(CREATE_TABLE);
		db.close();
	}

	/**
	 * Wird von der Klasse DatabaseManager aufgerufen und liefert eine
	 * Liste von Cursorn, mit dem durch die gefundenen Datensaetze navigiert 
	 * werden kann; ueber den Parameter wird das passende SQL-Statement als 
	 * String uebergeben
	 * @param Query ist das SQL-Statement fuer die Datenbankabfrage als String
	 * @return gibt eine Liste von Cursorn fuer die gefundenen Datensaetze zurueck
	 */
	public ArrayList<Cursor> getData(String Query) {
		// get writable database
		SQLiteDatabase sqlDB = this.getWritableDatabase();
		String[] columns = new String[] { "mesage" };
		// an array list of cursor to save two cursors one has results from the
		// query
		// other cursor stores error message if any errors are triggered
		ArrayList<Cursor> alc = new ArrayList<Cursor>(2);
		MatrixCursor Cursor2 = new MatrixCursor(columns);
		alc.add(null);
		alc.add(null);
		try {
			String maxQuery = Query;
			// execute the query results will be save in Cursor c
			Cursor c = sqlDB.rawQuery(maxQuery, null);
			// add value to cursor2
			Cursor2.addRow(new Object[] { "Success" });
			alc.set(1, Cursor2);
			if (null != c && c.getCount() > 0) {
				alc.set(0, c);
				c.moveToFirst();
				return alc;
			}
			return alc;
		} catch (SQLException sqlEx) {
			Log.d("printing exception", sqlEx.getMessage());
			// if any exceptions are triggered save the error message to cursor
			// an return the arraylist
			Cursor2.addRow(new Object[] { "" + sqlEx.getMessage() });
			alc.set(1, Cursor2);
			return alc;
		} catch (Exception ex) {
			Log.d("printing exception", ex.getMessage());
			// if any exceptions are triggered save the error message to cursor
			// an return the arraylist
			Cursor2.addRow(new Object[] { "" + ex.getMessage() });
			alc.set(1, Cursor2);
			return alc;
		}
	}

}
