package de.drk.plugin.calendar.neu;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import de.drk.plugin.calendar.neu.Helper.DatabaseHelper;
import de.drk.plugin.calendar.neu.R;
import de.drk.template.neu.AppcenterTemplate;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.ImageButton;
import android.widget.Toast;

/**
 * Diese Klasse stellt die Funktionalitaet zum Anzeigen
 * von Daten eines einzelnen Termins bereit; dazu wird
 * insbesondere das Layout mit den Datenfeldern und
 * entsprechenden Buttons gesetzt; mit den Buttons koennen
 * Termine geloescht oder zu anderen Activities gewechselt
 * werden.
 */

public class AppointmentData extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	int appointmentId = 0, clientId = 0;
	private final int NUMBER_OF_ALARMENTRIES = 52;
	ImageButton cancelButton = null;
	ImageButton deleteButton = null;
	ImageButton editButton = null;
	Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen, setzt das Layout, konfiguriert
	 * die Layout-Felder und holt sich die Daten eines Kontaktes aus der
	 * Datenbank; anschliessend werden die entsprechenden Layoutfelder mit 
	 * diesen Daten gefuellt. 
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// Layout fuer diese Activity setzen
		setLayout(R.layout.appointment_data);
		// Variablen und Objekte deklarieren sowie initialisieren
		TextView line1TV = (TextView) findViewById(R.id.line1TV);
		TextView line2TV = (TextView) findViewById(R.id.line2TV);
		TextView line3TV = (TextView) findViewById(R.id.line3TV);
		TextView line4TV = (TextView) findViewById(R.id.line4TV);
		TextView line5TV = (TextView) findViewById(R.id.line5TV);
		TextView line6TV = (TextView) findViewById(R.id.line6TV);
		TextView line7TV = (TextView) findViewById(R.id.line7TV);
		cancelButton = (ImageButton) findViewById(R.id.cancelButton);
		deleteButton = (ImageButton) findViewById(R.id.deleteButton);
		editButton = (ImageButton) findViewById(R.id.editButton);
		appointmentId = getIntent().getIntExtra("appointmentId", 0);
		clientId = getIntent().getIntExtra("clientId", 0);
		// ist die Termin-ID ungleich Null, entsprechende Termindaten
		// aus der Datenbank holen und die passenden TextView-Elemente
		// fuellen, um so alle Daten eines Termins auf dem Layout anzuzeigen
		if (appointmentId != 0) {
			// Bezeichnung des Termins setzen
			if (db.getTitle(appointmentId).length() != 0)
				line1TV.setText("Bezeichnung: " +db.getTitle(appointmentId));
			else
				line1TV.setText("Bezeichnung: keine Angabe");
			// Beschreibung des Termins setzen
			if (db.getDescription(appointmentId).length() != 0)
				line2TV.setText("Beschreibung: " +db.getDescription(appointmentId));
			else
				line2TV.setText("Beschreibung: keine Angabe");
			// Standort des Termins setzen
			if (db.getLocation(appointmentId).length() != 0)
				line3TV.setText("Standort: " +db.getLocation(appointmentId));
			else
				line3TV.setText("Standort: keine Angabe");
			// Prioritaet des Termins setzen
			if (db.getPriority(appointmentId).length() != 0)
				line4TV.setText("Prioritaet: " +db.getPriority(appointmentId));
			else
				line4TV.setText("Prioitaet: keine Angabe");
			// Strings fuer Startdatum/-uhrzeit und Enddatum/-uhrzeit erzeugen
			String startString = db.getStartDt(appointmentId);
			String[] startParts = startString.split(" ");
			String startDate = startParts[0];
			String startTime = startParts[1]; 
			String endString = db.getEndDt(appointmentId);
			String[] endParts = endString.split(" ");
			String endDate = endParts[0];
			String endTime = endParts[1]; 
			// Startdatum des Termins vorhanden
			if ((db.getStartDt(appointmentId).length() != 0)) {
				// Enddatum des Termins vorhanden
				if (db.getEndDt(appointmentId).length() != 0) {
					// Termin ist nicht ganztaegig
					if (db.getAllDay(appointmentId).equals("0"))
						line5TV.setText("Zeitraum: " +startDate+ ", " +startTime+ " Uhr bis " +endDate+ ", " +endTime+ " Uhr");
					// Termin ist ganztaegig
					else
						line5TV.setText("Zeitraum: " +startDate+ " bis " +endDate+ " (ganztaegig)");
				}
				// Enddatum des Termins nicht vorhanden
				else {
					// Termin ist nicht ganztaegig
					if (db.getAllDay(appointmentId).equals("0"))
						line5TV.setText("Beginn: " +startDate+ ", " +startTime+ " Uhr");
					// Termin ist ganztaegig
					else
						line5TV.setText("Beginn: " +startDate+ " (ganztaegig)");
				}			
			}
			// Startdatum des Termins nicht vorhanden
			else
				line5TV.setText("Zeitraum: keine Angabe");
			// Benachrichtigung des Termins setzen
			if ((db.getNotDtByAppId(appointmentId).length() != 0)) {
				String notificationString = db.getNotDtByAppId(appointmentId);
				String[] notificationParts = notificationString.split(" ");
				String notificationDate = notificationParts[0];
				String notificationTime = notificationParts[1]; 
				line6TV.setText("Benachrichtigung: " +notificationDate+ ", " +notificationTime+ " Uhr");
			}
			else
				line6TV.setText("Benachrichtigung: keine Angabe");
			// Wiederholungsangabe des Termins setzen
			line7TV.setText("Wiederholung: " +db.getRecurrence(appointmentId));
			if (db.getCarerEntry(appointmentId).equals("0")) {
				// Buttons sich machen, wenn es sich um private Termine
				// handelt, damit sie editiert oder geloescht werden koennen
				editButton.setVisibility(View.VISIBLE);
				deleteButton.setVisibility(View.VISIBLE);
			}
		}
	}

	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; das
	 * Layout dieser Activity verfuegt ueber drei Buttons
	 * zum Editieren und Loeschen eines Datensatzes sowie zum
	 * Abbrechen (Zurueckkehren zur Main-Activity); des Weiteren
	 * wird der Such-Button des Templates konfiguriert, um
	 * darueber die Such-Activity aufrufen zu koennen. Die
	 * Such-Activity ist abhaengig von jeweiligen Plugin und 
	 * damit nicht im Template zentral konfiguriert.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		// Zur Activity wechseln, mit der Termindaten bearbeitet
		// werden koennen, neben der Klienten-ID die Termin-ID
		// uebergeben
		case (R.id.editButton):
			Intent i = new Intent(this, AddEditAppointment1.class);
			i.putExtra("appointmentId", appointmentId);
			i.putExtra("clientId", clientId);
			startActivity(i);
			break;
		case (R.id.deleteButton):	
			// Termin und Alarm loeschen und zur Main-Activity wechseln
			if (appointmentId != 0) {
				// Alarm loeschen
				if (db.getAllDay(appointmentId).equals("0")) {
					SimpleDateFormat sdf = new SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.GERMANY);
					Date date = new Date();
			    	try {
						if(sdf.parse(db.getNotDtByAppId(appointmentId)).compareTo(date) > 0)
							removeAlarm(appointmentId);
					} catch (ParseException e) {
						e.printStackTrace();
					}	
				}
				// Termin loeschen
				db.deleteAppointment(appointmentId);
				// Main-Activity starten
				intent = new Intent(this, MainActivity.class);
				intent.putExtra("clientId", clientId);
				startActivity(intent);
			}
			else {
				// Termin kann nicht geloescht werden, weil die ID ungueltig ist,
				// also entsprechende Meldung ausgeben
				Toast toast = Toast.makeText(
						getApplicationContext(),
						"Die Termin-ID konnte nicht in der Datenbank gefunden werden!",
						Toast.LENGTH_LONG);
				LinearLayout toastLayout = (LinearLayout) toast.getView();
				TextView toastTV = (TextView) toastLayout.getChildAt(0);
				toastTV.setTextSize(34);
				toast.show();
			}
			break;
		// zur Main-Activity wechseln
		case (R.id.cancelButton):
			intent = new Intent(this, MainActivity.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			break;
		// zur Such-Activity wechseln
		case (R.id.searchButton):
			intent = new Intent(this, SearchAppointments.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			break;
	    // Aktionen ausfuehren, die fuer die Buttons im Template konfiguriert wurden
		default:
			super.onButtonClick(view);
			break;
		}
	}
	
	/**
	 * Dise Methode loescht ein oder mehrere Alarmeintraege (Pending-Intents)
	 * fuer einen einzelnen Termin, dessen ID als Parameter uebergeben wurde; 
	 * handelt es sich bei dem Termin um einen Serientermin (wird periodisch 
	 * wiederholt), werden insgesamt 52 Alarmeintraege geloescht (diese Anzahl 
	 * von Alarmeintraegen wird beim Erstellen eines Serientermins automatisch 
	 * angelegt). 
	 * @param appointment_id ist die ID des Termins, dessen Alarm geloescht werden soll 
	 */
	private void removeAlarm(int appointment_id) {
		// Intent zum Wechseln in die Alarm-Activity erstellen
		Intent intent = new Intent(this, AlarmReceiver.class);
		// AlarmManager-Objekt erstellen
		AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
		// Termin wird periodisch wiederholt
		if(!db.getRecurrence(appointment_id).equals("keine")) {
			// 52 Alarmeintraege (Pending-Intents) loeschen
			for(int i=0; i<NUMBER_OF_ALARMENTRIES; i++) {
				int not_id = Integer.parseInt(db.getNotId(appointment_id))+i;
				PendingIntent pIntent = PendingIntent.getActivity(this, not_id, intent, 0);
				am.cancel(pIntent);
				Log.d("", "Benachrichtigung mit Alarm-ID " +Integer.toString(not_id)+ " faellig am " +db.getNotDtByAppId(appointment_id)+ " geloescht!");
			}
		}
		// Termin wird nicht periodisch wiederholt
		else {
			// Alarm-Eintrag (Pending-Intent) loeschen
			PendingIntent pIntent = PendingIntent.getActivity(this, Integer.parseInt(db.getNotId(appointment_id)), intent, 0);
			am.cancel(pIntent);
			Log.d("", "Benachrichtigung mit Alarm-ID " +db.getNotId(appointment_id)+ " faellig am " +db.getNotDtByAppId(appointment_id)+ " geloescht!");
		}	
	}

}