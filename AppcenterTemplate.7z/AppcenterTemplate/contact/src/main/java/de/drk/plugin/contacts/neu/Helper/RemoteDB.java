package de.drk.plugin.contacts.neu.Helper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.drk.plugin.contacts.neu.Helper.WebServiceParser;

/**
 * Diese Klasse enthaelt Methoden fuer den Zugriff auf die Serverdatenbank,
 * also die MySQL-Datenbank, die von der Webanwendung verwendet wird; dies
 * sind im Einzelnen Methoden zum Abfragen und Setzen eines Flags sowie  zum
 * Abfragen von Klienten- und Gruppenkontakten fuer einen bestimmten Klienten.
 * @author Alex Wetzler
 */

public class RemoteDB {

	static String serverAdress = "http://212.100.43.180";

	/**
	 * Der Methode wird eine Klienten-ID und ein Flagname uebergeben;
	 * daraufhin wird ein JSON-Objekt ueber den JSON-Parser mit dem
	 * jeweiligen Flagnamen und -status geholt und der Flagstatus
	 * zurueckgegeben.
	 * @param clientId ist die Klienten-ID, die vom PHP-Skript benoetigt wird
	 * @param cFlagName ist der Flagname, der vom PHP-Skript benoetigt wird
	 * @return gibt den Flagstatus aus der Serverdatenbank zurueck (true oder false)
	 */
	public static boolean checkConfigChanges(int clientId, String cFlagName) {
		JSONObject json;
		JSONArray changeFlag;
		// Parser initialisieren
		WebServiceParser jParser = new WebServiceParser();
		// Liste von NameValue-Paaren erzeugen und die Felder, die als Parameter
		// dem Parser uebergeben werden, hinzufuegen (Klienten-ID, Flagname)
		ArrayList<NameValuePair> nameValuePairs = new ArrayList<NameValuePair>();
		nameValuePairs.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));
		nameValuePairs.add(new BasicNameValuePair("cFlagName",cFlagName));
		// JSON-Objekt mit den Serverdaten (Flagname und -status) holen
		json = jParser.sendEntityGetJSONFromUrl(serverAdress + "/changeFlagNeu.php", nameValuePairs);
		// ist das JSON-Objekt nicht leer und der Flagstatus auf 1, dann true zurueckliefern, 
		// andernfalls false
		if(json != null){
			try {
				changeFlag = json.getJSONArray("changeFlag");
				JSONObject c = changeFlag.getJSONObject(0);
				if(c.getInt("CFLAGSTATUS")==1)
					return true;
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		return false;
	}

	/**
	 * Der Methode wird eine Klienten-ID uebergeben; daraufhin wird ein JSON-Objekt 
	 * ueber den JSON-Parser mit den jeweiligen Klientenkontakten geholt und diese
	 * als JSON-Array zurueckgegeben.
	 * @param clientId ist die Klienten-ID, die vom PHP-Skript benoetigt wird
	 * @return liefert ein JSON-Array mit den Klientenkontakten aus der Serverdatenbank
	 */
	public static JSONArray getUserContacts(int clientId){
		JSONObject json;
		JSONArray contacts = null;
		// Parser initialisieren
		WebServiceParser jParser = new WebServiceParser();
		// Liste von NameValue-Paaren erzeugen und die Felder, die als Parameter
		// dem Parser uebergeben werden, hinzufuegen (Klienten-ID)
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
	   	nameValuePair.add(new BasicNameValuePair("ClientId",Integer.toString(clientId)));
	   	// JSON-Objekt mit den Serverdaten (Klientenkontakte) holen
		json = jParser.sendEntityGetJSONFromUrl(serverAdress + "/userContacts.php", nameValuePair);
		try {
			contacts = json.getJSONArray("userContacts");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		// Klientenkontakte als JSON-Array zurueckliefern
		return contacts;
	}
	
	/**
	 * Der Methode wird eine Klienten-ID uebergeben; daraufhin wird ein JSON-Objekt 
	 * ueber den JSON-Parser mit den jeweiligen Gruppenkontakten geholt und diese
	 * als JSON-Array zurueckgegeben.
	 * @param clientId ist die Klienten-ID, die vom PHP-Skript benoetigt wird
	 * @return liefert ein JSON-Array mit den Gruppenkontakten aus der Serverdatenbank
	 */
	public static JSONArray getGroupContacts(int clientId){
		JSONObject json;
		JSONArray contacts = null;
		// Parser initialisieren
		WebServiceParser jParser = new WebServiceParser();
		// Liste von NameValue-Paaren erzeugen und die Felder, die als Parameter
		// dem Parser uebergeben werden, hinzufuegen (Klienten-ID)
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
	   	nameValuePair.add(new BasicNameValuePair("ClientId",Integer.toString(clientId)));
	   	// JSON-Objekt mit den Serverdaten (Gruppenkontakte) holen
		json = jParser.sendEntityGetJSONFromUrl(serverAdress + "/groupContacts.php", nameValuePair);
		try {
			contacts = json.getJSONArray("groupContacts");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		// Gruppenkontakte als JSON-Array zurueckliefern
		return contacts;
	}
	
	/**
	 * Der Methode wird eine Klienten-ID, ein Flagname und ein Flagstatus uebergeben;
	 * daraufhin wird ein HTTP Post-Request an den Server gesendet, um den uebergebenen
	 * Flagstatus in der Serverdatenbank zu aendern; die Methode wird jedes Mal nach
	 * einem Datenabgleich ausgefuehrt, um den Flagstatus wieder zurueckzusetzen.
	 * @param clientId ist die Klienten-ID, die vom PHP-Skript benoetigt wird
	 * @param cFlagName ist der Flagname, der vom PHP-Skript benoetigt wird
	 * @param value ist der Flagstatus, der vom PHP-Skript benoetigt wird
	 */
	public static void setChangeFlag(int clientId, String cFlagName, int value){
		HttpClient httpclient = new DefaultHttpClient();
		// Liste von NameValue-Paaren erzeugen und die Felder, die als Parameter
		// uebergeben werden, hinzufuegen (Klienten-ID, Flagname, Flagstatus)
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		nameValuePair.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));
		nameValuePair.add(new BasicNameValuePair("cFlagName",cFlagName));
		nameValuePair.add(new BasicNameValuePair("value",Integer.toString(value)));
	   	// HTTP Post-Request mit den zu uebergebenen Daten ueber ein PHP-Skript senden 
	   	HttpPost httppost = new HttpPost(serverAdress + "/setChangeFlagNeu.php");
		try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair));
			httpclient.execute(httppost);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
