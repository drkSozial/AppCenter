package de.drk.plugin.contacts.neu;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnKeyListener;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

import de.drk.plugin.contacts.neu.Helper.DatabaseHelper;
import de.drk.template.neu.AppcenterTemplate;

/**
 * Diese Klasse stellt die Funktionalitaet zum Durchsuchen von Kontaktdatensaetzen
 * bereit; dazu wird insbesondere das Layout mit dem Suchfeld gesetzt und das 
 * entsprechende Event konfiguriert, um jedesmal die Ergebnisanzeige aktualisieren
 * zu koennen, sobald ein (weiterer) Buchstabe eingetippt wurde. 
 * @author Alex Wetzler
 */

public class SearchContacts extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	TextView contactTV = null;
	EditText editSuchen = null;
	LinearLayout contactScroll = null;
    int clientId = 0;
    Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen und setzt das Layout; ausserdem wird
	 * ein Event fuer das Suchfeld festgelegt, also die Aktion die beim Eintippen 
	 * von Buchstaben in das Suchfeld ausgefuehrt werden soll; am Ende wird noch das 
	 * TextView, das zu Beginn angezeigt wird (ohne Suchergebnisse), erstellt und 
	 * dem Layout hinzugefuegt.
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// Layout fuer diese Activity setzen
		setLayout(R.layout.search_contacts);
		// Variablen und Objekte deklarieren sowie initialisieren
		editSuchen = (EditText)findViewById(R.id.search_edit);
		contactScroll = (LinearLayout)findViewById(R.id.contactScroll);
		intent = getIntent();
		clientId = intent.getIntExtra("clientId", 0);
		// Events fuer das EditText-Feld editSuchen festlegen
		editSuchen.addTextChangedListener(new TextWatcher() {
			public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
			public void onTextChanged(CharSequence s, int start, int before, int count) {}
			@Override
			public void afterTextChanged(Editable arg0) {
				// Methode fuer das Anzeigen von gefundenenen Kontakten aufrufen, sobald ein
				// Buchstabe eingegeben wurde und bei jedem weiteren eingegebenen Buchstaben
				readContacts();
			}
		});
		editSuchen.setOnKeyListener(new OnKeyListener() {
			public boolean onKey(View v, int keyCode, KeyEvent event) {
				if (keyCode ==  KeyEvent.KEYCODE_ENTER) {
					if (event.getAction() == KeyEvent.ACTION_DOWN) {
					} else if (event.getAction() == KeyEvent.ACTION_UP) {
						InputMethodManager imm = (InputMethodManager)getSystemService(Context.INPUT_METHOD_SERVICE);
						imm.hideSoftInputFromWindow(editSuchen.getWindowToken(), 0);
					}
					return true;
				} else
					return false;
			}

		});
		// TextView fuer die nicht vorhandenen Suchergebnisse zu Beginn mit entsprechendem Hinweis
		// erstellen und dem LinearLayout hinzufuegen
		setContactTV();
	}

	/**
	 * Wird jedesmal aufgerufen, sobald ein Buchstabe im Suchfeld
	 * eingegeben wurde; leert die LinearLayout-Inhalte, holt sich 
	 * dann die neuen Ergebnisse (Kontaktdatensaetze) aus der Datenbank 
	 * und fuegt diese dem LinearLayout hinzu.
	 */
	public void readContacts(){
		// LinearLayout-Inhalte (Suchergebnisse) entfernen
		contactScroll.removeAllViews();
		// wenn ein Buchstabe eingegeben wurde, dann das String-Array
		// mit den Ergebnissen aus der Datenbank holen
		if(!editSuchen.getText().toString().equals("")) {
			String[] searchString = db.searchContacts(editSuchen.getText().toString());
			if(searchString.length != 0){
				// TexView-Array mit der Anzahl der gefundenen Kontakte erstellen
				TextView[] textViewArray = new TextView[searchString.length];
				// TextViews durchlaufen, Attribute setzen und onClickListener setzen,
				// anschliessend TextViews dem LinearLayout hinzufuegen
				for(int i = (searchString.length-1); i >= 0; i--) {
					textViewArray[i] = new TextView(this);
					textViewArray[i].setBackgroundResource(R.drawable.cell_shape);
					textViewArray[i].setPadding(10, 15, 10, 15);
					textViewArray[i].setTextAppearance(this, android.R.style.TextAppearance_Large);
					textViewArray[i].setTextColor(getResources().getColor(R.color.textColorWeekdays));						
					textViewArray[i].setTextSize(32);
					textViewArray[i].setClickable(true);
					String returnString = searchString[i];
					String[] parts = returnString.split(",");
					String firstName = parts[1];
					String lastName = parts[2];
					String phoneNumber = parts[3];
					textViewArray[i].setText(lastName + ", " + firstName + " (" + phoneNumber + ")");
					textViewArray[i].setId(Integer.parseInt(parts[0]));
					textViewArray[i].setOnClickListener(new View.OnClickListener() {  
						@Override         
						public void onClick(View v) {
							Log.d("", "contactId: " + v.getId());
							intent = new Intent(SearchContacts.this, ContactData.class);
							intent.putExtra("clientId", clientId);
							intent.putExtra("contactId", v.getId());
							startActivity(intent);							
						}     
					});
					contactScroll.addView(textViewArray[i]);
				}
			}else
				setContactTV();
		}
		else
			setContactTV();
	}
	
	/**
	 * Diese Methode wird aufgerufen, wenn noch kein Buchstabe im
	 * Suchfeld eingegeben wurde oder der Suchstring zu keinen
	 * Ergebnisse fuehrt; die Methode erstellt ein neues 
	 * TextView-Objekt, setzt dessen Attribute und fuegt es dann 
	 * dem LinearLayout-Objekt hinzu.
	 */
	private void setContactTV() {
		contactTV = new TextView(this);
		contactTV.setBackgroundResource(R.drawable.cell_shape);
		contactTV.setPadding(10, 15, 10, 15);
		contactTV.setTextAppearance(this, android.R.style.TextAppearance_Large);
		contactTV.setTextColor(getResources().getColor(R.color.textColorWeekdays));						
		contactTV.setTextSize(32);
		contactTV.setText("- Keine Kontakte vorhanden -");
		contactScroll.addView(contactTV);
	}
	
	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; da
	 * das Layout dieser Activity ueber keine Buttons verfuegt,
	 * wird lediglich ein Button in der rechten Menueleiste,
	 * die ueber das Template generiert wird, neu konfiguriert;
	 * die Neukonfiguration fuehrt dazu, dass das Betaetigen des
	 * Back-Buttons den zuletzt eingegebenen Buchstaben entfernt.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		case (R.id.backButton):
			// zuletzt eingetippten Buchstaben des Suchstrings loeschen
			if (editSuchen.getText().length() != 0) {
				String text = editSuchen.getText().toString();
				text = text.substring(0, text.length() - 1);
				editSuchen.setText(text);
			}
			else
				super.onButtonClick(view);
			break;
		// Aktionen ausfuehren, die im Template fuer die Buttons konfiguriert wurden
		default:
			super.onButtonClick(view);
			break;
		}
	}

}

