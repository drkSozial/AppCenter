/**
* Enthaelt Activity-Klassen, die das Layout setzen, die Steuerelemente konfigurieren,
* die Button-Events behandeln, den Datenabgleich durchfuehren und vieles mehr.
*/
package de.drk.plugin.contacts.neu;