package de.drk.plugin.contacts.neu.Helper;

import java.util.ArrayList;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

/**
 * Diese Klasse enthaelt Methoden fuer den Zugriff auf die lokale Datenbank,
 * also die SQLite-Datenbank, die einzig von dem Kontakte-Plugin verwendet wird;
 * dies sind im Einzelnen Methoden zum Abfragen, Hinzufuegen, Bearbeiten und
 * Loeschen von Datensaetzen; der DatabaseHelper wird in saemtlichen Activity-Klassen
 * instanziiert, weil ein Datenbankzugriff zumeist noetig wird, sobald
 * Aktionen auf der Benutzeroberflaeche ausgefuehrt werden.
 * @author Alex Wetzler
 */

public class DatabaseHelper extends SQLiteOpenHelper {
	private static final String ID = "id";
	private static final String FIRSTNAME = "firstname";
	private static final String LASTNAME = "lastname";
	private static final String PHONENUMBER = "phonenumber";
	private static final String EMAILADDRESS = "emailaddress";
	private static final String STREET = "street";
	private static final String HOUSENUMBER = "housenumber";
	private static final String ZIPCODE = "zipcode";
	private static final String CITY = "city";
	private static final String CARERENTRY = "carerentry";
	private static final String TABLE_CONTACT = "contact";
	private static final String DB_NAME = "database.db";
	private static final int DB_VERSION = 1;
	private static final String CREATE_CONTACT = "CREATE TABLE contact ("
			+ "id INTEGER PRIMARY KEY AUTOINCREMENT," + "firstname TEXT,"
			+ "lastname TEXT," + "phonenumber TEXT," + "emailaddress TEXT,"
			+ "street TEXT," + "housenumber TEXT," + "zipcode TEXT,"
			+ "city TEXT," + "carerentry TEXT);";
	private static final String DROP_CONTACT = "DROP TABLE IF EXISTS contact";

	/**
	 * Konstruktor, um ein DatabaseHelper-Objekt instanziieren zu koennen.
	 * @param context ist das Programmumfeld, das benoetigt wird um Ressourcen anzufordern
	 */
	public DatabaseHelper(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}

	/**
	 * Fuegt einen neuen Kontaktdatensatz zur Datenbank (Tabelle contact) hinzu;
	 * Der Methode werden alle benoetigten Kontaktfelder per Parameter uebergeben,
	 * dann wird ein SQLiteDatabase-Objekt erzeugt und damit der Datensatz in die 
	 * Datenbank geschrieben.
	 * @param firstName ist der Vorname des Kontakts
	 * @param lastName ist der Nachname des Kontakts
	 * @param phoneNumber ist die Telefonnummer des Kontakts
	 * @param emailAddress ist die E-Mail-Adresse des Kontakts
	 * @param street ist der Strassenname des Kontakts
	 * @param houseNumber ist die Hausnummer des Kontakts
	 * @param zipCode ist die Postleitzahl des Kontakts
	 * @param city ist der Ortsname des Kontakts
	 * @param carerEntry ist die Angabe ueber die Klassifikation und Herkunft des
	 * Kontakts (Privatkontakt, Klientenkontakt, Gruppenkontakt)
	 */
	public void addContact(String firstName, String lastName,
			String phoneNumber, String emailAddress, String street,
			String houseNumber, String zipCode, String city, String carerEntry) {
		SQLiteDatabase db = this.getWritableDatabase();
		ContentValues values = new ContentValues();
		values.put(FIRSTNAME, firstName);
		values.put(LASTNAME, lastName);
		values.put(PHONENUMBER, phoneNumber);
		values.put(EMAILADDRESS, emailAddress);
		values.put(STREET, street);
		values.put(HOUSENUMBER, houseNumber);
		values.put(ZIPCODE, zipCode);
		values.put(CITY, city);
		values.put(CARERENTRY, carerEntry);
		db.insert(TABLE_CONTACT, null, values);
		db.close();
	}

	/**
	 * Loescht einen bestehenden Kontaktdatensatz aus der Datenbank,
	 * wenn er ueber seine ID, die als Parameter uebergeben wird,
	 * gefunden werden kann.
	 * @param id ist die Kontakt-ID, nach der gesucht wird
	 */
	public void deleteContact(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		db.delete(TABLE_CONTACT, "id = " + id, null);
		db.close();
	}

	/**
	 * Loescht alle Kontaktdatensaetze aus der Datenbank,
	 * die aus der Server-Datenbank kommen, also nicht
	 * lokal auf dem Geraet angelegt wurden.
	 */
	public void deleteCarerContacts() {
		SQLiteDatabase db = this.getReadableDatabase();
		db.delete(TABLE_CONTACT, "carerentry != 0", null);
		db.close();
	}

	/**
	 * Liefert die Anzahl der aktuell verfuegbaren
	 * Kontaktdatensaetze in der Datenbank.
	 * @return gibt die Anzahl der Kontaktdatensaetze zurueck
	 */
	public int getNumberOfContacts() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { ID }, null,
				null, null, null, null);
		int number = Cursor.getCount();
		db.close();
		return number;
	}

	/**
	 * Liefert die ID saemtlicher Kontaktdatensaetze als
	 * String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (IDs) zurueck
	 */
	public String[] getIds() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { ID }, null,
				null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] ids = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			ids[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return ids;
	}

	/**
	 * Liefert den Vornamen saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (Vornamen) zurueck
	 */
	public String[] getFirstNames() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { FIRSTNAME },
				null, null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] firstNames = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			firstNames[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return firstNames;
	}

	/**
	 * Liefert den Nachnamen saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (Nachnamen) zurueck
	 */
	public String[] getLastNames() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { LASTNAME },
				null, null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] lastNames = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			lastNames[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return lastNames;
	}

	/**
	 * Liefert die Telefonnummer saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (Telefonnummern) zurueck
	 */
	public String[] getPhoneNumbers() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { PHONENUMBER },
				null, null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] phoneNumbers = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			phoneNumbers[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return phoneNumbers;
	}

	/**
	 * Liefert die E-Mail-Adresse saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (E-Mail-Adressen) zurueck
	 */
	public String[] getEmailAddresses() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { EMAILADDRESS },
				null, null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] emailAddresses = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			emailAddresses[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return emailAddresses;
	}

	/**
	 * Liefert den Strassennamen saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (Strassennamen) zurueck
	 */
	public String[] getStreets() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { STREET }, null,
				null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] streets = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			streets[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return streets;
	}

	/**
	 * Liefert die Hausnummer saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (Hausnummern) zurueck
	 */
	public String[] getHouseNumbers() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { HOUSENUMBER },
				null, null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] houseNumbers = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			houseNumbers[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return houseNumbers;
	}

	/**
	 * Liefert die Postleitzahl saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (Postleitzahlen) zurueck
	 */
	public String[] getZipCodes() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { ZIPCODE }, null,
				null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] zipCodes = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			zipCodes[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return zipCodes;
	}

	/**
	 * Liefert den Ortsnamen saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (Ortsnamen) zurueck
	 */
	public String[] getCities() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { CITY }, null,
				null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] cities = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			cities[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return cities;
	}

	/**
	 * Liefert die Klassifikationsangabe saemtlicher Kontaktdatensaetze
	 * als String-Array, sortiert nach den Nachnamen der Kontakte.
	 * @return gibt ein String-Array (Klassifikationsangaben) zurueck
	 */
	public String[] getCarerEntries() {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.query(TABLE_CONTACT, new String[] { CARERENTRY },
				null, null, null, null, "lastname ASC");
		Cursor.moveToFirst();
		String[] carerEntries = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {
			carerEntries[i] = Cursor.getString(0);
			Cursor.moveToNext();
		}
		db.close();
		return carerEntries;
	}

	/**
	 * Liefert ggf den Vornamen eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt den Vornamen des Kontakts als String zurueck
	 */
	public String getFirstName(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT firstname FROM contact WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String firstName = Cursor.getString(0);
		db.close();
		return firstName;
	}

	/**
	 * Liefert ggf den Nachnamen eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt den Nachnamen des Kontakts als String zurueck
	 */
	public String getLastName(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT lastname FROM contact WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String lastName = Cursor.getString(0);
		db.close();
		return lastName;
	}
	
	/**
	 * Liefert ggf die Telefonnummer eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Telefonnummer des Kontakts als String zurueck
	 */
	public String getPhoneNumber(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT phonenumber FROM contact WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String phoneNumber = Cursor.getString(0);
		db.close();
		return phoneNumber;
	}

	/**
	 * Liefert ggf die E-Mail-Adresse eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die E-Mail-Adresse des Kontakts als String zurueck
	 */
	public String getEmailAddress(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT emailaddress FROM contact WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String emailAddress = Cursor.getString(0);
		db.close();
		return emailAddress;
	}

	/**
	 * Liefert ggf den Strassennamen eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt den Strassennamen des Kontakts als String zurueck
	 */
	public String getStreet(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT street FROM contact WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String street = Cursor.getString(0);
		db.close();
		return street;
	}

	/**
	 * Liefert ggf die Hausnummer eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Hausnummer des Kontakts als String zurueck
	 */
	public String getHouseNumber(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT housenumber FROM contact WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String houseNumber = Cursor.getString(0);
		db.close();
		return houseNumber;
	}

	/**
	 * Liefert ggf die Postleitzahl eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Postleitzahl des Kontakts als String zurueck
	 */
	public String getZipCode(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery("SELECT zipcode FROM contact WHERE id = "
				+ id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String zipCode = Cursor.getString(0);
		db.close();
		return zipCode;
	}

	/**
	 * Liefert ggf den Ortsnamen eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt den Ortsnamen des Kontakts als String zurueck
	 */
	public String getCity(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT city FROM contact WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String city = Cursor.getString(0);
		db.close();
		return city;
	}

	/**
	 * Liefert ggf die Klassifizierungsangabe eines Kontaktdatensatzes als String,
	 * wobei der Kontakt ueber den Parameter (Kontakt-ID) in der Datenbank
	 * gesucht wird.
	 * @return gibt die Klassifizierungsangabe des Kontakts als String zurueck
	 */
	public String getCarerEntry(int id) {
		SQLiteDatabase db = this.getReadableDatabase();
		Cursor Cursor = db.rawQuery(
				"SELECT carerentry FROM contact WHERE id = " + id, null);
		if (Cursor.getCount() == 0)
			return "";
		Cursor.moveToFirst();
		String carerEntry = Cursor.getString(0);
		db.close();
		return carerEntry;
	}
	
	/**
	 * Liefert true, wenn ein Gruppenkontaktdatensatz ueber die Parameter
	 * (Vorname, Nachname, Telefonnummer) in der Datenbank gefunden werden kann,
	 * anderfalls wird false geliefert.
	 * @param firstName ist der Vorname des Gruppenkontakts, nach dem gesucht werden soll
	 * @param lastName ist der Nachname des Gruppenkontakts, nach dem gesucht werden soll
	 * @param phoneNumber ist die Telefonnummer des Gruppenkontakts, nach der gesucht werden soll
	 * @return gibt true oder false zurueck, je nachdem ob der Datensatz gefunden wurde oder nicht
	 */
	public boolean groupContactExists(String firstName, String lastName, String phoneNumber) {
		SQLiteDatabase db = this.getReadableDatabase();
		boolean contactFound = false;
		Cursor Cursor = db.rawQuery(
				"SELECT id FROM contact WHERE firstname = '" + firstName + 
				"' AND lastname = '" + lastName +
				"' AND phonenumber = '" + phoneNumber + 
				"' AND carerentry = '2'", null);
		if (Cursor.getCount() > 0) contactFound = true;
		db.close();
		return contactFound;
	}
	
	/**
	 * Liefert true, wenn ein Kontaktdatensatz ueber die Parameter
	 * (Vorname, Nachname, Telefonnummer, ID) in der Datenbank gefunden 
	 * werden kann, anderfalls wird false geliefert.
	 * @param firstName ist der Vorname des Kontakts, nach dem gesucht werden soll
	 * @param lastName ist der Nachname des Kontakts, nach dem gesucht werden soll
	 * @param phoneNumber ist die Telefonnummer des Kontakts, nach der gesucht werden soll
	 * @param contactId ist die ID des Kontakts, nach der gesucht werden soll
	 * @return gibt true oder false zurueck, je nachdem ob der Datensatz gefunden wurde oder nicht
	 */
	public boolean contactExists(String firstName, String lastName, String phoneNumber, int contactId) {
		SQLiteDatabase db = this.getReadableDatabase();
		boolean contactFound = false;
		Cursor Cursor = db.rawQuery(
				"SELECT id FROM contact WHERE firstname = '" + firstName + 
				"' AND lastname = '" + lastName +
				"' AND phonenumber = '" + phoneNumber + 
				"' AND NOT id = " +contactId, null);
		if (Cursor.getCount() > 0) contactFound = true;
		db.close();
		return contactFound;
	}

	/**
	 * Liefert einige Felder (ID, Vorname, Nachname, Telefonnummer) derjenigen
	 * Kontaktdatensaetze zurueck, die ueber den Parameter (Such-String) in der
	 * Datenbank gefunden wurden.
	 * @param name ist der Such-String, nach dem alle Datensaetze durchsucht werden
	 * @return ist ein String-Array mit ID, Vorname, Nachname und Telefonnummer
	 * der gefundenen Kontaktdatensaetze
	 */
	public String[] searchContacts(String name) {
		SQLiteDatabase db = this.getReadableDatabase();
		// passende SQL-Statements ueber die Methode rawQuery des SQLiteDatabase-Objekts db ausfuehren
		Cursor CursorContactIds = db.rawQuery(
				"SELECT id FROM contact WHERE firstname LIKE '%" + name
						+ "%' OR lastname LIKE '%" + name + "%' ORDER BY lastname DESC", null);
		Cursor CursorFirstNames = db.rawQuery(
				"SELECT firstname FROM contact WHERE firstname LIKE '%" + name
						+ "%' OR lastname LIKE '%" + name + "%' ORDER BY lastname DESC", null);
		Cursor CursorLastNames = db.rawQuery(
				"SELECT lastname FROM contact WHERE firstname LIKE '%" + name
						+ "%' OR lastname LIKE '%" + name + "%' ORDER BY lastname DESC", null);
		Cursor CursorPhoneNumbers = db.rawQuery(
				"SELECT phonenumber FROM contact WHERE firstname LIKE '%"
						+ name + "%' OR lastname LIKE '%" + name + "%' ORDER BY lastname DESC", null);
		// jeweils zum ersten Datensatz navigieren (Cursor)
		CursorContactIds.moveToFirst();
		CursorFirstNames.moveToFirst();
		CursorLastNames.moveToFirst();
		CursorPhoneNumbers.moveToFirst();
		// String-Arrays mit der Anzahl der gefunden Datensaetze erstellen
		int countEntries = CursorLastNames.getCount();
		String[] contactIds = new String[countEntries];
		String[] firstNames = new String[countEntries];
		String[] lastNames = new String[countEntries];
		String[] phoneNumbers = new String[countEntries];
		// vorhergehende String-Arrays durchlaufen und zu einem neuen String-Array 
		// zusammenbauen, das als Rueckgabe zurueckgeliefert wird
		String[] returnString = new String[countEntries];
		for (int i = 0; i < countEntries; i++) {
			contactIds[i] = CursorContactIds.getString(0);
			firstNames[i] = CursorFirstNames.getString(0);
			lastNames[i] = CursorLastNames.getString(0);
			phoneNumbers[i] = CursorPhoneNumbers.getString(0);
			returnString[i] = contactIds[i] + "," + firstNames[i] + ","
					+ lastNames[i] + "," + phoneNumbers[i];
			CursorContactIds.moveToNext();
			CursorFirstNames.moveToNext();
			CursorLastNames.moveToNext();
			CursorPhoneNumbers.moveToNext();
		}
		db.close();
		return returnString;
	}

	/**
	 * Ist eine Callback-Methode und wird nur dann aufgerufen, wenn
	 * die Datenbank noch nicht existiert, hier wird die Methode 
	 * execSQL zum Erstellen der Tabelle contact ausgefuehrt 
	 * (uebergeben wird dazu das passende SQL-Statement als Konstante).
	 * @param db ist das SQLiteDatabase-Objekt, mit dem die Datenbank
	 * erstellt werden kann
	 */
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(CREATE_CONTACT);
	}

	/**
	 * Ist eine Callback-Methode und wird nur dann aufgerufen, wenn die
	 * Datenbank bereits existiert und deren Versionsnummer kleiner ist
	 * als vom Konstruktor angefordert; hier kann der Code zum Migrieren
	 * einer Datenbank ausgefuehrt werden, zur Zeit wird hier allerdings
	 * nur die Datenbank geloescht (ueber execSQL) und neu angelegt (ueber
	 * onCreate).
	 * @param db ist das SQLiteDatabase-Objekt, mit dem die Datenbank
	 * neu erstellt werden kann
	 * @param oldVersion ist die alte Versionsnummer der Datenbank
	 * @param newVersion ist die neue Versionsnummer der Datenbank
	 */
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		db.execSQL(DROP_CONTACT);
		onCreate(db);
	}

	 /**
	  * Loescht die Tabelle contact und legt sie neu an; dazu wird ein
	  * SQLiteDatabase-Objekt erzeugt und dessen Methode execSQL aufgerufen,
	  * dieser werden die passenden SQL-Statements als Parameter uebergeben.
	  */
	public void resetDatabaseContacts() {
		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(DROP_CONTACT);
		db.execSQL(CREATE_CONTACT);
		db.close();
	}

	/**
	 * Wird von der Klasse DatabaseManager aufgerufen und liefert eine
	 * Liste von Cursorn, mit dem durch die gefundenen Datensaetze navigiert 
	 * werden kann; ueber den Parameter wird das passende SQL-Statement als 
	 * String uebergeben
	 * @param Query ist das SQL-Statement fuer die Datenbankabfrage als String
	 * @return gibt eine Liste von Cursorn fuer die gefundenen Datensaetze zurueck
	 */
	public ArrayList<Cursor> getData(String Query) {
		// get writable database
		SQLiteDatabase sqlDB = this.getWritableDatabase();
		String[] columns = new String[] { "mesage" };
		// an array list of cursor to save two cursors one has results from the
		// query
		// other cursor stores error message if any errors are triggered
		ArrayList<Cursor> alc = new ArrayList<Cursor>(2);
		MatrixCursor Cursor2 = new MatrixCursor(columns);
		alc.add(null);
		alc.add(null);
		try {
			String maxQuery = Query;
			// execute the query results will be save in Cursor c
			Cursor c = sqlDB.rawQuery(maxQuery, null);
			// add value to cursor2
			Cursor2.addRow(new Object[] { "Success" });
			alc.set(1, Cursor2);
			if (null != c && c.getCount() > 0) {
				alc.set(0, c);
				c.moveToFirst();
				return alc;
			}
			return alc;
		} catch (SQLException sqlEx) {
			Log.d("printing exception", sqlEx.getMessage());
			// if any exceptions are triggered save the error message to cursor
			// an return the arraylist
			Cursor2.addRow(new Object[] { "" + sqlEx.getMessage() });
			alc.set(1, Cursor2);
			return alc;
		} catch (Exception ex) {
			Log.d("printing exception", ex.getMessage());
			// if any exceptions are triggered save the error message to cursor
			// an return the arraylist
			Cursor2.addRow(new Object[] { "" + ex.getMessage() });
			alc.set(1, Cursor2);
			return alc;
		}
	}

}
