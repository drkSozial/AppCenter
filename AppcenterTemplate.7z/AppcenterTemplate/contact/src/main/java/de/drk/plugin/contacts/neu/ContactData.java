package de.drk.plugin.contacts.neu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import de.drk.plugin.contacts.neu.Helper.DatabaseHelper;
import de.drk.template.neu.AppcenterTemplate;

/**
 * Diese Klasse stellt die Funktionalitaet zum Anzeigen
 * von Daten eines einzelnen Kontakts bereit; dazu wird
 * insbesondere das Layout mit den entsprechenden 
 * Datenfeldern und Buttons gesetzt; mit den Buttons koennen
 * Kontakte geloescht oder zu anderen Activities gewechselt
 * werden.
 * @author Alex Wetzler
 */

public class ContactData extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	int contactId = 0, clientId = 0;
	TextView firstNameText = null;
	TextView lastNameText = null;
	TextView phoneNumberText = null;
	TextView emailAddressText = null;
	TextView streetText = null;
	TextView houseNumberText = null;
	TextView zipCodeText = null;
	TextView cityText = null;
	ImageButton cancelButton = null;
	ImageButton deleteButton = null;
	ImageButton editButton = null;
	Bundle b = null;
	Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen, setzt das Layout, konfiguriert
	 * die Layout-Felder und holt sich die Daten eines Kontaktes aus der
	 * Datenbank; anschliessend werden die entsprechenden Layoutfelder mit 
	 * diesen Daten gefuellt. 
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// Layout fuer diese Activity setzen
		setLayout(R.layout.contact_data);
		// Variablen und Objekte deklarieren sowie initialisieren
		firstNameText = (TextView) findViewById(R.id.firstNameText);
		lastNameText = (TextView) findViewById(R.id.lastNameText);
		phoneNumberText = (TextView) findViewById(R.id.phoneNumberText);
		emailAddressText = (TextView) findViewById(R.id.emailAddressText);
		streetText = (TextView) findViewById(R.id.streetText);
		houseNumberText = (TextView) findViewById(R.id.houseNumberText);
		zipCodeText = (TextView) findViewById(R.id.zipCodeText);
		cityText = (TextView) findViewById(R.id.cityText);
		cancelButton = (ImageButton) findViewById(R.id.cancelButton);
		deleteButton = (ImageButton) findViewById(R.id.deleteButton);
		editButton = (ImageButton) findViewById(R.id.editButton);
		b = getIntent().getExtras();
		contactId = b.getInt("contactId");
		clientId = b.getInt("clientId");
		// ist die Kontakt-ID ungleich Null, entsprechende Kontaktdaten
		// aus der Datenbank holen und die passenden TextView-Elemente
		// fuellen, um so alle Daten eines Kontakts auf dem Layout anzuzeigen
		if (contactId != 0) {
			firstNameText.setText(db.getFirstName(contactId) + " ");
			lastNameText.setText(db.getLastName(contactId));
			phoneNumberText.setText(db.getPhoneNumber(contactId));
			emailAddressText.setText(db.getEmailAddress(contactId));
			streetText.setText(db.getStreet(contactId) + " ");
			houseNumberText.setText(db.getHouseNumber(contactId));
			zipCodeText.setText(db.getZipCode(contactId) + " ");
			cityText.setText(db.getCity(contactId));
			if (db.getCarerEntry(contactId).equals("0")) {
				// Buttons sichtbar machen, wenn es sich um private Kontakte
				// handelt, damit sie editiert oder geloescht werden koennen
				editButton.setVisibility(View.VISIBLE);
				deleteButton.setVisibility(View.VISIBLE);
			}
		}
	}

	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; das
	 * Layout dieser Activity verfuegt ueber drei Buttons
	 * zum Editieren und Loeschen eines Datensatzes sowie zum
	 * Abbrechen (Zurueckkehren zur Main-Activity); des Weiteren
	 * wird der Such-Button des Templates konfiguriert, um
	 * darueber die Such-Activity aufrufen zu koennen; die
	 * Such-Activity ist abhaengig von jeweiligen Plugin und 
	 * damit nicht im Template zentral konfiguriert.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		// Zur Activity wechseln, mit der Kontaktdaten bearbeitet
		// werden koennen, neben der Klienten-ID die Kontakt-ID
		// uebergeben
		case (R.id.editButton):
			intent = new Intent(this, AddEditContact.class);
			intent.putExtra("contactId", contactId);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			break;
		case (R.id.deleteButton):
			// Kontakt loeschen und zur Main-Activity wechseln
			if (contactId != 0) {
				db.deleteContact(contactId);
				intent = new Intent(this, MainActivity.class);
				intent.putExtra("clientId", clientId);
				startActivity(intent);
				finish();
			}
			// Kontakt kann nicht geloescht werden, weil die ID ungueltig ist,
			// also entsprechende Meldung ausgeben
			else {
				Toast toast = Toast.makeText(
						getApplicationContext(),
						"Die Kontakt-ID konnte nicht in der Datenbank gefunden werden!",
						Toast.LENGTH_LONG);
				LinearLayout toastLayout = (LinearLayout) toast.getView();
				TextView toastTV = (TextView) toastLayout.getChildAt(0);
				toastTV.setTextSize(34);
				toast.show();
			}
			break;
		// zur Main-Activity wechseln
		case (R.id.cancelButton):
			intent = new Intent(this, MainActivity.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			break;
		// zur Such-Activity wechseln
		case (R.id.searchButton):
			intent = new Intent(this, SearchContacts.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			break;
		// Aktionen ausfuehren, die fuer die Buttons im Template konfiguriert wurden
		default:
			super.onButtonClick(view);
			break;
		}
	}

}