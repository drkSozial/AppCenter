package de.drk.plugin.contacts.neu;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import de.drk.plugin.contacts.neu.Helper.DatabaseHelper;
import de.drk.template.neu.AppcenterTemplate;

/**
 * Diese Klasse stellt die Funktionalitaet zum Hinzufuegen,
 * Editieren und Loeschen von einzelnen Kontakten bereit; dazu wird
 * insbesondere das Layout mit den entsprechenden Datenfeldern und
 * Buttons gesetzt; mit den Buttons kann der jeweilige Datensatz in 
 * der lokalen Datenbank gespeichert werden oder aus dieser geloescht
 * werden; des Weiteren kann wieder zur Main-Activity gewechselt
 * werden; das Editieren von Kontakten fuehrt dazu, dass der jeweilige
 * Kontakt geloescht und neu angelegt wird.
 * @author Alex Wetzler
 */

public class AddEditContact extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	int contactId = 0, clientId = 0;
	EditText firstNameText = null;
	EditText lastNameText = null;
	EditText phoneNumberText = null;
	EditText emailAddressText = null;
	EditText streetText = null;
	EditText houseNumberText = null;
	EditText zipCodeText = null;
	EditText cityText = null;
	ImageButton cancelButton = null;
	ImageButton deleteButton = null;
	ImageButton saveButton = null;
	Bundle b = null;
	Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen, setzt das Layout, konfiguriert
	 * die Layout-Felder und holt sich, fuer den Fall dass ein Kontakt bearbeitet
	 * werden soll, die Daten dieses Kontakts aus der lokalen Datenbank; 
	 * anschliessend werden die entsprechenden Layoutfelder mit diesen Daten gefuellt.
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// sorgt dafuer, dass die Tastatur eingeklappt bleibt
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN); 
		// Layout fuer diese Activity setzen
		setLayout(R.layout.add_edit_contact);
		// Variablen und Objekte deklarieren sowie initialisieren
		firstNameText = (EditText) findViewById(R.id.firstNameText);
		lastNameText = (EditText) findViewById(R.id.lastNameText);
		phoneNumberText = (EditText) findViewById(R.id.phoneNumberText);
		emailAddressText = (EditText) findViewById(R.id.emailAddressText);
		streetText = (EditText) findViewById(R.id.streetText);
		houseNumberText = (EditText) findViewById(R.id.houseNumberText);
		zipCodeText = (EditText) findViewById(R.id.zipCodeText);
		cityText = (EditText) findViewById(R.id.cityText);
		cancelButton = (ImageButton) findViewById(R.id.cancelButton);
		deleteButton = (ImageButton) findViewById(R.id.deleteButton);
		saveButton = (ImageButton) findViewById(R.id.saveButton);
		firstNameText.requestFocus();
		b = getIntent().getExtras();
		// wurden dieser Activity Daten uebergeben, so soll ein bestehender
		// Kontakt aus der Datenbank geaendert werden, d.h. es muessen
		// entsprechende Kontaktdaten geholt und die passenden TextView-Elemente
		// gefuellt werden
		if (b != null) {
			contactId = b.getInt("contactId");
			clientId = b.getInt("clientId");
			firstNameText.setText(db.getFirstName(contactId));
			lastNameText.setText(db.getLastName(contactId));
			phoneNumberText.setText(db.getPhoneNumber(contactId));
			emailAddressText.setText(db.getEmailAddress(contactId));
			phoneNumberText.setText(db.getPhoneNumber(contactId));
			streetText.setText(db.getStreet(contactId));
			houseNumberText.setText(db.getHouseNumber(contactId));
			zipCodeText.setText(db.getZipCode(contactId));
			cityText.setText(db.getCity(contactId));
		}
	}
	
	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; das
	 * Layout dieser Activity verfuegt ueber drei Buttons
	 * zum Speichern und Loeschen eines Datensatzes sowie zum
	 * Abbrechen (Zurueckkehren zur Main-Activity); des Weiteren
	 * werden alle Buttons des Templates neu konfiguriert bzw
	 * gesperrt, um ein anderweitiges Navigieren zu unterbinden, 
	 * solange die Kontaktanlage/-bearbeitung nicht abgeschlossen 
	 * ist.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		case (R.id.saveButton):
			// Fehlerfaelle abfangen (Kontaktfelder leer oder Kontakt existiert bereits)
			if (firstNameText.getText().toString().equals("")
					|| lastNameText.getText().toString().equals("")
					|| phoneNumberText.getText().toString().equals("")) {
				Toast toast = Toast.makeText(
						getApplicationContext(),
						"Bitte mindestens die Felder Vorname, Nachname und Telefon-Nr. ausfuellen!",
						Toast.LENGTH_LONG);
				LinearLayout toastLayout = (LinearLayout) toast.getView();
				TextView toastTV = (TextView) toastLayout.getChildAt(0);
				toastTV.setTextSize(34);
				toast.show();
			}
			else if (db.contactExists(firstNameText.getText().toString(), lastNameText.getText().toString(), 
					phoneNumberText.getText().toString(), contactId)) {
				Toast toast = Toast.makeText(
						getApplicationContext(),
						"Es ist bereits ein Kontakt mit diesem Namen und dieser Telefon-Nr. vorhanden!",
						Toast.LENGTH_LONG);
				LinearLayout toastLayout = (LinearLayout) toast.getView();
				TextView toastTV = (TextView) toastLayout.getChildAt(0);
				toastTV.setTextSize(34);
				toast.show();
			}
			// Kontakt aus der Datenbank loeschen, neu anlegen und zur Main-Activity wechseln
			else {
				if (contactId != 0)
					db.deleteContact(contactId);
				db.addContact(firstNameText.getText().toString(), lastNameText
						.getText().toString(), phoneNumberText.getText().toString(),
						emailAddressText.getText().toString(), streetText.getText()
								.toString(), houseNumberText.getText().toString(),
						zipCodeText.getText().toString(),
						cityText.getText().toString(), "0");
				intent = new Intent(this, MainActivity.class);
				intent.putExtra("clientId", clientId);
				startActivity(intent);
				finish();
			}
			break;
		case (R.id.deleteButton):
			// Kontakt loeschen und zur Main-Activity wechseln
			if (contactId != 0) {
				db.deleteContact(contactId);
				intent = new Intent(this, MainActivity.class);
				intent.putExtra("clientId", clientId);
				startActivity(intent);
				finish();
			}
			// Kontakt kann nicht geloescht werden, weil die ID ungueltig ist,
			// also entsprechende Meldung ausgeben
			else {
				Toast toast = Toast.makeText(
						getApplicationContext(),
						"Die Kontakt-ID konnte nicht in der Datenbank gefunden werden!",
						Toast.LENGTH_LONG);
				LinearLayout toastLayout = (LinearLayout) toast.getView();
				TextView toastTV = (TextView) toastLayout.getChildAt(0);
				toastTV.setTextSize(34);
				toast.show();
			}
			break;
		// zur Main-Activity wechseln
		case (R.id.cancelButton):	
			intent = new Intent(this, MainActivity.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			finish();
			break;
		// alle Buttons der rechten Menueleiste sperren
		case (R.id.homeButton):
			break;
		case (R.id.phoneButton):
			break;
		case (R.id.searchButton):
			break;
		case (R.id.backButton):
			break;
		// Aktionen ausfuehren, die fuer die Buttons im Template konfiguriert wurden
		default:
			super.onButtonClick(view);
			break;
		}
	}
	
}