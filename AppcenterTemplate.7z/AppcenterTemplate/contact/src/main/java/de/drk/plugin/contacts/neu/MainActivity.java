package de.drk.plugin.contacts.neu;

import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Timer;
import java.util.TimerTask;

import de.drk.plugin.contacts.neu.Helper.DatabaseHelper;
import de.drk.plugin.contacts.neu.Helper.RemoteDB;
import de.drk.template.neu.AppcenterTemplate;

/**
 * Diese Klasse zeigt alle in der lokalen Datenbank gespeicherten Kontakte
 * in einem ScrollView an, es werden nur der Kontakname und die Telefonnummer
 * angezeigt, mit einem Klick auf einen Kontakt wird in die Activity zum Anzeigen 
 * aller Kontaktdaten gewechselt; es gibt ein Nummernfeld ueber das eine Rufnummer
 * gewaehlt werden kann und ueber den Call-Button wird die Anruf-Activity gestartet;
 * ueber den NewContact-Button kann in die Activity zum Anlegen eines neuen Kontakts
 * gewechselt werden; es wurde ausserdem der Search-Button konfiguriert, um in
 * die Such-Activity fuer Kontakte wechseln zu koennen.
 * @author Alex Wetzler
 */

public class MainActivity extends AppcenterTemplate {

	DatabaseHelper db = new DatabaseHelper(this);
	boolean threadstarted = false;
	int SCROLLSPEED = 50, contactId = 0, clientId = 0;
	private final String SERVER_IP = "http://212.100.43.180";
	String phoneNumber = "";
	TextView phoneNumberText = null;
	LinearLayout contactScroll = null;
	ScrollView scrollView = null;
	Timer syncTimer = null;
	Timer scrollTimer = null;
	Intent intent = null;

	/**
	 * Wird beim Start der Activity aufgerufen, setzt das Layout, konfiguriert
	 * die Layoutelemente, fuehrt fuer den Fall dass die Activiy zum ersten Mal 
	 * aufgerufen wurde (Start der App) einen Datenabgleich durch und aktualisiert 
	 * die Kontaktliste.
	 * @param savedInstanceState ist ein Bundle-Objekt, mit dem Daten zwischen
	 * den Activities ausgetauscht werden koennen
	 */
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// onCreate-Methode der Superklasse aufrufen
		super.onCreate(savedInstanceState);
		// Layout fuer diese Activity setzen
		setLayout(R.layout.main_activity);
		// Klienten-ID von der aufgerufenen Activiy uebernehmen
		Intent intent = getIntent();
		clientId = intent.getIntExtra("clientId", 0);
		// beim ersten Start dieser Activity ist die Klienten-ID Null,
		// in diesem Fall remoteToLocal in einem Thread aufrufen 
		// um den Datenabgleich durchzufuehren
		int firstStart = intent.getIntExtra("firstStart", 0);
		if (firstStart == 1) {
			Log.d("", "onCreate mit firstStart");
			Thread thread = new Thread(){
				@Override
				public void run() {
					if(isServerReachable())
							remoteToLocal();
					else
						Log.d("Serververbindung", "Server ist nicht erreichbar.");
					threadstarted=false;
				}
			};
			if(!threadstarted){
				threadstarted=true;
				thread.start();
				try {
					thread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
		// sorgt dafuer, dass die Tastatur eingeklappt bleibt
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);
		// Objekte deklarieren, initialisieren und konfigurieren (setOnTochListener)
		phoneNumberText = (TextView) findViewById(R.id.phoneNumberText);
		contactScroll = (LinearLayout) findViewById(R.id.contactScroll);
		scrollView = (ScrollView) findViewById(R.id.contactList);
        scrollView.setOnTouchListener(new View.OnTouchListener() {
	        @Override
	        public boolean onTouch(View v, MotionEvent event) {
				scroll(10000);
	            return false;
	        }
        });;
        // Kontakliste (Views) aktualisieren 
        readContent();
	}

	/**
	 * Diese Methode behandelt die Events, die beim Druecken
	 * eines Buttons im Layout ausgefuehrt werden soll; das
	 * Layout dieser Activity verfuegt ueber zwei Buttons und
	 * zwar fuer das Anlegen eines neues Kontakts in der
	 * lokalen Datenbank (Wechsel in die entsprechende Activity) 
	 * und fuer das Anrufen der angezeigten Rufnummer (Starten 
	 * der entsprechenden Activity); ausserdem wird der
	 * Such-Button des Templates konfiguriert, um darueber 
	 * die Such-Activity aufrufen zu koennen; die Such-Activity 
	 * ist abhaengig von jeweiligen Plugin und damit nicht im 
	 * Template zentral konfiguriert; neben dem Such-Button
	 * wird der Back-Button umkonfiguriert, um bei einem
	 * Betaetigen die letzte Ziffer der Rufnummer zu loeschen.
	 * @param view ist das View-Objekt, mit dessen Hilfe die
	 * Steuerelemente des Layouts identifiziert werden koennen
	 */
	public void onButtonClick(View view) {
		switch (view.getId()) {
		// zur Such-Activity wechseln
		case (R.id.searchButton):
			intent = new Intent(this, SearchContacts.class);
			intent.putExtra("clientId", clientId);
			startActivity(intent);
			break;
		// Back-Button neu konfigurieren, um letzte Ziffer der
		// Rufnummer zu loeschen
		case (R.id.backButton):
			if (phoneNumber.equals(""))
				super.onButtonClick(view);
			else {
				phoneNumber = phoneNumber
						.substring(0, phoneNumber.length() - 1);
				phoneNumberText.setText(phoneNumber);
			}
			break;
		// zur Kontaktanlage-Activity wechseln
		case (R.id.newContactButton):
			intent = new Intent(this, AddEditContact.class);
			intent.putExtra("clientId", clientId);
			if (phoneNumber != "")
				intent.putExtra("phoneNumber", phoneNumber);
			startActivity(intent);
			break;
		// zur Anruf-Activity wechseln
		case (R.id.callButton):
			if (phoneNumberText.getText().toString().length() != 0) {
				String url = "tel:" + phoneNumberText.getText().toString();
				Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(url));
				callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
				getApplicationContext().startActivity(callIntent);		
			}
			break;
		// Aktionen ausfuehren, die fuer die Buttons im Template 
		// konfiguriert wurden	
		default:
			super.onButtonClick(view);
			break;
		}
	}

	/**
	 * Diese Methode verarbeitet Eingaben auf dem 
	 * Rufnummernfeld derart, dass die eingegeben
	 * Zeichen an den String phoneNumber angehaengt
	 * werden und schliesslich das Feld fuer die
	 * Rufnummer auf dem Layout aktualisiert.
	 * @param view ist das View-Objekt, mit dessen 
	 * Hilfe die Steuerelemente des Layouts 
	 * identifiziert werden koennen
	 */
	public void onButtonClickPhone(View view) {
		switch (view.getId()) {
		case (R.id.nummerEins):
			phoneNumber += "1";
			break;
		case (R.id.nummerZwei):
			phoneNumber += "2";
			break;
		case (R.id.nummerDrei):
			phoneNumber += "3";
			break;
		case (R.id.nummerVier):
			phoneNumber += "4";
			break;
		case (R.id.nummerFuenf):
			phoneNumber += "5";
			break;
		case (R.id.nummerSechs):
			phoneNumber += "6";
			break;
		case (R.id.nummerSieben):
			phoneNumber += "7";
			break;
		case (R.id.nummerAcht):
			phoneNumber += "8";
			break;
		case (R.id.nummerNeun):
			phoneNumber += "9";
			break;
		case (R.id.nummerNull):
			phoneNumber += "0";
			break;
		case (R.id.nummerStern):
			phoneNumber += "*";
			break;
		case (R.id.nummerRaute):
			phoneNumber += "#";
			break;
		}
		phoneNumberText.setText(phoneNumber);
	}

	/**
	 * Diese Methode wird ausgefuehrt wenn die Activity aufgebaut wurde;
	 * der Aufruf der Scroll-Methode wird erst dann ausgefuehrt, wenn alle 
	 * Views aufgebaut sind und damit die Laenge der Views abgefragt werden 
	 * kann; dies ist notwendig weil die Views dynamisch erstellt werden
	 * und deren Groesse vom Inhalt abhaengt.
	 */
	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
		super.onWindowFocusChanged(hasFocus);
		scroll(0);
	}
	
	/**
	 * Diese Methode wird beim Start dieser Activity und nach jedem Datenabgleich
	 * aufgerufen, es werden die Kontakt-Views entfernt, die neuen Kontaktdaten
	 * aus der Datenbank geholt, die Kontakt-Views mit den neuen Daten angelegt 
	 * und dem ScrollView hinzugefuegt. 
	 */
	public void readContent() {
		// Views fuer die einzelnen Kontakte entfernen
		contactScroll.removeAllViews();
		// aktuelle Kontaktdaten (ID, Vorname, Nachname, Telefonnummer,
		// Klassifizierungsangabe) aus der Datenbank holen
		String[] idString = db.getIds();
		String[] firstNameString = db.getFirstNames();
		String[] lastNameString = db.getLastNames();
		String[] phoneNumberString = db.getPhoneNumbers();
		String[] carerEntryString = db.getCarerEntries();		
		// Fuer jeden Kontakt ein TextView erzeugen, dessen Attribute setzen,
		// einen onClickListener zum Wechseln in die Activity zur
		// Kontaktdatenanzeige setzen und dem ScrollView hinzufuegen
		for (int i = 0; i < db.getNumberOfContacts(); i++) {
			TextView textview = new TextView(MainActivity.this);
			textview.setBackgroundResource(R.drawable.cell_shape);
			textview.setPadding(10, 15, 10, 15);
			textview.setTextAppearance(MainActivity.this, android.R.style.TextAppearance_Large);
			textview.setTextColor(Color.parseColor("#000000"));
			textview.setTextSize(28);
			textview.setClickable(true);
			textview.setTag(phoneNumberString[i]);
			textview.setText(lastNameString[i] + ", " + firstNameString[i] + " (" + phoneNumberString[i] + ")");
			// die Kontakt-ID wird als ID fuer das TextView verwendet
			textview.setId(Integer.valueOf(idString[i]));
			// die Angabe in carerEntry bestimmt die Hintergrundfarbe des TextViews
			if (carerEntryString[i].equals("0"))
				textview.setBackgroundColor(Color.parseColor("#3fb3cde0"));
			else if (carerEntryString[i].equals("1"))
				textview.setBackgroundColor(Color.parseColor("#3f6497b1"));
			else if (carerEntryString[i].equals("2"))
				textview.setBackgroundColor(Color.parseColor("#3f005b96"));
			textview.setOnClickListener(new View.OnClickListener() {
				@Override
				public void onClick(View v) {	
					intent = new Intent(MainActivity.this, ContactData.class);
					intent.putExtra("contactId", v.getId());
					intent.putExtra("clientId", clientId);
					startActivity(intent);
				}
			});
			contactScroll.addView(textview);
		}
	}

	/**
	 * Diese Methode sorgt fuer das automatischen Scrollen des View mit der
	 * Kontaktliste in einer bestimmten Geschwindigkeit; das Scrollen wird 
	 * ueber einen Timer alle x Sekunden (wird ueber die Konstante SCROLLSPEED 
	 * festgelegt) im UI-Thread ausgefuehrt; zusaetzlich kann ueber den Parameter delay die
	 * Ausfuehrung verzoegert werden.
	 * @param delay gibt die Verzoegerung des Timers in Millisekunden an
	 */
	public void scroll(long delay) {
		// wenn der Timer fuer den Scroll-Task schon eingerichtet
		// wurde, diesen beenden und neu einrichten
		if(scrollTimer != null)
			scrollTimer.cancel();
		// TimerTask-Objekt erstellen und im UI-Thread laufen lassen
		TimerTask scrollTask = new TimerTask() {
			int i = 0;
			boolean up = true;
			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {
						// naechste y-Position ermitteln (hoch oder runter)
						if (up == true && i <= contactScroll.getHeight()
										- scrollView.getMaxScrollAmount() - 300)
							i++;
						else {
							up = false;
							i--;
							if (i == 0)
								up = true;
						}
						// Scroll-View auf die naechste Position bewegen
						// i entspricht der y-Position
						scrollView.scrollTo(0, i);
					}
				});
			}
		};
		// Timer-Objekt erzeugen und mit dem Scroll-Task konfigurieren
	    scrollTimer = new Timer();
	    scrollTimer.schedule(scrollTask, delay, SCROLLSPEED);
	}
	
	/**
	 * Diese Methode setzt einen TimerTask fuer das regelmaessige
	 * Ausfuehren der sync-Methode, die den Datenabgleich steuert;
	 * regelmaessig bedeutet, dass die Methode in einem separaten
	 * Thread alle 10 Sekunden aufgerufen wird; zu Beginn wird
	 * ueberprueft, ob dieser TimerTask schon existiert, ist dies
	 * der Fall, wird er beendet und neu angelegt.
	 */
	public void setSyncTask(){
		if(syncTimer != null)
			syncTimer.cancel();
		TimerTask syncTask = new TimerTask() {
			public void run() {		
				sync();														
			}
		};
		syncTimer = new Timer();
		syncTimer.schedule(syncTask, 0, 10000); 
	}
	
	/**
	 * Diese Methode erstellt zu Beginn einen neuen Thread
	 * und ueberprueft darin ob eine Verbindung zum Server
	 * besteht, ist dies der Fall, wird ueberprueft, ob sich
	 * die Daten fuer den jeweiligen Klienten in der
	 * Serverdatenbank geaendert haben, also das Flag gesetzt
	 * ist, ist dies der Fall, wird die lokale Datenbank
	 * aktualisiert; anschliessend wird die Kontaktansicht
	 * aktualisiert, indem die TextViews fuer die Kontakte
	 * geloescht und neu angelegt werden.
	 */
	private void sync(){
		// ist die Klienten-ID gueltig, d.h. ungleich Null,
		// wird das Ueberpruefen auf Datenaenderung und der
		// Datenabgleich in einem separaten Thread durchgefuehrt
		if(clientId != 0){
			Thread thread = new Thread() {
				@Override
				public void run() {
					// besteht eine Verbindung zum Server, wird ueberprueft
					// ob sich die Daten fuer den jeweiligen Klienten
					// in der Serverdatenbank geaendert haben
					if(isServerReachable()){
						boolean serverConfigChanged = RemoteDB.checkConfigChanges(clientId, "Contact");
						Log.d("", "sync");
						Log.d("", "clientId: " +clientId);
						// haben sich die Daten gaendert, wird die Methode
						// remotToLocal aufgerufen, um zu den Datenabgleich
						// durchzufuehren
						if(serverConfigChanged){
							Log.d("", "serverConfigChanged");
							RemoteDB.setChangeFlag(clientId,"Contact",0);		
							remoteToLocal();
							// nach dem Datenabgleich werden die TextViews ueber die
							// Methode readContent neu erstellt (muss in einem
							// separaten Thread ausgefuehrt werden, weil es die UI
							// betrifft)
							runOnUiThread(new Runnable(){
								@Override
								public void run(){
									readContent();
								}
							});
						}
					}
					else
						Log.d("Serververbindung", "Server ist nicht erreichbar.");
					threadstarted=false;
				}
			};
			// ist der Thread fuer die Ueberpruefung und den Datenabgleich
			// noch nicht gestartet, wird er gestartet und es wird
			// gewartet bis er beendet wurde
			if(!threadstarted){
				threadstarted=true;
				thread.start();
				try {
					thread.join();
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			}
		}
	}

	/**
	 * Diese Methode prueft, ob das Geraet eine Verbindung zum Server
	 * herstellen kann und liefert true, wenn die Verbindung zu
	 * stande kommt, andernfalls false. 
	 * @return gibt true oder false zurueck, je nachdem ob die
	 * Verbindung besteht oder nicht
	 */
	public boolean isServerReachable() {
		// ConnectivityManager-Objekt erzeugen, um damit wiedderum
		// ein NetworkInfo-Objekt erzeugen zu koennen, das zurueckliefern
		// kann, ob eine Netzwerkverbindung besteht oder nicht
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		// besteht eine Netzwerkverbindung, dann ein HttpURLConnection-
		// Objekt erzeugen, um sich mit der IP-Adresse des Servers
		// verbinden zu koennen, kommt eine Verbindung zu stande wird
		// true zurueckgeliefert, andernfalls false
		if (netInfo != null && netInfo.isConnected()) {
			try {
				URL url = new URL(SERVER_IP);
				HttpURLConnection urlc = (HttpURLConnection) url
						.openConnection();
				urlc.setConnectTimeout(10 * 1000);
				urlc.connect();
				if (urlc.getResponseCode() == 200)
					return true;
				else
					return false;
			} catch (MalformedURLException e1) {
				return false;
			} catch (IOException e) {
				return false;
			}
		}
		return false;
	}
	
	/**
	 * Diese Methode loescht alle Kontakte aus der lokalen Datenbank,
	 * die vom Server kommen, also Klienten- und Gruppenkontakte;
	 * anschliessend werden diese mit Hilfe der RemoteDB-Klasse erneut
	 * vom Server bezogen, um die aktuellen Daten zu erhalten;
	 * schliesslich werden sie mit Hilfe der DatabaseHelper-Klasse
	 * zu der lokalen Datenbank hinzugefuegt.
	 */
	private void remoteToLocal() {
		// Methode deleteCarerContacts von DatabaseHelper-Klasse 
		// aufrufen, um alle Kontakte zu loeschen, die vom Server kommen 
		// (Klienten-/Gruppenkontake)
		db.deleteCarerContacts();
		// Ist die gegenwaertige Klienten-ID gueltig, dann Klienten- und
		// Gruppenkontakte ueber die RemoteDB-Klasse neu beziehen
		// (als JSONArray-Objekt), die jeweiligen Daten extrahieren
		// und ueber die addContact-Methode der DatabaseHelper-Klasse
		// in der lokalen Datenbank anlegen
		if(clientId != 0){
			JSONArray userContacts = RemoteDB.getUserContacts(clientId);
			JSONArray groupContacts = RemoteDB.getGroupContacts(clientId);
			try {
				// Klientenkontakte zu der Datenbank hinzufuegen
				if (userContacts != null) {
					for (int i = 0; i < userContacts.length(); i++) {
						JSONObject c = userContacts.getJSONObject(i);
						db.addContact(c.getString("FIRSTNAME"),
								c.getString("LASTNAME"), c.getString("PHONENUMBER"),
								c.getString("EMAILADDRESS"), c.getString("STREET"), 
								c.getString("HOUSENUMBER"), c.getString("ZIPCODE"), 
								c.getString("CITY"), "1");
					}
				}
				// Gruppenkontakte zu der Datenbank hinzufuegen
				if (groupContacts != null) {
					for (int i = 0; i < groupContacts.length(); i++) {
						JSONObject c = groupContacts.getJSONObject(i);
						if (!db.groupContactExists(c.getString("FIRSTNAME"), c.getString("LASTNAME"), c.getString("PHONENUMBER")))
							db.addContact(c.getString("FIRSTNAME"),
									c.getString("LASTNAME"), c.getString("PHONENUMBER"),
									c.getString("EMAILADDRESS"), c.getString("STREET"), 
									c.getString("HOUSENUMBER"), c.getString("ZIPCODE"), 
									c.getString("CITY"), "2");
					}
				}
			} catch (JSONException e) {
				e.printStackTrace();
			}
		}
		else
			Log.d("", "Client-ID == 0");
	}
	
	/**
	 * Die Methode wird ausgefuehrt, wenn die Main-Activity
	 * fuer den Benutzer sichtbar wird; hier wird die 
	 * onStart-Methode der Superklasse aufgerufen als auch die
	 * Methode zur Erstellung des Tasks fuer den Datenabgleich.
	 */
	@Override
	public void onStart(){																
		super.onStart();
		setSyncTask();
	}
	
	/**
	 * Die Methode wird ausgefuehrt, wenn die Main-Activity
	 * fuer den Benutzer nicht sichtbar wird; hier wird
	 * die onStart-Methode der Superklasse aufgerufen und der
	 * Timer fuer die Datenabgleich mit dem Server gestoppt.
	 */
	@Override
	public void onStop(){																
		super.onStop();
		if(syncTimer != null)
			syncTimer.cancel();															
	}

}