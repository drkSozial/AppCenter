package de.drk.plugin.contacts.neu.Helper;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONException;
import org.json.JSONObject;

import android.util.Log;

/**
 * Diese Klasse ist ein JSON-Parser und besteht nur aus der Methode 
 * sendEntityGetJSONFromUrl, die ein JSON-Objekt mit den jeweiligen 
 * Serverdaten fuer die lokale Datenbank zurueckliefert; sie wird in 
 * der Klasse RemoteDB instanziiert, die wiederrum Methoden fuer den 
 * Zugriff auf die Serverdatenbank bereitstellt.
 * @author Alex Wetzler
 */

public class WebServiceParser {

	static InputStream is = null;
	static JSONObject jObj = null;
	static String json = null;
	
	/**
	 * Der Methode wird der Pfad des jeweiligen PHP-Skripts und eine Liste von Daten
	 * uebergeben, diese sind fuer die SQL-Abfrage auf die Datenbank noetig; nach dem Parsen 
	 * wird ein JSON-Objekt mit den jeweiligen Serverdaten zurueckgeliefert.
	 * @param url ist das Serverzeichnis, in dem das jeweilige PHP-Skript liegt + Skriptname
	 * @param nameValuePairs ist eine Liste von NameValue-Paaren, die fuer das Anfordern von
	 * Daten an den Server uebergeben werden muessen, damit er die passenden Daten liefern kann
	 * @return gibt das geparste JSON-Objekt mit den entsprechenden Daten zurueck
	 */
	public JSONObject sendEntityGetJSONFromUrl(String url, ArrayList<NameValuePair> nameValuePairs) {
		try {
			// ueber HTTP Post-Request Daten an den Server senden und ueber HTTP Response-Request
			// Daten vom Server empfangen
			DefaultHttpClient httpClient = new DefaultHttpClient();
			HttpPost httpPost = new HttpPost(url);
			httpPost.setEntity(new UrlEncodedFormEntity(nameValuePairs));
			Log.d("", "Name = " + nameValuePairs.get(0).getName());
			Log.d("", "Value = " + nameValuePairs.get(0).getValue());
			HttpResponse httpResponse = httpClient.execute(httpPost);
			HttpEntity httpEntity = httpResponse.getEntity();
			is = httpEntity.getContent();           
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
			return null;
		} catch (ClientProtocolException e) {
			e.printStackTrace();
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
		try {
			BufferedReader reader = new BufferedReader(new InputStreamReader(
					is, "iso-8859-1"), 8);
			StringBuilder sb = new StringBuilder();
			String line = null;
			while ((line = reader.readLine()) != null) {
				sb.append(line + "\n");
			}
			is.close();
			json = sb.toString();
		} catch (Exception e) {
			Log.e("Buffer Error", "Error converting result " + e.toString());
			return null;
		}
		try {
			jObj = new JSONObject(json);
		} catch (JSONException e) {
			Log.e("JSON Parser", "Error parsing data " + e.toString());
			return null;
		}
			return jObj;
	}
}