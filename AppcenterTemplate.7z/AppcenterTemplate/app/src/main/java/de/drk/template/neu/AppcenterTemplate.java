package de.drk.template.neu;

import android.app.Dialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.Uri;
import android.support.v4.app.FragmentActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.RelativeLayout;
import de.drk.template.neu.R;

public class AppcenterTemplate extends FragmentActivity{
	
	/***********************************************************************************
	 * @brief Library-Project "AppcenterTemplate"
	 * 
	 * Dies ist das Template für die Haupt-App und die Plugins der Appcenter-App.
	 * Die Haupt-App und die Plugins erben von dieser Klasse. "AppcenterTemplate" muss 
	 * von "FragmentActivity" erben, da die Haupt-App eine Kind-Klasse von
	 * "FragmentActivity" ist. 
	 * In dieser Activity wird die Seitenleiste mit Notruf-, Home-, Zurück- und 
	 * Suche-Button, sowie der Hintergrund gesetzt. Es werden die Aktionen, die bei
	 * einem Klick auf einen der Buttons gestartet werden sollen, bestimmt.
	 * Die Activity liefert die Methode setLayout, über welche die Kind-Klassen das
	 * Layout des Haupt-Fensters setzen können.
	 **********************************************************************************/
	
	/***********************************************************************************
	 * Durch Aufruf dieser Funktion kann eine Kind-Klasse das Layout der App setzen.
	 **********************************************************************************/
	public void setLayout(int resId){
		setContentView(R.layout.template);												//Setzen des Template-Layouts 
		
		RelativeLayout mainLayout = (RelativeLayout)findViewById(R.id.mainLayout);		//das RelativeLayout "mainLayout" definiert den Inhaltsbereich, den die Kind-Klassen füllen können
		
		mainLayout.addView(LayoutInflater.from(this).inflate(resId, null));				//Hinzufügen eines Layouts zum Haupt-Fenster. "resId" ist die ID des Layouts, das dem Haupt-Fenster zugewiesen wird
	}

	/**
	 * @brief Wird ein Button im Layout gedrueckt wird diese Funktion ausgelöst
	 * 
	 * Hier wird abgefragt, ob ein Button gedrueckt wird und welcher gedrueckt wird. 
	 */
	public void onButtonClick(View view) {

		if (view.getId() == R.id.phoneButton){
			final Dialog dialog = new Dialog(this);
			dialog.setContentView(R.layout.activity_notruf);
			dialog.setTitle("NOTRUF");
			dialog.setCancelable(true);

			final Button jaButton = (Button)dialog.findViewById(R.id.jaButton);
			final Button neinButton = (Button)dialog.findViewById(R.id.neinButton);

			neinButton.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					dialog.dismiss();
				}    

			});

			jaButton.setOnClickListener(new OnClickListener() {

				@Override
				public void onClick(View arg0) {
					SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(
							"standard", MODE_PRIVATE);
					String url = "tel:"+sharedPreferences.getString("notruf", "1234567890");
					Intent callIntent = new Intent(Intent.ACTION_CALL, Uri.parse(url));
					callIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
					getApplicationContext().startActivity(callIntent);
					dialog.dismiss();
				}    

			});			
			dialog.show();
		}
		else if (view.getId() == R.id.homeButton){
			Intent intent = new Intent();
			intent.setClassName("de.drk.appcenter.neu", "de.drk.appcenter.neu.MainActivity");
			finish();
			startActivity(intent);
			overridePendingTransition(0, 0);
		}
		else if(view.getId() == R.id.backButton){
			finish();
			overridePendingTransition(0, 0);
		}
		else if(view.getId() == R.id.searchButton){
			/*Intent intent = new Intent();
			intent.setAction("android.intent.action.SEARCH_APPCENTER_NEU");
			intent.setAction("android.intent.action.DBMANAGER_APPCENTER_NEU");
			finish();
			startActivity(intent);
			overridePendingTransition(0, 0);*/
		}	
	}	
}