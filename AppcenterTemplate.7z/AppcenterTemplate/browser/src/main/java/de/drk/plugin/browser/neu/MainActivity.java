package de.drk.plugin.browser.neu;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Locale;
import java.util.Timer;
import java.util.TimerTask;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.drk.plugin.browser.neu.R;
import de.drk.plugin.browser.neu.Helper.DatenbankHelfer;
import de.drk.plugin.browser.neu.Helper.WebServiceParser;
import de.drk.template.neu.AppcenterTemplate;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.ForegroundColorSpan;
import android.text.style.RelativeSizeSpan;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.view.WindowManager;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.LinearInterpolator;
import android.view.inputmethod.InputMethodManager;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ToggleButton;

/**
 * @class Browser
 * 
 * @brief Anzeigen von Webinhalten mit Eingabemöglichkeit einer Adresse	
 * 
 * In dieser Activity können URLs direkt eingetippt werden, die dann eine Webseite öffnen. Falls man keine URL eintippt, wird nach dem
 * eingegebenden Begriff bei Google.de gesucht. Es wird immer die zuletzt geöffnete Seite gestartet. In den Leszeichen kann man neue 
 * anlegen oder löschen. Wenn man ein Lesezeichen anlegt, wird erstmal die Adresse mit Titel genommen, die gerade geöffnet ist.				 
 */

public class MainActivity extends AppcenterTemplate {

	DatenbankHelfer db = new DatenbankHelfer(this);
	
	String urlget = "http://212.100.43.180/json/getdataNeu.php";
	
	JSONArray bookmarks = null;

	boolean threadstarted=false;
	boolean loeschenSet=false;

	int SCROLLSPEED=50;

	String url=""; 
	String title="";
	String urlview = "";

	EditText webseite=null;
	EditText edittexttitle = null;
	EditText edittexturl = null;
	Animation mAnimation = null;
	WebView browser = null;	
	Button abbrechen = null;
	Button jaButton = null;
	Button neinButton = null;
	Button hinzufuegen = null;
	ImageButton bookmarknewabort = null;
	ImageButton bookmarknewsave = null;
	LinearLayout bookmarkScroll = null;	
	ToggleButton loeschen = null;


	/**
	 * @brief Wird aufgerufen, wenn diese Activity gestartet wird
	 * 
	 * In dieser Funktion findet das Setup statt. Die Daten den Intents werden abgefangen, da die App von extern gestartet werden kann.
	 * Dieser sollte nur die URL beinhalten, die aufgerufen werden soll. Das Extra des Intents heisst "url". Sollte 
	 * kein Extra im Intent vorliegen wird google.de direkt als Startseite aufgerufen. Ansonsten kann man noch ueber den Button
	 * Lesezeichen eigene Seiten ablegen und auswählen, die dann aufgerufen werden. Der Button "Los" öffnet dann die in der Adress-
	 * zeile eingegebene Adresse.
	 */

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);

//		setContentView(R.layout.activity_browser);
		
		setLayout(R.layout.activity_main);

		//Der Scroll Geschwindigkeit wird aus den Einstellungen übernommen
		SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(
				"standard", MODE_PRIVATE);	
		
//		if(System.currentTimeMillis()-Long.valueOf(sharedPreferences.getString("timelastsync", String.valueOf(System.currentTimeMillis()))).longValue()>((Long.valueOf(sharedPreferences.getString("synctime", "5")).longValue())*60000)||(System.currentTimeMillis()-Long.valueOf(sharedPreferences.getString("timelastsync", String.valueOf(System.currentTimeMillis()))).longValue())==0){

			try {
				sync();	
				savePreferences("timelastsync", String.valueOf(System.currentTimeMillis()));
			} catch (JSONException e) {
				e.printStackTrace();
			}
//		}
		
		Integer[] speed = new Integer[] {0, 100, 90, 80, 70, 60, 50, 40, 30, 20, 10};		
		SCROLLSPEED = speed[Integer.valueOf(sharedPreferences.getString("scrollspeed", "3"))];		

		//Tastatur eingeklappt lassen
		getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_STATE_HIDDEN);  

		//Falls ein Intent mit einer URL kommt wird es durch das Bundle verfügbar gemacht
		Bundle b = getIntent().getExtras();  
		browser = (WebView)findViewById(R.id.browser_view); 
		browser.setWebViewClient(new WebViewClient());
		browser.getSettings().setSupportZoom(true);
		browser.getSettings().setBuiltInZoomControls(true);
		EditText webseite = (EditText)findViewById(R.id.webseite);

		//Wenn ENTER gedrückt wird, öffnet sich die in der Adressleiste eingegebene Seite
		webseite.setOnKeyListener(new OnKeyListener()
		{
			public boolean onKey(View v, int keyCode, KeyEvent event)
			{

				if (keyCode ==  KeyEvent.KEYCODE_ENTER) {

					if (event.getAction() == KeyEvent.ACTION_DOWN) {

					} else if (event.getAction() == KeyEvent.ACTION_UP) {
						Button los = (Button)findViewById(R.id.browserLos);
						los.performClick();    
					} 
					return true;
				}else{
					return false;
				}
			}

		});
		loadSavedPreferences();
		browser.loadUrl(url);
		webseite.setText(url);

		//Url wird geändert, wenn von extern eine URL kommt, in dem man die Activity aufruft
		if(b!=null){
			url=b.getString("url");			
			browser.loadUrl(url);
			webseite.setText(url);
		}
	}

	
	
	/**
	 * @brief Wird ein Button gedrueckt wird diese Methode ausgefuehrt.
	 * 
	 * Der entsprechende Button wird mit einer IF Anweisung abgefragt und der entsprechende Code wird ausgefuehrt.
	 */


	public void onButtonClick(View view) {
		
		webseite = (EditText)findViewById(R.id.webseite);
		browser = (WebView)findViewById(R.id.browser_view);

		super.onButtonClick(view);
		
		if(view.getId() == R.id.bookmarks){
			readContent();
		}else if(view.getId() == R.id.browserLos){

			String urledit=webseite.getText().toString();

			//Tastatur wird eingeklappt
			InputMethodManager imm = (InputMethodManager) getSystemService(Activity.INPUT_METHOD_SERVICE);
			imm.toggleSoftInput(InputMethodManager.HIDE_IMPLICIT_ONLY, 0);

			//Abfrage, ob eine Adresse eingetippt wurde, ansonsten bei Google suchen
			if(webseite.getText().toString().contains(".") && !webseite.getText().toString().contains(":")){
				url="http://"+urledit;
			}else if (webseite.getText().toString().contains(":")){
				url=urledit;
			}else{
				url="https://www.google.de/search?q="+urledit;
			}

			//Die Seite laden
			browser.loadUrl(url);
			//Wenn die Seite geladen wurde, wird der Titel auf einen Teil der URL gesetzt
			browser.setWebViewClient(new WebViewClient() {


				@Override
				public void onPageFinished(WebView view, String url) {

					title=view.getUrl();
					String[] splitResult = title.split("\\.");
					title = splitResult[1].substring(0, 1).toUpperCase(Locale.getDefault()) + splitResult[1].substring(1);
					urlview = view.getUrl();
					webseite.setText(urlview);
					savePreferences("lastpage", urlview);

				}
			});
		}
	}

	
	/**
	 * @brief Laden von Einstellungen
	 * 
	 * Hier wird die letzte Seite, die Aufgerufen wurde abgefragt und gesetzt
	 */
	private void loadSavedPreferences() {
		SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(
				"standard", MODE_PRIVATE);
		url = sharedPreferences.getString("lastpage", "http://google.de");


	}

	/**
	 * @brief Speichern von Einstellungen
	 * 
	 * Hier können Werte übergeben werden, die dann in den SharedPreferences gespeichert werden
	 */

	private void savePreferences(String key, String value) {
		SharedPreferences sharedPreferences = getApplicationContext().getSharedPreferences(
				"standard", MODE_PRIVATE);
		Editor editor = sharedPreferences.edit();
		editor.putString(key, value);
		editor.commit();
	}


	/**
	 * @brief Liest alle Leszeichen aus der Datenbank ein und listet diese im Dialog auf
	 * 
	 * Ein Dialog wird erstellt und alle in der Datenbank eingetragenen Werte werden im Dialog angezeigt. 
	 */


	public void readContent(){

		String[] idString = db.getBookmarkId();
		String[] titleString = db.getTitleBook();
		String[] urlString = db.getUrlBook();

		//Festlegen der Animation für den Löschen Button, der blinkt, wenn aktiviert
		mAnimation = new AlphaAnimation(1, 0);
		mAnimation.setDuration(200);
		mAnimation.setInterpolator(new LinearInterpolator());
		mAnimation.setRepeatCount(Animation.INFINITE);
		mAnimation.setRepeatMode(Animation.REVERSE); 

		//Für die Lesezeichen wird ein Android Dialog aufgerufen
		final Dialog dialog = new Dialog(MainActivity.this);
		dialog.setContentView(R.layout.activity_bookmarks);
		dialog.setTitle("Lesezeichen");
		dialog.setCancelable(true);
		dialog.getWindow().setWindowAnimations(R.style.DialogNoAnimation);

		bookmarkScroll = (LinearLayout)dialog.findViewById(R.id.bookmarkScroll);
		hinzufuegen = (Button)dialog.findViewById(R.id.hinzufuegen);
		loeschen = (ToggleButton)dialog.findViewById(R.id.loeschen);

		if(loeschenSet){
			loeschen.setChecked(true);
			loeschen.startAnimation(mAnimation);
		}else{
			loeschen.setChecked(false);
			loeschen.clearAnimation();
		}


		//Die Bedienelemente werden ausgeblendet, wenn der Wert aus der Datenbank nicht 1 ist
		if(db.getBookmarkSet().equals("1")){
			hinzufuegen.setVisibility(1);
			loeschen.setVisibility(1);
		}

		loeschen.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				if(loeschen.isChecked()){
					loeschenSet=true; 
					loeschen.startAnimation(mAnimation);
				}else{
					loeschenSet=false;
					loeschen.clearAnimation();
				}
			}  
		});

		//Bevor alle TextViews hinzugefügt werden, werden erstmal alle vorhandenen von dem ElternView entfernt
		bookmarkScroll.removeAllViews();

		int arraysize=titleString.length;

		//Die TextViews werden dynamisch erstellt
		TextView[] textViewArray = new TextView[arraysize];

		//Konfiguration der Textviews
		for(int i = 0; i < arraysize; i++) {	
			textViewArray[i] = new TextView(this);
			textViewArray[i].setBackgroundResource(R.drawable.cell_weeks);
			textViewArray[i].setPadding(10, 15, 10, 15);
			textViewArray[i].setTextAppearance(this, android.R.style.TextAppearance_Large);
			textViewArray[i].setTextColor(Color.parseColor("#000000"));						
			textViewArray[i].setTextSize(32);
			textViewArray[i].setWidth(300);

			//Verschiedene Teile eines String formatieren
			final SpannableString textToShow = new SpannableString(titleString[i]+"\n"+urlString[i]);
			textToShow.setSpan(new RelativeSizeSpan(0.5f), titleString[i].length() ,textToShow.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);  
			textToShow.setSpan(new ForegroundColorSpan(Color.GRAY), titleString[i].length(), textToShow.length(), Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);


			textViewArray[i].setText(textToShow);
			textViewArray[i].setId(Integer.valueOf(idString[i]));	//TextView ID wird auf die EventID gesetzt
			textViewArray[i].setOnClickListener(new View.OnClickListener() {  
				@Override         
				public void onClick(View v) {  

					if(loeschenSet){
						db.deleteBookmark(v.getId());
						dialog.dismiss();
						readContent();
					}else{
						String[] idString = db.getBookmarkId();
						String[] urlString = db.getUrlBook();

						browser = (WebView)findViewById(R.id.browser_view); 
						browser.setWebViewClient(new WebViewClient());
						webseite = (EditText)findViewById(R.id.webseite);

						for(int i=0;i<idString.length;i++){
							if(idString[i].equals(String.valueOf(v.getId()))){
								savePreferences("lastpage", urlString[i]);
								browser.loadUrl(urlString[i]);
								webseite.setText(urlString[i]);								
								dialog.dismiss();

							}
						}
					}
				}     
			}); 
			//TextView zum LinearLayout hinzufügen
			bookmarkScroll.addView(textViewArray[i]);
		}



		abbrechen=(Button)dialog.findViewById(R.id.abbrechen);
		abbrechen.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				dialog.dismiss();
			}
		});

		hinzufuegen.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View arg0) {
				dialog.setContentView(R.layout.activity_bookmarks_new);
				bookmarknewabort = (ImageButton)dialog.findViewById(R.id.bookmarknewabort);
				bookmarknewsave = (ImageButton)dialog.findViewById(R.id.bookmarknewsave);

				edittexttitle = (EditText)dialog.findViewById(R.id.title);
				edittexturl = (EditText)dialog.findViewById(R.id.url);
				edittexttitle.setText(title);
				edittexturl.setText(urlview);

				bookmarknewabort.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						dialog.dismiss();	

					}
				});

				//Aktuelle Seite in die Datenbank, als neues Lesezeichen eintragen
				bookmarknewsave.setOnClickListener(new OnClickListener() {

					@Override
					public void onClick(View arg0) {
						db.addBookmark(edittexttitle.getText().toString(), edittexturl.getText().toString());
						dialog.dismiss();
					}
				});
			}
		});

		dialog.show();

		//Für das Scrollen wird ein Timertask angelegt, der den Scrollview alle paar ms um 1 Pixel versetzt
		TimerTask task = new TimerTask() {
			int i = 0;
			boolean up=true;

			ScrollView scrollView = (ScrollView)dialog.findViewById(R.id.contactList);
			LinearLayout bookmarkScroll = (LinearLayout)dialog.findViewById(R.id.bookmarkScroll);


			@Override
			public void run() {
				runOnUiThread(new Runnable() {
					@Override
					public void run() {		
						//Schaltet das Scrollen mit dem Finger ab
						bookmarkScroll.getParent().requestDisallowInterceptTouchEvent(true);
						if(up==true && i<=bookmarkScroll.getHeight()-scrollView.getMaxScrollAmount()-300){
							i++;
						}else{
							up=false;
							i--;
							if(i==0){
								up=true;
							}
						}
						scrollView.scrollTo(0, i);
					}
				});


			}
		};
		Timer timer = new Timer();
		timer.schedule(task, 0, SCROLLSPEED);
	}
	
	/**
	 * @brief Pruefen, ob eine Netzwerkverbindung vorhanden ist.
	 * 
	 * Gibt einen boolean Wert wieder, ob eine Verbindung zum Internet besteht.
	 * 
	 */

	public boolean isURLReachable() {
		ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnected()) {
			try {
				URL url = new URL("http://212.100.43.180/");   
				HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
				urlc.setConnectTimeout(10 * 1000);          
				urlc.connect();
				if (urlc.getResponseCode() == 200) {        
					return true;
				} else {
					return false;
				}
			} catch (MalformedURLException e1) {
				return false;
			} catch (IOException e) {
				return false;
			}
		}
		return false;
	}
	
	private void sync() throws JSONException{

		Thread thread = new Thread()
		{


			@Override
			public void run() {

				runOnUiThread(new Runnable() {

					public void run() {
//						sync_status_view=(ImageView)findViewById(R.id.sync_status_view);
//						sync_status_view.setVisibility(View.VISIBLE);


					}});

				if(isURLReachable()){
					remotetolocal();
				}

				threadstarted=false;

				runOnUiThread(new Runnable() {

					public void run() {
//						sync_status_view=(ImageView)findViewById(R.id.sync_status_view);
//						sync_status_view.setVisibility(View.INVISIBLE);


					}});
			}
		};
		if(!threadstarted){
			thread.start();
			threadstarted=true;
		}
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * @brief Daten von dem Remote Server empfangen
	 * 
	 * Diese Methode holt sich ein JSON Objekt mit allen Daten, reinigt die Daten aus der Datenbank und spielt die aktuellen rein.
	 */
	
	private void remotetolocal() {
		db.resetDatabaseBookmarks();

		//Parser initialisieren
		WebServiceParser jParser = new WebServiceParser();

		//JSON Objekt von einer URL holen
		JSONObject json = jParser.getJSONFromUrl(urlget);

		//Nun alle Daten rausziehen und in der lokalen Datenbank speichern

		try {		

			bookmarks = json.getJSONArray("bookmark");

			for(int i = 0; i < bookmarks.length(); i++){
				JSONObject c = bookmarks.getJSONObject(i);
				String title = c.getString("title");
				String url = c.getString("url");
				db.addBookmark(title, url);
			}

		} catch (JSONException e) {
			e.printStackTrace();
		}
	}
}
