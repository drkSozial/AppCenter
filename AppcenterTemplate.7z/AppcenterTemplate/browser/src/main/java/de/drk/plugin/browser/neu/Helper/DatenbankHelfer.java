package de.drk.plugin.browser.neu.Helper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * @class DatenbankHelfer
 * 
 * @brief Diese Klasse dient als Zwischenschicht fuer die Datenbank und Klassen, die mit der Datenbank arbeiten wollen
 * 
 * In dieser Klasse gibt es einige Getter und Putter Methoden um Daten von und in die Datenbank einzutragen. Auch der Aufbau
 * und spätere Upgrade einer Datenbank wird hier ausgefuehrt.
 * 
 * Die Datenbank besteht aus zwei Tabellen, Kontakte und Calendar. 
 *
 */

public class DatenbankHelfer extends SQLiteOpenHelper {

	private static final String TITLEB = "titleB";
	private static final String URL = "url";
	private static final String VALUENAME = "valuename";
	private static final String VALUE = "value";
	private static final String TABLE_VALUE = "value";
	private static final String TABLE_BOOKMARKS = "bookmark";
	private static final String DB_NAME = "database.db";
	private static final int DB_VERSION = 1;

	private static final String TAB_CREATE_BOOKMARKS =
			"CREATE TABLE bookmark ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "titleB TEXT,"
					+ "url TEXT);";

	private static final String TAB_CREATE_VALUE =
			"CREATE TABLE value ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "valuename TEXT,"
					+ "value TEXT);";

	private static final String VALUE_DROP = 
			"DROP TABLE IF EXISTS value";

	private static final String BOOKMARKS_DROP = 
			"DROP TABLE IF EXISTS bookmark";

	public DatenbankHelfer(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}

	public void addBookmark(String titleBook, String urlBook) {
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(TITLEB, titleBook); 
		values.put(URL, urlBook); 
		db.insert(TABLE_BOOKMARKS, null, values);
		db.close();
	}

	public void deleteBookmark(int id){
		SQLiteDatabase db = this.getReadableDatabase();
		String where = "id = " + id;
		db.delete(TABLE_BOOKMARKS, where, null);
	}

	public String[] getBookmarkId(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("bookmark", 
						new String[] {"id"}, 
						"", 
						null, 
						null, 
						null, 
						"titleB ASC");



		Cursor.moveToFirst();
		String[] id = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			id[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return id;

	}

	public String getBookmarkSet(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("value", 
						new String[] {"value"}, 
						"", 
						null, 
						null, 
						null, 
						null);



		Cursor.moveToFirst();

		String show_add_bookmark = Cursor.getString(0);



		db.close();
		return show_add_bookmark;

	}

	public String[] getTitleBook(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("bookmark", 
						new String[] {"titleB"}, 
						"", 
						null, 
						null, 
						null, 
						"titleB ASC");



		Cursor.moveToFirst();
		String[] titleB = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			titleB[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return titleB;

	}

	public String[] getUrlBook(){


		SQLiteDatabase db = this.getReadableDatabase();     
		Cursor Cursor = 
				db.query("bookmark", 
						new String[] {"url"}, 
						"", 
						null, 
						null, 
						null, 
						"titleB ASC");



		Cursor.moveToFirst();
		String[] url = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			url[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}


		db.close();
		return url;

	}





	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(TAB_CREATE_VALUE);
		db.execSQL(TAB_CREATE_BOOKMARKS);

		ContentValues values = new ContentValues();
		values.put(VALUENAME, "show_bookmark_set"); 
		values.put(VALUE, "0");  
		db.insert(TABLE_VALUE, null, values);

	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		//Wird ein neuer Datenbankaufbau gebraucht, wird diese Methode aufgerufen in dieser man den Code hinterlegen kann um die
		//Daten in die neue Datenbank zu migrieren. Hier löschen wir die Datenbank einfach und legen sie neu an.
		db.execSQL(VALUE_DROP);
		db.execSQL(BOOKMARKS_DROP);
		onCreate(db);

	}



	public void resetDatabaseBookmarks(){


		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(BOOKMARKS_DROP);
		db.execSQL(TAB_CREATE_BOOKMARKS);

	}



	public void resetDatabaseValue(){


		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(VALUE_DROP);
		db.execSQL(TAB_CREATE_VALUE);

	}

	public void setBookmarkSet(String set) {



		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(VALUENAME, "show_bookmark_set"); 
		values.put(VALUE, set); 
		db.update(TABLE_VALUE, values, "id = 2", null);

		db.close();
	}
	
}
