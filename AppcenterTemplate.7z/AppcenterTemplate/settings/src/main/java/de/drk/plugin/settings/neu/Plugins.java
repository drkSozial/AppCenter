package de.drk.plugin.settings.neu;

import java.io.File;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.DownloadManager;
import android.app.Fragment;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.content.pm.PackageManager.NameNotFoundException;
import android.database.Cursor;
import android.graphics.Color;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RelativeLayout;
import android.widget.TableLayout;
import android.widget.TextView;
import android.widget.Toast;
import de.drk.plugin.settings.neu.R;
import de.drk.plugin.settings.neu.Helper.DatabaseHelper;
import de.drk.plugin.settings.neu.Helper.RemoteDB;

/**
 * 
 * @author Peter Ewert
 *
 */

/**
 * @class Plugins
 * @brief Klasse fuer die Installation/Deinstallation  von Plugins
 * 
 * Dieses Fragment ist das Tool zur Installation/Deinstallation von Plugins
 * der App "Appcenter"
 */

public class Plugins extends Fragment implements OnClickListener {						//erbt von android.app.Fragment
	
	private Context context;
	
	private DatabaseHelper db;
	
	private final String SERVER_IP = "http://212.100.43.180/";
	private final String SERVER_PLUGIN_DIR = "http://212.100.43.180/appcenterPluginsNeu/";
	
	private View view;
	
	private boolean serverConnection = false;
    
    private List<Integer> installedPluginId = new ArrayList<Integer>();
    private List<String> installedPluginName = new ArrayList<String>();
    private List<String> installedPluginPackageName = new ArrayList<String>();
    
    private List<String> packageUninstall = new ArrayList<String>();
	private List<Integer> uninstalledPluginId = new ArrayList<Integer>();
    
    private DownloadManager downloadManager;
    private BroadcastReceiver receiverDownloadComplete;
    
    private long[] downloadId;
    private boolean[] installed;

	public Plugins() {
	}

	////////////////////////////////////////////////////////////////////////////////////
	//Konstruktor, mit dem der Kontext der aufrufenden Activity uebergeben wird.
	////////////////////////////////////////////////////////////////////////////////////
    public Plugins(Context context){
		this.context = context;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Methode, die nach Erstellung des Fragments aufgerufen wird.
	////////////////////////////////////////////////////////////////////////////////////
    public View onCreateView(LayoutInflater inflater, ViewGroup container, 
	                           Bundle savedInstanceState){
	    
	    isServerReachable();															//Verbindung zum Server testen 
	    
    	if(serverConnection){															//wenn Verbindung zum Server vorhanden
		    view = inflater.inflate(R.layout.fragment_plugin, container, false);		//Layout aus XML erzeugen
		    
		    db = new DatabaseHelper(context);												
		    		    
		    new GetPlugins().execute();													//Aufruf des Async-Tasks GetPlugins()
			
			setBroadcastReceiver();														//BroadcastReceiver fuer die Detektion der Downloads setzen
    	}
    	else{
    		layoutNoConnection(inflater, container);									//wenn keine Serververbindung -> dieses Layout anzeigen
    	}

		return view;
	}

	////////////////////////////////////////////////////////////////////////////////////
	//AsyncTask fuer das Ermitteln und Auflisten der verfuegbaren Plugins. 
	////////////////////////////////////////////////////////////////////////////////////
	private class GetPlugins extends AsyncTask<Void, Void, Boolean> {
		
		final List<Integer> pluginIds = new ArrayList<Integer>();
		final List<String> pluginNames = new ArrayList<String>();
		final List<String> pluginPackages = new ArrayList<String>();
		final List<String> pluginApks = new ArrayList<String>();
		
		@Override
		protected Boolean doInBackground(Void... params) {								//wird in einen eigenen Thread ausgelagert

	      	try {	
	      		JSONArray allPlugins = RemoteDB.getAllPlugins();						//Plugins aus der Server-Datenbank holen
				installed = new boolean[allPlugins.length()];							//Array zum Speichern des Status (installiert oder nicht installiert)
				for(int i = 0; i < allPlugins.length(); i++){							//Speichern der Daten der Plugins in Lists
					JSONObject c = allPlugins.getJSONObject(i);
					if(!c.getString("NAME").equals("Einstellungen") && !c.getString("NAME").equals("EinstellungenNeu")){
						pluginIds.add(c.getInt("ID"));
						pluginNames.add(c.getString("NAME"));
						pluginPackages.add(c.getString("PACKAGENAME"));
						pluginApks.add(c.getString("APK"));
					}
				}      
	      	}catch(JSONException e){
				e.printStackTrace();
	      		getActivity().runOnUiThread(new Runnable(){
					@Override
					public void run(){
						Toast.makeText(getActivity().getBaseContext(), 
								"Es wurden keine Plugins gefunden!",
								Toast.LENGTH_LONG).show();
					}
	      		});
	      		return false;
	      	}
	      	return true;
	    }
		
		@Override
		protected void onPostExecute(Boolean result) {									//nach Beendigung von doInBackground()
			for(int i=0; i<pluginNames.size(); i++){
				if(!pluginNames.get(i).equals("Einstellungen") && !pluginNames.get(i).equals("EinstellungenNeu")){
					setPluginRow(pluginIds.get(i), pluginNames.get(i), i);					//fuer jedes Plugin eine Zeile zur Tabelle hinzufuegen 
				}
			}
	      	Button install_button = (Button)view.findViewById(R.id.install_button);	
	      	install_button.setOnClickListener(new OnClickListener() {					//onClick-Listener fuer den Button "Bestaetigen" setzen
	            public void onClick(View v) {
	            	List<String> apkInstall = new ArrayList<String>();
	    			for(int i=0; i<pluginIds.size(); i++){								//jede Zeile der Tabelle durchlaufen
	    				RelativeLayout rl = (RelativeLayout)view.						//Zeile auswaehlen (jede Zeile ist ein RelativeLayout)
	    						findViewById(pluginIds.get(i));
	    				CheckBox cb = (CheckBox) rl.getChildAt(0);					

	    				if(cb.isChecked()){												//wenn die Checkbox aktiviert ist
    						if(!installed[i]){											//wenn das Plugin nicht installiert ist
		    					apkInstall.add(pluginApks.get(i));						//apk-Namen zur List apkInstall hinzufuegen
	    						installedPluginId.add(pluginIds.get(i));				//Plugin-Daten speichern
	    						installedPluginName.add(pluginNames.get(i));
	    						installedPluginPackageName.add(pluginPackages.get(i));
    						}
    						else{														//wenn das Plugin installiert ist
    							packageUninstall.add(pluginPackages.get(i));			//Package-Namen und Plugin-ID speichern
        						uninstalledPluginId.add(pluginIds.get(i));
    						}
	    				}
	    			}
	    			if(apkInstall.size()!=0){
	    				startDownload(apkInstall);										//starten des Downloads der zur Installation ausgewaehlten Plugins
	    			}
	    			else if(packageUninstall.size()!=0){								//wenn kein Plugin zur Installation ausgewaehlt wurde (sonst wird die Deinstallation erst nach dem Download der anderen Plugins gestartet)
	    				uninstall(packageUninstall);									//starten der Deinstallation der hierzu bestimmten Plugins
	    			}
	            }  
	        });
	      	final CheckBox check_all_installed = (CheckBox)view.						//hier werden, wenn die Checkbox links neben dem Button "Bestaetigen" aktiviert wird, alle Checkboxen in der Reihe darueber aktiviert
	      			findViewById(R.id.check_all_installed);
	      	check_all_installed.setOnClickListener(new OnClickListener() {
	            public void onClick(View v) {
	    			for(int i=0; i<pluginNames.size(); i++){
	    				RelativeLayout rl = (RelativeLayout)view.
	    						findViewById(pluginIds.get(i));
	    				CheckBox cb = (CheckBox) rl.getChildAt(0);
	    				if(installed[i])
	    					cb.setChecked(check_all_installed.isChecked());
	    			}
	            }
	        });
	      	final CheckBox check_all_not_installed = (CheckBox)view.					//hier werden, wenn die Checkbox rechts neben dem Button "Bestaetigen" aktiviert wird, alle Checkboxen in der Reihe darueber aktiviert
	      			findViewById(R.id.check_all_not_installed);
	      	check_all_not_installed.setOnClickListener(new OnClickListener() {
	            public void onClick(View v) {
	    			for(int i=0; i<pluginNames.size(); i++){
	    				RelativeLayout rl = (RelativeLayout)view.
	    						findViewById(pluginIds.get(i));
	    				CheckBox cb = (CheckBox) rl.getChildAt(0);
	    				if(!installed[i])
	    					cb.setChecked(check_all_not_installed.isChecked());
	    			}
	            }
	        });
		}
	}
    
	////////////////////////////////////////////////////////////////////////////////////
	//Methode zum Hinzufuegen einer Zeile in der Plugin-Tabelle
	////////////////////////////////////////////////////////////////////////////////////
	private void setPluginRow(int pluginId, String pluginName, int rowNumber){
		
	    TableLayout.LayoutParams param_tablerow = new TableLayout.						//Setzen der LayoutParams fuer die Zeilen der Tabelle
	    		LayoutParams(TableLayout.LayoutParams.MATCH_PARENT, 
	    					TableLayout.LayoutParams.WRAP_CONTENT,1);
	    RelativeLayout.LayoutParams param_checkbox = new RelativeLayout.				//Setzen der LayoutParams fuer die Checkboxen in der Tabelle
	    		LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
	    					RelativeLayout.LayoutParams.WRAP_CONTENT);
	    RelativeLayout.LayoutParams param_textview = new RelativeLayout.				//Setzen der LayoutParams fuer die TextViews in der Tabelle
	    		LayoutParams(RelativeLayout.LayoutParams.WRAP_CONTENT,
	    					RelativeLayout.LayoutParams.WRAP_CONTENT);
	    
	    final RelativeLayout rl = new RelativeLayout(context);							//Erstellen eines RelativeLayouts
		CheckBox cb = new CheckBox(context);											//Erstellen einer Checkbox
		TextView tx = new TextView(context);											//Erstellen eines Textviews
		
		int[] pluginIds = db.getPluginId();
		
	    for (int i=0; i<pluginIds.length; i++){								
	    	if(pluginId == pluginIds[i]){												//Abfrage, ob das Plugin schon installiert ist
	    		param_checkbox.addRule(RelativeLayout.ALIGN_PARENT_RIGHT);				//Checkbox rechts anordnen
	    		cb = createCheckBox(param_checkbox);									//Checkbox und Textview erstellen
	    		tx = createTextView(pluginName + " (installiert)",param_textview,
	    				getResources().getColor(R.color.dark_green));

	    		rl.addView(cb);															//Checkbox und Textview zum RelativeLayout hinzufuegen
	    		rl.addView(tx);
	    		
	    		installed[rowNumber] = true;											//Plugin als installiert "markieren"
	    	}
	    }
		if(!installed[rowNumber]){														//wenn das Plugin noch nicht installiert ist

			param_checkbox.addRule(RelativeLayout.ALIGN_PARENT_LEFT);					//Checkbox links anordnen
	    	cb = createCheckBox(param_checkbox);										//Checkbox und Textview erstellen
			tx = createTextView(pluginName,param_textview, Color.BLACK);
			
			rl.addView(cb);																//Checkbox und Textview zum RelativeLayout hinzufuegen
			rl.addView(tx);
		}
	    
	    rl.setId(pluginId);																//dem RelativeLayout die ID des Plugins zuweisen (wichtig fuer den onClick-Listener)
	    rl.setBackgroundColor(getResources().getColor(R.color.white_50));				//Hintergrund der Zeile
		rl.setLayoutParams(param_tablerow);
		TableLayout tl = (TableLayout)view.findViewById(R.id.table_plugin);
		tl.addView(rl);																	//RelativeLayout als Zeile zum TableLayout hinzufuegen
		
		rl.setOnClickListener(new OnClickListener() {									//onClick-Listener fuer die Zeile setzen
			CheckBox checkBox;
	        public void onClick(View v) {
				checkBox = (CheckBox) rl.getChildAt(0);
				checkBox.setChecked(!checkBox.isChecked());								//wenn auf eine Zeile geklickt wird, wird der Status der Checkbox geaendert 
	        }  
	    });
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Checkbox erstellen
	////////////////////////////////////////////////////////////////////////////////////
	private CheckBox createCheckBox(RelativeLayout.LayoutParams params){
		
		int screenWidth = context.getResources().getDisplayMetrics().widthPixels;		//Ermitteln der Bildschirmbreite in Pixeln
		
		CheckBox cb = new CheckBox(context);
		cb.setText("");
		cb.setButtonDrawable(R.drawable.checkbox);
		params.setMargins(screenWidth/8, 0, screenWidth/8, 0);
		params.addRule(RelativeLayout.CENTER_VERTICAL);
		cb.setLayoutParams(params);
	
		return cb;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Textview erstellen
	////////////////////////////////////////////////////////////////////////////////////
	private TextView createTextView(String text, RelativeLayout.LayoutParams params, int color){
	
		int screenHeight = context.getResources().getDisplayMetrics().heightPixels;		//Ermitteln der Bildschirmeigenschaften
		int scaledDensity = (int) context.getResources().getDisplayMetrics().scaledDensity;
		int textSize = (screenHeight/20)/scaledDensity;
		
		TextView tx = new TextView(context);
		tx.setText(text);
		tx.setTextColor(color);
		tx.setTextSize(textSize);
		params.addRule(RelativeLayout.CENTER_HORIZONTAL);
		tx.setLayoutParams(params);
		tx.setGravity(Gravity.CENTER);
		tx.setPadding(0, screenHeight/70, 0, screenHeight/70);
	
		return tx;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Layout "Keine Serververbindung" setzen
	////////////////////////////////////////////////////////////////////////////////////
	private void layoutNoConnection(LayoutInflater inflater, ViewGroup container){
		view = inflater.inflate(R.layout.fragment_plugin_no_connection, container, false);
	  	Button try_again_button = (Button)view.findViewById(R.id.try_again_bt);
	  	try_again_button.setOnClickListener(this);
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//onClick-Methode fuer das Layout "Keine Serververbindung"
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void onClick(View v) {
		if(v.getId() == R.id.try_again_bt){												//wenn auf den Button "Erneut versuchen" geklickt wird, wird das Fragment "Plugins" neu geladen
			FragmentManager fragmentManager = getFragmentManager();
	        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
	        fragmentTransaction.remove(this);											//Fragment "Plugins" entfernen
	        Plugins plugins = new Plugins(context);
	        fragmentTransaction.add(R.id.fragment_container, plugins);					//Fragment "Plugins" hinzufuegen
	        fragmentTransaction.commit();
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Methode zum Starten der Downloads der als List uebergebenen apk-Dateien
	////////////////////////////////////////////////////////////////////////////////////
	private void startDownload(List<String> installApk){
		getActivity().registerReceiver(receiverDownloadComplete,						//Anmelden des Download-Broadcast-Receivers
				new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));
		downloadId = new long[installApk.size()];										//Array zum hinterlegen der DownloadIds
		downloadManager = (DownloadManager) getActivity().								//Instanz des Android-DownloadManagers erstellen
				getSystemService(Context.DOWNLOAD_SERVICE);
		for(int i=0; i<installApk.size(); i++){
			String url = SERVER_PLUGIN_DIR + installApk.get(i);							//Pfad zur Datei, die heruntergeladen werden soll
			Uri uri = Uri.parse(url);													//Uri erstellen
			DownloadManager.Request request = new DownloadManager.Request(uri);			//Request fuer die Uri erstellen
			request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,	//Downloadverzeichnis bestimmen
					installApk.get(i));
			downloadId[i] = downloadManager.enqueue(request);							//Download in die Warteschlange stellen. Wird dann automatisch gestartet. Die zurueckgegebene ID im Array downloadId speichern.
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode setzt den BroadcastReceiver, der dafuer zustaendig ist den Status der 
    //Downloads zu ermitteln
	////////////////////////////////////////////////////////////////////////////////////
    private void setBroadcastReceiver(){
    	receiverDownloadComplete = new BroadcastReceiver() {
    		private int downloadCounter = 0;											//Counter fuer das Zaehlen der erfolgreich beendeten Downloads
    		private List<Uri> apkUri = new ArrayList<Uri>();							//List in der die Pfade der Downloads gespeichert werden
    		@Override
			public void onReceive(Context context, Intent intent){
				if(downloadId != null){
					DownloadManager.Query query = new DownloadManager.Query();			
					query.setFilterById(downloadId);									//Herausfiltern der Downloads mit den Download-IDs des Arrays downloadId
					Cursor cursor = downloadManager.query(query);
					cursor.moveToFirst();												//ersten der gefilteren Downloads auswaehlen 
					
					int statusIndex = cursor.getColumnIndex(DownloadManager.			//ermitteln des Download-Status
							COLUMN_STATUS);
					int status = cursor.getInt(statusIndex);
					
					int fileNameIndex = cursor.getColumnIndex(DownloadManager.			//ermitteln des Pfads der heruntergeladenen Datei
							COLUMN_LOCAL_FILENAME);
					String savedFilePath = cursor.getString(fileNameIndex);
					
					int reasonIndex = cursor.getColumnIndex(DownloadManager.			//ermitteln der detaillierten Angaben zum Status bei STATUS_FAILED oder STATUS_PAUSED
							COLUMN_REASON);
					int reason = cursor.getInt(reasonIndex);

					switch (status){
					case DownloadManager.STATUS_FAILED:									//wenn der Download fehlgeschlagen ist
						Toast.makeText(context,
								"Datei konnte nicht geladen werden",
								Toast.LENGTH_SHORT).show();
						Log.d("", "Download-Fehler: " + reason);						//Fehler im Logging ausgeben
						downloadCounter++;
					case DownloadManager.STATUS_SUCCESSFUL:								//wenn der Download beendet wurde
						if(savedFilePath!=null){										//ueberpruefen, ob die Pfad-Variable nicht leer ist
							downloadCounter++;							
							Uri apk_install = Uri.fromFile(new File(savedFilePath));	//Download-Pfad
							apkUri.add(apk_install);		
							if(downloadCounter == downloadId.length)					//wenn alle Downloads erfolgreich beendet wurden
								install(apkUri);										//Installations-Methode aufrufen
						}
					}
				}
			}
		};
    }
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode startet die Installation der heruntergeladenen Plugins und danach 
    //die Deinstallation der ausgewaehlten Plugins
	////////////////////////////////////////////////////////////////////////////////////
    private void install(List<Uri> apkUri){
    	getActivity().unregisterReceiver(receiverDownloadComplete);						//Download-Broadcast-Receiver abmelden
		Intent installIntent = new Intent(Intent.ACTION_VIEW);
		for(int i=0; i<apkUri.size(); i++){
			installIntent.setDataAndType(apkUri.get(i),									//dem Installations-Intent den Pfad der apk-Datei und den Typ uebergeben 
					"application/vnd.android.package-archive");
			startActivityForResult(installIntent, i);									//Install-Intent starten. Bei dessen Beendigung wird die Methode onActivityResult() aufgerufen, der der Wert i uebergeben wird.
		}
		uninstall(packageUninstall);													//Deinstallations-Methode aufrufen
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Methode, in der die Deinstallation der Plugins, deren package-Namen als List
	//uebergeben werden, gestartet wird.
	////////////////////////////////////////////////////////////////////////////////////
	private void uninstall(List<String> packageName){
		for(int i=0; i<packageName.size(); i++){															
			Uri packageURI = Uri.parse("package:"+packageName.get(i));
			Intent uninstallIntent = new Intent(Intent.ACTION_DELETE, packageURI);
			startActivityForResult(uninstallIntent, i+1000);							//Starten der Deinstallation. Danach wird die Methode onActivityResult() aufgerufen. Dieser wird der Wert i+1000 uebergeben.
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Wird nach Beendigung eines Intents aufgerufen, der mit startActivityForResult()
	//aufgerufen wurde.
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void onActivityResult(int requestCode, int resultCode, Intent data) {
	    if (requestCode >= 0 && requestCode < 1000) {									//wenn der beendete Intent eine Installation war
	    	if(installed(installedPluginPackageName.get(requestCode))){					//wenn das Plugin erfolgreich installiert wurde
	    		db.addPlugin(installedPluginId.get(requestCode),						//hinzufuegen des Plugins zur lokalen Datenbank
	    					installedPluginName.get(requestCode), 
	    					installedPluginPackageName.get(requestCode), 0);
	    	}
	    	if(requestCode == 0)														//wenn dies der der requestCode des als erstes gestarteten Install-Intents ist
	    		reloadFragment();														//Fragment neu laden
	    }
	    else if (requestCode >= 1000){													//wenn der beendete Intent eine Deinstallation war
	    	if(!installed(packageUninstall.get(requestCode-1000))){						//wenn das Plugin erfolgreich deinstalliert wurde
	    		db.deletePlugin(uninstalledPluginId.get(requestCode-1000));				//Plugin aus der lokalen Datenbank loeschen
	    	}
	    	if(installedPluginId.size()==0 && requestCode==1000)						//wenn kein Plugin zur Installation ausgewaehlt war und wenn dies der requestCode des als erstes gestarteten Unistall-Intents ist						
	    		reloadFragment();														//Fragment neu laden
	    		Log.d("", "reload Fragment");
	    }
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode untersucht, ob ein Plugin mit dem uebergebenen Package-Namen
	//instaliert ist und gibt dementsprechend true oder false zurueck.
	////////////////////////////////////////////////////////////////////////////////////
	private boolean installed(String pluginPackageName){
		PackageManager pm = context.getPackageManager();
		try {
			pm.getPackageInfo(pluginPackageName, PackageManager.GET_ACTIVITIES);
			return true;
		} catch (NameNotFoundException e) {
			return false;
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Serververbingung ueberpruefen
	////////////////////////////////////////////////////////////////////////////////////
    private void isServerReachable() {
    	Thread thread = new Thread()
		{
			@Override
			public void run() {
				ConnectivityManager cm = (ConnectivityManager)context.
						getSystemService(Context.CONNECTIVITY_SERVICE);
				NetworkInfo netInfo = cm.getActiveNetworkInfo();
				if (netInfo != null && netInfo.isConnected()) {
					try {
						URL url = new URL(SERVER_IP);   
						HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
						urlc.setConnectTimeout(10 * 1000);          
						urlc.connect();
						if (urlc.getResponseCode() == 200) {        
							serverConnection = true;
						} else {
							serverConnection = false;
						}
					} catch (MalformedURLException e1) {
						serverConnection = false;
					} catch (IOException e) {
						serverConnection = false;
					}
				}
			}
		};
		thread.start();
		try {
			thread.join();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}	
	
	////////////////////////////////////////////////////////////////////////////////////
	//Methode fuer das erneute Laden des Fragments
	////////////////////////////////////////////////////////////////////////////////////
	private void reloadFragment(){
		FragmentManager fragmentManager = getFragmentManager();
	    FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();
	    getFragmentManager().beginTransaction().remove(this).commit();
		Plugins plugins = new Plugins(context);
		fragmentTransaction.add(R.id.fragment_container, plugins);
		fragmentTransaction.commit();
	}
}
