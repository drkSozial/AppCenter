package de.drk.plugin.settings.neu.Helper;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;

import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.message.BasicNameValuePair;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import de.drk.plugin.settings.neu.Helper.WebServiceParser;

/**
 * 
 * @author Peter Ewert
 *
 */

public class RemoteDB {

	private static String serverAdress = "http://212.100.43.180";
	
	public static void insertPlugin(int pluginId, int clientId, int pluginPosition){
		
		HttpClient httpclient = new DefaultHttpClient();
		
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		
		nameValuePair.add(new BasicNameValuePair("pluginId",Integer.toString(pluginId)));
	   	nameValuePair.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));
	   	nameValuePair.add(new BasicNameValuePair("pluginPosition",Integer.toString(pluginPosition)));
	   	
	   	HttpPost httppost = new HttpPost(serverAdress + "/insertPluginNeu.php");

		try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair));
			httpclient.execute(httppost);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void deletePlugin(int pluginId, int clientId){
		
		HttpClient httpclient = new DefaultHttpClient();
		
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
	 
	   	nameValuePair.add(new BasicNameValuePair("pluginId",Integer.toString(pluginId)));
	   	nameValuePair.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));

		HttpPost httppost = new HttpPost(serverAdress + "/deletePluginNeu.php");
			
        try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair));
			httpclient.execute(httppost);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static JSONArray getUserPlugins(int clientId){
		
		JSONObject json;
		JSONArray plugins = null;
		
		WebServiceParser jParser = new WebServiceParser();

		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		 
	   	nameValuePair.add(new BasicNameValuePair("ClientId",Integer.toString(clientId)));
		
		json = jParser.sendEntityGetJSONFromUrl(serverAdress + "/userPluginsNeu.php", nameValuePair);
	
		try {
			plugins = json.getJSONArray("userPlugins");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return plugins;
	}
	
	public static JSONArray getAllPlugins(){
		
		JSONObject json;
		JSONArray plugins = null;

		json = WebServiceParser.getJSONFromUrl(serverAdress + "/allPluginsNeu.php");
	
		try {
			plugins = json.getJSONArray("allPlugins");
		} catch (JSONException e) {
			e.printStackTrace();
		}
		
		return plugins;
	}
	
	public static void updatePluginPosition(int pluginId, int clientId, int position){
		
		HttpClient httpclient = new DefaultHttpClient();
		
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		
		nameValuePair.add(new BasicNameValuePair("pluginId",Integer.toString(pluginId)));
	   	nameValuePair.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));
	   	nameValuePair.add(new BasicNameValuePair("position",Integer.toString(position)));
	   	
	   	HttpPost httppost = new HttpPost(serverAdress + "/updateClientPluginPositionNeu.php");

		try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair));
			httpclient.execute(httppost);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}	
	}
	
	public static void deleteUserPlugins(int clientId){
		
		HttpClient httpclient = new DefaultHttpClient();
		
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		
		nameValuePair.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));
		
		HttpPost httppost = new HttpPost(serverAdress + "/deleteUserPluginsNeu.php");

		try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair));
			httpclient.execute(httppost);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	public static void setChangeFlag(int clientId, String cFlagName, int value){
		
		HttpClient httpclient = new DefaultHttpClient();
		
		ArrayList<NameValuePair> nameValuePair = new ArrayList<NameValuePair>();
		
		nameValuePair.add(new BasicNameValuePair("clientId",Integer.toString(clientId)));
		nameValuePair.add(new BasicNameValuePair("cFlagName",cFlagName));
		nameValuePair.add(new BasicNameValuePair("value",Integer.toString(value)));
	   	
	   	HttpPost httppost = new HttpPost(serverAdress + "/setChangeFlagNeu.php");

		try {
			httppost.setEntity(new UrlEncodedFormEntity(nameValuePair));
			httpclient.execute(httppost);
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	 	
}
