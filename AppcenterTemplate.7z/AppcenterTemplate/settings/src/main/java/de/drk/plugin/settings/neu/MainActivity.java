package de.drk.plugin.settings.neu;

import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;

import de.drk.template.neu.AppcenterTemplate;
import de.drk.plugin.settings.neu.R;
import de.drk.plugin.settings.neu.Helper.DatabaseHelper;
import de.drk.plugin.settings.neu.Helper.RemoteDB;
import de.drk.plugin.settings.neu.Helper.RemoteToLocal;
import android.app.FragmentManager;
import android.app.FragmentTransaction;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.SharedPreferences.Editor;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

/**
 * 
 * @author Peter Ewert
 *
 */

/**
 * @class MainActivity
 * @brief MainActivity des Appcenter-Plugins "Einstellungen"
 * 
 * Diese Activity ist fuer das Management der zwei Fragmente "Konfiguration" und 
 * "Plugins" zustaendig. Hier findet die Speicherung der Konfiguration statt und es 
 * werden die Aktionen, die bei Klicks auf die Standard-Seitennavigation gestartet
 * werden, angepasst.
 */

public class MainActivity extends AppcenterTemplate implements OnClickListener{			//erbt von der Library-Project-Klasse "AppcenterTemplate"

	private final String SERVER_IP = "http://212.100.43.180";
	
	Config config = new Config(this);													//Fragment des Konfigurations-Tools
	Plugins plugins = new Plugins(this);												//Fragment fuer das Plugin-Installations-Deinstallations-Tool
	
	FragmentManager fragmentManager;
	
	DatabaseHelper db;
	
	Context context;

	////////////////////////////////////////////////////////////////////////////////////
	//Methode, die nach Erstellung der Activity aufgerufen wird.
	////////////////////////////////////////////////////////////////////////////////////
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        
        setLayout(R.layout.activity_main);												//Aufruf der von "AppcenterTemplate" geerbten Klasse zum setzen des Layouts
				
        int clientId = getIntent().getIntExtra("clientId", -1);
        Log.d("", "ClientId = " + clientId);
        if(clientId != -1){
        	SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this);
        	Editor editor = sharedPreferences.edit();
			editor.putInt("clientId", clientId);
			editor.commit();
			Log.d("", "ClientId = " + sharedPreferences.getInt("clientId", -1));
        }
        
        context = this;
        
        loadConfig();																	//Laden der Plugin-Konfiguration aus der Server-Datenbank

        db = new DatabaseHelper(this);													//Instanz von DatenbankHelfer zum Zugriff auf die lokale Datenbank
        
        fragmentManager = getFragmentManager();											//Instanz des Fragment-Managers
        FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();	//Starten von Transaktionen der Fragments
        fragmentTransaction.add(R.id.fragment_container, config);						//Setzen des Fragments "config" in das FrameLayout fragment_container (siehe XML)
        fragmentTransaction.commit();													//Anwenden der Transaktion
        
        ImageView tab1 = (ImageView)findViewById(R.id.tab_config);
        tab1.setOnClickListener(this);													//Setzen des onClick-Listeners fuer den Button "Konfiguration"
        
        ImageView tab2 = (ImageView)findViewById(R.id.tab_plugin);
        tab2.setOnClickListener(this);													//Setzen des onClick-Listeners fuer den Button "Plugins"
        
        getSidebarClicks();																//Setzen des onClick-Listeners fuer die Side-Bar-Buttons
    }

	////////////////////////////////////////////////////////////////////////////////////
	//Laden der Plugin-daten der Server-Datenbank und Speichern in der lokalen Datenbank
	////////////////////////////////////////////////////////////////////////////////////
	public void loadConfig(){
		Thread thread = new Thread()
		{
			@Override
			public void run() {
				if(isServerReachable()){
					RemoteToLocal remoteToLocal;
					remoteToLocal = new RemoteToLocal(context);							//Instanz der Klasse RemoteToLocal, die fuer die Verbindung zwischen lokaler Datenbank und Server-Datenbank zustaendig ist
					remoteToLocal.remotetolocalConfig();								//Laden der Plugin-Konfigurationsdaten in die lokale Datenbank
				}
				else{
					Log.d("Serververbindung", "Server ist nicht erreichbar.");
					runOnUiThread(new Runnable(){
						@Override
						public void run(){
							Toast.makeText(context,										//Nachricht auf UI-Thread ausgeben
							"Keine Server-Verbindung.Konfiguration wurde nicht geladen.",
							Toast.LENGTH_SHORT).show();
						}
					});
				}
			}
		};
		thread.start();
		try {
			thread.join();																//Warten, bis der Thread durchgelaufen ist
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Serververbingung ueberpruefen
	////////////////////////////////////////////////////////////////////////////////////
	public boolean isServerReachable() {
		ConnectivityManager cm = (ConnectivityManager)this.
				getSystemService(Context.CONNECTIVITY_SERVICE);
		NetworkInfo netInfo = cm.getActiveNetworkInfo();
		if (netInfo != null && netInfo.isConnected()) {
			try {
				URL url = new URL(SERVER_IP);   
				HttpURLConnection urlc = (HttpURLConnection) url.openConnection();
				urlc.setConnectTimeout(10 * 1000);          
				urlc.connect();
				if (urlc.getResponseCode() == 200) {        
					return true;
				} else {
					return false;
				}
			} catch (MalformedURLException e1) {
				return false;
			} catch (IOException e) {
				return false;
			}
		}
		return false;
	}


	////////////////////////////////////////////////////////////////////////////////////
	//Überpruefung der Klicks
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void onClick(View v) {
		ImageView tab_config = (ImageView)findViewById(R.id.tab_config);
        ImageView tab_plugin = (ImageView)findViewById(R.id.tab_plugin);
        Intent intent = new Intent();
		switch (v.getId()){
		case R.id.homeButton:	
			if(config.isVisible()){
				saveConfig();															
			}
			saveConfigToRemoteDB();											
			intent.setClassName("de.drk.appcenter.neu",
					"de.drk.appcenter.neu.MainActivity");
			startActivity(intent);														//Neustart der Haupt-App, damit Konfiguration uebernommen wird. In onButton() von AppcenterTemplate wird nur die aktuelle Activity beendet.
			overridePendingTransition(0, 0);
			break;
			//wenn auf den Home-
		case R.id.searchButton:															//oder Suche-Button geklickt wurde
			if(config.isVisible()){
				saveConfig();															//Konfiguration in lokaler Datenbank speichern
			}
			saveConfigToRemoteDB();														//Konfiguration in Server-Datenbank speichern
			//super.onButtonClick(v);														//Aufruf der AppcenterTemplate-Methode onButton() fuehr die Ausfuehrung der Standard-Aktionen
			break;
		case R.id.backButton:															//wenn der Zurueck-Button geklickt wurde
			if(config.isVisible()){
				saveConfig();															
			}
			saveConfigToRemoteDB();											
			intent.setClassName("de.drk.appcenter.neu",
					"de.drk.appcenter.neu.MainActivity");
			startActivity(intent);														//Neustart der Haupt-App, damit Konfiguration uebernommen wird. In onButton() von AppcenterTemplate wird nur die aktuelle Activity beendet.
			overridePendingTransition(0, 0);
			break;
		case R.id.tab_config:
			if(!config.isVisible()){
				tab_plugin.setBackgroundResource(R.drawable.button_plugins);				//"Plugins"-Button auf inaktiv setzen
				tab_config.setBackgroundResource(R.drawable.button_config_active);			//"Konfiguration"-Button auf aktiv setzen
		        
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();	//Neue Fragment-Transaktion starten
				
		        getFragmentManager().beginTransaction().remove(plugins).commit();
				config = new Config(this);													//Neue Instanz des Fragments "Konfiguration"
				fragmentTransaction.add(R.id.fragment_container, config);					//Fragment "Konfiguration" setzen
				fragmentTransaction.commit();												//Transaktion anwenden
			}
			break;
		case R.id.tab_plugin:
			if(config.isVisible()){
				saveConfig();																//Konfiguration lokal speichern
				tab_config.setBackgroundResource(R.drawable.button_config);					//"Konfiguration"-Button auf inaktiv setzen
				tab_plugin.setBackgroundResource(R.drawable.button_plugins_active);			//"Plugins"-Button auf aktiv setzen
				
				FragmentTransaction fragmentTransaction = fragmentManager.beginTransaction();	//Neue Fragment-Transaktion starten
				
				getFragmentManager().beginTransaction().remove(config).commit();
				plugins = new Plugins(this);												//Neue Instanz des Fragments "Plugins"
				fragmentTransaction.add(R.id.fragment_container, plugins);					//Fragment "Konfiguration" setzen
				fragmentTransaction.commit();												//Transaktion anwenden
			}
			break;
		}
	}

	////////////////////////////////////////////////////////////////////////////////////
	//onClick-Listener auf Home-, Zurueck-, und Suche-Button setzen
	////////////////////////////////////////////////////////////////////////////////////
	public void getSidebarClicks(){
		ImageButton homeButton = (ImageButton)findViewById(R.id.homeButton);
		homeButton.setOnClickListener(this);
		ImageButton backButton = (ImageButton)findViewById(R.id.backButton);
		backButton.setOnClickListener(this);
		ImageButton searchButton = (ImageButton)findViewById(R.id.searchButton);
		searchButton.setOnClickListener(this);
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Konfiguration lokal speichern
	////////////////////////////////////////////////////////////////////////////////////
	public void saveConfig(){
		LinearLayout wrapper = (LinearLayout)findViewById(R.id.wrapper);
		int position;

		for (int i = 0; i < wrapper.getChildCount(); i++){								//durchlaufen der Kind-Elemente des Wrappers (Seiten "Nicht platzierte Anwendungen", "Erste Seite", "Zweite Seite" und "Dritte Seite")
    	   LinearLayout linearLayout = (LinearLayout) wrapper.getChildAt(i);
    	   for (int j = 1; j < linearLayout.getChildCount(); j++) {						//durchlaufen der inneren LinearLayouts der Seiten
    		   LinearLayout ll_child = (LinearLayout) linearLayout.getChildAt(j);
    		   for(int k=0; k<ll_child.getChildCount(); k++){							//durchlaufen der FrameLayouts
    			   FrameLayout fr = (FrameLayout)ll_child.getChildAt(k);
    			   if(fr.getChildCount() > 0){											//untersuchen, ob das FrameLayout ein Kind-Element hat
    				   FrameLayout flButton = (FrameLayout)fr.getChildAt(0);
    				   if(i==0){
    					   position = 0;												//wenn das FrameLayout sich in der Seite "Nicht platzierte Anwendungen" befindet
    				   }
    				   else{
    					   position = k+4*(j-1)+i*10;									//wenn das FrameLayout sich auf einer der anderen Seiten befindet, Position berechnen
    				   }
    				   db.updatePluginPosition(flButton.getId(), position);				//aktualisieren der Position in der lokalen Datenbank
    			   }						
    		   }
    	   }
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Konfiguration in der Server-Datenbank speichern
	////////////////////////////////////////////////////////////////////////////////////
	public void saveConfigToRemoteDB(){
		Thread thread = new Thread()
		{
			@Override
			public void run() {
				if(isServerReachable()){
					int[] pluginId = db.getPluginId();									//Daten aus lokaler Datenbank laden
					int[] pluginPosition = db.getPluginPosition();
					
					SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
		        	int clientId =sharedPreferences.getInt("clientId", -1);
					
					RemoteDB.deleteUserPlugins(clientId);									//Plugins des Users aus der Server-datenbank loeschen
					
					for(int i=0; i<pluginId.length; i++){
						Log.d("", "PluginId: " + pluginId[i] );
						RemoteDB.insertPlugin(pluginId[i], clientId, pluginPosition[i]);		//Plugin fuer den User in der Server-Datenbank einfuegen
					}
					//RemoteDB.setChangeFlag(clientId, 1, 1);									//Change-Flag in der Server-Datenbank setzen
					RemoteDB.setChangeFlag(clientId,"Plugin",1);
					Log.d("", "saveConfigPlugintoRemote");
				}
				else{
					Log.d("Serververbindung", "Server ist nicht erreichbar.");
					runOnUiThread(new Runnable(){
						@Override
						public void run(){
							Toast.makeText(context,"Keine Server-Verbingung. " +		//Nachricht auf UI-Thread ausgeben
									"Daten wurden nicht uebertragen.",
									Toast.LENGTH_SHORT).show();
						}
					});
				}
			}
		};
		thread.start();
		try {
			thread.join();																//warten, bis der Thread durchgelaufen ist
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
}