package de.drk.plugin.settings.neu.Helper;

import org.json.JSONArray;
import org.json.JSONObject;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;
import android.util.Log;

public class RemoteToLocal {
	
	Context context;
	
	private DatabaseHelper db;
	
	public RemoteToLocal(Context context){
		this.context = context;
		this.db = new DatabaseHelper(context);
	}

	public void remotetolocalConfig() {
		
		JSONArray plugins;

		try {
        	SharedPreferences sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context);
        	int clientId = sharedPreferences.getInt("clientId", -1);
        	Log.d("", "remotetolocal clientId: " + clientId);
			plugins = RemoteDB.getUserPlugins(clientId);
			
			if(db != null)
				db.resetTablePlugin();

			for(int i = 0; i < plugins.length(); i++){
				JSONObject c = plugins.getJSONObject(i);
				int pluginId = c.getInt("PLUGIN_ID");
				String pluginName = c.getString("NAME");
				String pluginPackageName = c.getString("PACKAGENAME");
				int pluginPosition = c.getInt("POSITION");
				db.addPlugin(pluginId, pluginName, pluginPackageName, pluginPosition);

			}

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
}
