package de.drk.plugin.settings.neu.Helper;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

/**
 * @class DatenbankHelfer
 * 
 * @brief Die Klasse DatabaseHelper dient dem Zugriff auf die lokale Datenbank.
 * Über Getter und Setter koenne Daten gelesen und in die Datenbank geschrieben werden. 
 *
 */

public class DatabaseHelper extends SQLiteOpenHelper {
	private static final String PLUGINID = "pluginId";
	private static final String PLUGINNAME = "pluginName";
	private static final String PLUGINPACKAGENAME = "pluginPackageName";
	private static final String PLUGINPOSITION = "pluginPosition";
	private static final String TABLE_PLUGIN = "plugin";
	private static final String DB_NAME = "database.db";
	private static final int DB_VERSION = 1;
	private static final String TAB_CREATE_PLUGIN =
			"CREATE TABLE plugin ("
					+ "id INTEGER PRIMARY KEY AUTOINCREMENT,"
					+ "pluginId INTEGER,"
					+ "pluginName TEXT,"
					+ "pluginPackageName TEXT,"
					+ "pluginPosition INTEGER);";

	private static final String PLUGIN_DROP = 
			"DROP TABLE IF EXISTS plugin";

	public DatabaseHelper(Context context) {
		super(context, DB_NAME, null, DB_VERSION);
	}
	
	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL(TAB_CREATE_PLUGIN);
	}
	
	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

	}

	public void addPlugin(int pluginId, String pluginName, String pluginPackageName, int pluginPosition) {
		SQLiteDatabase db = this.getWritableDatabase();  
		ContentValues values = new ContentValues();
		values.put(PLUGINID, pluginId); 
		values.put(PLUGINNAME, pluginName);
		values.put(PLUGINPACKAGENAME, pluginPackageName);
		values.put(PLUGINPOSITION, pluginPosition);
		db.insert(TABLE_PLUGIN, null, values);
		db.close();
	}

	public void deletePlugin(int pluginId){
		SQLiteDatabase db = this.getReadableDatabase();
		String where = "pluginId = " + pluginId;
		db.delete(TABLE_PLUGIN, where, null);
	}
	
	public String[] getPluginName(){
		
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = 
				db.query("plugin", 
						new String[] {"pluginName"}, 
						"", 
						null, 
						null, 
						null, 
						"pluginName ASC");
		
		Cursor.moveToFirst();
		String[] pluginName = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			pluginName[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}
		
		db.close();
		return pluginName;
	}
	
	public String[] getPluginPackageName(){
		
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = 
				db.query("plugin", 
						new String[] {"pluginPackageName"}, 
						"", 
						null, 
						null, 
						null, 
						"pluginName ASC");
		
		Cursor.moveToFirst();
		String[] pluginPackageName = new String[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			pluginPackageName[i]=Cursor.getString(0);
			Cursor.moveToNext();

		}
		
		db.close();
		return pluginPackageName;
	}
	
	public int[] getPluginId(){
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = 
				db.query("plugin", 
						new String[] {"pluginId"}, 
						"", 
						null, 
						null, 
						null, 
						"pluginName ASC");
		
		Cursor.moveToFirst();
		int[] pluginId = new int[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			pluginId[i]=Cursor.getInt(0);
			Cursor.moveToNext();
		}
		
		db.close();
		return pluginId;
	}
	
	public int[] getPluginPosition(){
		SQLiteDatabase db = this.getReadableDatabase(); 
		Cursor Cursor = 
				db.query("plugin", 
						new String[] {"pluginPosition"}, 
						"", 
						null, 
						null, 
						null, 
						"pluginName ASC");
		
		Cursor.moveToFirst();
		int[] pluginPosition = new int[Cursor.getCount()];
		for (int i = 0; i < Cursor.getCount(); i++) {

			pluginPosition[i]=Cursor.getInt(0);
			Cursor.moveToNext();
		}
		
		db.close();
		return pluginPosition;
	}
	
	public void updatePluginPosition(int pluginId, int pluginPosition){
		SQLiteDatabase db = this.getWritableDatabase();
		
		ContentValues cv = new ContentValues();
		cv.put(PLUGINPOSITION, pluginPosition);
		db.update(TABLE_PLUGIN, cv, PLUGINID + "= " + pluginId, null);
		
		db.close();
	}

	public void resetTablePlugin(){
		SQLiteDatabase db = this.getWritableDatabase();
		db.execSQL(PLUGIN_DROP);
		db.execSQL(TAB_CREATE_PLUGIN);
	}
	
}
