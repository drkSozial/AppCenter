package de.drk.plugin.settings.neu;

import java.util.ArrayList;
import java.util.List;

import de.drk.plugin.settings.neu.R;
import de.drk.plugin.settings.neu.Helper.DatabaseHelper;
import de.drk.plugin.settings.neu.Helper.PluginButton;
import android.app.Fragment;
import android.content.Context;
import android.content.pm.PackageManager.NameNotFoundException;
import android.os.Bundle;
import android.util.Log;
import android.view.DragEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.DragShadowBuilder;
import android.view.View.OnClickListener;
import android.view.View.OnDragListener;
import android.view.View.OnTouchListener;
import android.view.WindowManager.LayoutParams;
import android.widget.FrameLayout;
import android.widget.LinearLayout;

/**
 * 
 * @author Peter Ewert
 *
 */

/**
 * @class Config
 * @brief Konfigurations-Tool der App "Appcenter"
 * 
 * Dieses Fragment ist das Konfigurations-Tool der App "Appcenter". Es kann ueber 
 * Drag-and-Drop die Position der Plugin-Buttons in "Appcenter" bestimmt werden.
 */

public class Config extends Fragment 													//erbt von android.app.Fragment
					implements OnClickListener,OnDragListener,OnTouchListener{
	
	private final int[] FIRST_POS = {10,20,30};											//erster Positions-Wert auf den Seiten "Erste Seite", "Zweite Seite" und "Dritte Seite"
	private final int PAGE_ROWS = 2;													//Zeilen pro Seite
	private final int BUTTONS_PER_ROW = 4;												//Buttons pro Zeile
	
	private final int LL_WEIGHT_OPEN = 10;												//LinearLayout-Weight-Wert fuer die aufgeklappte Seite
	private final int LL_WEIGHT_CLOSED = 1;												//LinearLayout-Weight-Wert fuer die zugeklappten Seiten
	
	private View view;
	private Context context;
	private DatabaseHelper db;
	private FrameLayout flButton;
	private List<Integer> frameLayoutIds = new ArrayList<Integer>();
	private List<Integer> buttonIdsMoved = new ArrayList<Integer>();
	private List<Integer> frameIdsMoved = new ArrayList<Integer>();
	private PluginButton button;
	private int buttonSizeBig,
				textSizeBig,
				buttonSizeSmall,
				textSizeSmall;

	public Config() {
	}

	////////////////////////////////////////////////////////////////////////////////////
	//Konstruktor, mit dem der Kontext der aufrufenden Activity uebergeben wird.
	////////////////////////////////////////////////////////////////////////////////////
	public Config(Context context){
		this.context = context;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Methode, die nach Erstellung des Fragments aufgerufen wird.
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container, 
	                           Bundle savedInstanceState){
		view = inflater.inflate(R.layout.fragment_config, container, false);
	
		db = new DatabaseHelper(context);
		
		setListeners();
		
		getSize();																		//Bestimmen der Groesse der ImageButtons und TextViews abhaengig von den Bilschirmeigenschaften											
		
		frameLayoutIds = getFrameLayoutIds();											
		
		button = new PluginButton(context);												//PluginButton liefert Methoden fuer die Erstellung eines Buttons
		placeButtons();
		
		return view;	
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//getSize bestimmt die Groesse der ImageButtons und des Textes in den TextViews 
	//abhaengig von den Bilschirmeigenschaften
	////////////////////////////////////////////////////////////////////////////////////
	private void getSize(){
		int screenWidth;
		int scaledDensity;
		
		screenWidth = context.getResources().getDisplayMetrics().widthPixels;			//Ermitteln der Bildschirmeigenschaften
		scaledDensity = (int) context.getResources().getDisplayMetrics().scaledDensity;

		buttonSizeBig = screenWidth/7;													//Groesse von ImageButton und TextView fuer grosse Darstellung 
		textSizeBig = (screenWidth/40)/scaledDensity;

		buttonSizeSmall = screenWidth/9;												//Groesse von ImageButton und TextView fuer kleine Darstellung
		textSizeSmall = (screenWidth/50)/scaledDensity;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//setPlacedButtons() setzt die Buttons der  Plugins an die in der Datenbank 
	//gespeicherte Position.
	////////////////////////////////////////////////////////////////////////////////////
	private void placeButtons(){
		
		int[] buttonId = null;
		String[] pluginPackageName = null;
		int[] position = null;
		
		buttonId = db.getPluginId();													//Auslesen der benoetigten Daten aus der Datenbank.
		pluginPackageName = db.getPluginPackageName();									//Diese werden als Arrays zurueckgegeben.		
		position = db.getPluginPosition();
		
		for(int i=0; i<buttonId.length; i++){											//Durchlaufen aller Datenbankeintraege
			
			FrameLayout frameLayoutButton;
			
			try {
				frameLayoutButton = button.createButtonFromPlugin(pluginPackageName[i],			//Erstellen eines FrameLayout-Buttons mithilfe der Klasse PluginButton
						buttonId[i], buttonSizeBig, textSizeBig);
				
				///////////////////////////////////////////////////////////////////////
				//if-Abfrage, auf welcher Seite der Framelayout-Button platziert werden
				//soll. Bei 
				//			position<10 	-> unter Alle Anwendungen
				//			9<position<18	-> unter Erste Seite
				//			19<position<28	-> unter Zweite Seite
				//			29<position<38	-> unter Dritte Seite
				if(position[i] < FIRST_POS[0]){													
					button.resizeButton(frameLayoutButton,buttonSizeSmall,textSizeSmall);		//Verkleinern des Buttons, da Buttons unter Alle Anwendungen kleiner dargestellt werden
					setButtonFirstEmpty(R.id.row1,frameLayoutButton);							//Setzen des FarmeLayout-Buttons in das erste freie FrameLayout
				}
				else if(position[i] >= FIRST_POS[0] && 
						position[i] < FIRST_POS[0]+PAGE_ROWS*BUTTONS_PER_ROW){
					///////////////////////////////////////////////////////////////////
					//if-Abfrage, ob Position in der ersten oder zweiten Reihe der 
					//Seite
					if(position[i] < FIRST_POS[0]+BUTTONS_PER_ROW){
						setButton(R.id.row21, position[i]-FIRST_POS[0],frameLayoutButton);		//FrameLayout-Button in erster Reihe an Position "position[i]-10" unter "Erste Seite" setzen	
					}
					else{
						setButton(R.id.row22, 													//FrameLayout-Button in zweiter Reihe unter "Erste Seite" setzen
								position[i]-(FIRST_POS[0]+BUTTONS_PER_ROW),frameLayoutButton);		
					}
				}
				else if(position[i] >= FIRST_POS[1] && 
						position[i] < FIRST_POS[1]+PAGE_ROWS*BUTTONS_PER_ROW){
					if(position[i] < FIRST_POS[1]+BUTTONS_PER_ROW){
						setButton(R.id.row31, position[i]-FIRST_POS[1], frameLayoutButton);
					}
					else{
						setButton(R.id.row32, 
								position[i]-(FIRST_POS[1]+BUTTONS_PER_ROW),frameLayoutButton);
					}
				}
				else if(position[i] >= FIRST_POS[2] && 
						position[i] < FIRST_POS[2]+PAGE_ROWS*BUTTONS_PER_ROW){
					if(position[i] < 34){
						setButton(R.id.row41, position[i]-FIRST_POS[2], frameLayoutButton);
					}
					else{
						setButton(R.id.row42, 
								position[i]-(FIRST_POS[2]+BUTTONS_PER_ROW),frameLayoutButton);
					}
				}
			} catch (NameNotFoundException e) {
				Log.d("package_not_found", "Das Paket " + pluginPackageName[i] +		//Log ausgeben, wenn das Paket auf dem Geraet nicht gefunden wurde
						" konnte nicht gefunden werden.");
			}
		}
			
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode fuegt einen Button (bestehend aus Bild und Name) in das FrameLayout,
	//dessen Position, welche es in dem uebergeordneten LinearLayout einnimmt, uebergeben 
	//wird.
	////////////////////////////////////////////////////////////////////////////////////
	private void setButton(int parentLLId, int parentFLPosition, FrameLayout flButton){
		LinearLayout ll = (LinearLayout) view.findViewById(parentLLId);
		FrameLayout fl = (FrameLayout) ll.getChildAt(parentFLPosition);
		
		fl.addView(flButton);															//hinzufuegen des Fraemlayout-Buttons
		
		flButton.setOnTouchListener(this);												//setzen des OnTouch-Listeners fuer den FrameLayout-Button
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode fuegt einen Button (bestehend aus Bild und Name) in das erste freie
	//FrameLayout des uebergebenen LinearLayouts.
	////////////////////////////////////////////////////////////////////////////////////
	private void setButtonFirstEmpty(int linearLayoutId, FrameLayout flButton){
		FrameLayout fl = getFirstEmptyFrameLayout(linearLayoutId);						//Finden des ersten freien FrameLayouts unter dem LinearLayout mit der uebergebenen ID
		
		if(fl != null){
			fl.addView(flButton);														//hinzufuegen des Fraemlayout-Buttons
		
			flButton.setOnTouchListener(this);											//setzen des OnTouch-Listeners fuer den FrameLayout-Button
		}
		else{
			Log.d("setButtonFirstEmpty", "kein freies FrameLayout. " +
					"Button konnte nicht gesetzt werden");
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode sucht das erste leere FrameLayout in dem LinearLayout mit der 
	//uebergebenen ID
	////////////////////////////////////////////////////////////////////////////////////
	private FrameLayout getFirstEmptyFrameLayout(int linearLayoutId){
		
		LinearLayout page = (LinearLayout) view.findViewById(linearLayoutId);
		LinearLayout ll;
		FrameLayout fl = null;
		boolean found = false;
		
		for (int i = 1; i < page.getChildCount(); i++) {								//Kind-Elemente des LinearLayouts mit der uebergebenen ID werden durchlaufen 
			ll = (LinearLayout) page.getChildAt(i);
			for (int j=0; j < ll.getChildCount(); j++){									//Kind-Elemente des Untergeordneten LinearLayouts werden durchlaufen
				fl = (FrameLayout) ll.getChildAt(j);
				if (fl.getChildCount() == 0) {											//Abfrage, ob FrameLayout Kind-Elemente enthaelt
					found = true;														
					return fl;															//Rueckgabe des ersten leeren FrameLayouts
				}
			}
			if(found)																	//wenn leeres FrameLayout gefunden wurde -> beenden der Schleife
				break;
		}
		
		return null;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Setzen des onClickListeners fuer die LinearLayouts und des onDragListeners fuer 
	//jeden Frame des Layouts
	////////////////////////////////////////////////////////////////////////////////////
	private void setListeners() {
		LinearLayout wrapper = (LinearLayout)view.findViewById(R.id.wrapper);
		
		for(int i=0; i<wrapper.getChildCount(); i++){									//Durchlaufen der einzelnen Seiten (Alle Anwendungen, Erste Seite, ...)
			LinearLayout ll = (LinearLayout)wrapper.getChildAt(i);
			ll.setOnDragListener(this);													//Setzen des OnDrag-Listeners
			ll.setOnClickListener(this);												//Setzen des OnClick-Listeners
			for(int j=1; j<ll.getChildCount(); j++){									//Durchlaufen der Kind-Elemente der einzelnen Seiten (Alle Anwendungen, Erste Seite, ...)
				LinearLayout ll_child = (LinearLayout)ll.getChildAt(j);
				for(int k=0; k<ll_child.getChildCount(); k++){							//Durchlaufen der FrameLayouts
					FrameLayout fr = (FrameLayout)ll_child.getChildAt(k);
					if(fr.getParent().getParent() != wrapper.getChildAt(0))
						fr.setOnDragListener(this);										//Setzen des OnDrag-Listeners
				}
			}
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Ermitteln der IDs aller FrameLayouts auf den Seiten Erste Seite, Zweite Seite und
	//Dritte Seite
	////////////////////////////////////////////////////////////////////////////////////
	private List<Integer> getFrameLayoutIds(){
		
		List<Integer> frameLayoutIds = new ArrayList<Integer>();
		
		LinearLayout wrapper = (LinearLayout)view.findViewById(R.id.wrapper);
		
		for(int i=1; i<wrapper.getChildCount(); i++){									//Durchlaufen der Seiten (Erste Seite, Zweite Seite, Dritte Seite)
			LinearLayout ll = (LinearLayout)wrapper.getChildAt(i);
			for(int j=1; j<ll.getChildCount(); j++){									//Durchlaufen der Kind-Elemente der einzelnen Seiten (Alle Anwendungen, Erste Seite, ...)
				LinearLayout ll_child = (LinearLayout)ll.getChildAt(j);
				for(int k=0; k<ll_child.getChildCount(); k++){							//Durchlaufen der FrameLayouts
					FrameLayout fr = (FrameLayout)ll_child.getChildAt(k);
					frameLayoutIds.add(fr.getId());										//Hinzufuegen der ID
				}
			}
		}
		return frameLayoutIds;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode verschiebt den FrameLayout-Button des uebergebenen FrameLayout in 
	//das rechts oder links daneben liegende FrameLayout.
	////////////////////////////////////////////////////////////////////////////////////
	private void moveView(FrameLayout fl) {
    	if(fl.getChildCount() != 0 && fl.getChildAt(0) != flButton){					//wenn das FrameLayout nicht leer ist und der gezogene Button nicht das Kind-Element des FrameLayouts ist
    		boolean flag = false;
    		boolean moveForward = true;
    		int framePositionInList = frameLayoutIds.indexOf(fl.getId());				//Ermitteln der Position der ID des FrameLayout-Buttons in der List FrameLayoutIds
    		FrameLayout flCheck;
    		FrameLayout flNew = null;
    		int loop = 0;
    		///////////////////////////////////////////////////////////////////////////
    		//erstes freies FrameLayout in Vorwaerts- oder Rueckwaertsrichtung finden
    		while(!flag){
    			loop++;
    			if(framePositionInList+loop < frameLayoutIds.size()-1){					
	    			flCheck = (FrameLayout) view.findViewById							//Naechstes FrameLayout in Vorwaerts-Richtung
	    					(frameLayoutIds.get(framePositionInList+loop));
	    			if(flCheck.getChildCount() == 0 || 
	    					flCheck.getChildAt(0) == flButton){							//Abfrage, ob FrameLayout leer ist oder der unsichtbare Button der gezogen wird sich in diesem befindet
	    				flag = true;													//wenn ja, Schleife beenden
	    				moveForward = true;												//Verschiebe-Richtung vorwaerts
	    			}
    			}
    			
    			if(framePositionInList-loop > 0){
	    			flCheck = (FrameLayout) view.findViewById							//Naechstes FrameLayout in Rueckwaerts-Richtung
	    					(frameLayoutIds.get(framePositionInList-loop));
	    			if(flCheck.getChildCount() == 0|| 
	    					flCheck.getChildAt(0) == flButton){							//Abfrage, ob FrameLayout leer ist oder der unsichtbare Button der gezogen wird sich in diesem befindet
	    				flag = true;													//wenn ja, Schleife beenden			
	    				moveForward = false;											//Verschiebe-Richtung rueckwaerts
	    			}
    			}
    		}
    		FrameLayout flButton = (FrameLayout) fl.getChildAt(0);						//FrameLayout-Button des uebergebenen FrameLayouts
    		buttonIdsMoved.add(flButton.getId());										//ID des FrameLayout-Buttons zu der List buttonIdsMove hinzufuegen
    		frameIdsMoved.add(fl.getId());												//ID des FrameLayouts zu der List frameIdsMove hinzufuegen
    		if(moveForward){
    			flNew = (FrameLayout) view.findViewById(frameLayoutIds.					//naechstes FrameLayout in Vorwaerts-Richtung
    					get(framePositionInList+1));
    		}
    		else{
    			flNew = (FrameLayout) view.findViewById(frameLayoutIds.					//naechstes FrameLayout in Rueckwaerts-Richtung
    					get(framePositionInList-1));
    		}
    		
    		if(flNew.getChildCount() != 0){
    			moveView(flNew);														//wenn flNew nicht leer ist, dessen FrameLayout-Button auch verschieben
    		}
    		
    		fl.removeAllViews();														//Alle Views aus altem Parent-FrameLayout loeschen
    		flNew.addView(flButton);													//FrameLayout-Button in neues Parent-FrameLayout seten
    	}
    }
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode verschiebt die Buttons zurueck an ihre urspruengliche Position, die in
	//den Lists buttonIdsMove und frameIdsMove gespeichert ist.
	////////////////////////////////////////////////////////////////////////////////////
	private void reset() {
		if(!frameIdsMoved.isEmpty() && !buttonIdsMoved.isEmpty()){	
			int i = 0;
			while(i < buttonIdsMoved.size() && i < frameIdsMoved.size()){				//Durchlaufen der beiden Lists
				if(buttonIdsMoved.get(i) != flButton.getId()){							//Wenn ID nicht ID des aktuell im Drag-Event befindlichen FrameLayout-Buttons ist
					FrameLayout flButton = (FrameLayout)view.
							findViewById(buttonIdsMoved.get(i));
					FrameLayout f = (FrameLayout)view.findViewById(frameIdsMoved.get(i));
					if(flButton.getParent() != null){
						FrameLayout fr = (FrameLayout)flButton.getParent();	
						if(fr.getChildCount()==2)
							fr.removeViewAt(1);											//Zweiten View aus altem Parent-FrameLayout loeschen (wichtig wenn das Drag-Event ohne Drop endet)
						else
							fr.removeAllViews();										//Alle Views aus altem Parent-FrameLayout loeschen
					}
					f.addView(flButton);												//FrameLayout-Button in neues Parent-FrameLayout setzen
				}
	    		i++;
			}
			buttonIdsMoved.clear();														//Lists loeschen
			frameIdsMoved.clear();
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Diese Methode klappt eine der vier Seiten (Alle Anwendungen, Erste Seite, 
	//Zweite Seite, Dritte Seite) auf.
	////////////////////////////////////////////////////////////////////////////////////
	private void setCurrentPage(View v){
		LinearLayout.LayoutParams paramsAll = new LinearLayout.LayoutParams			
				(LayoutParams.MATCH_PARENT, 0, LL_WEIGHT_CLOSED);						//Params mit Layout-Weight 1 
		LinearLayout.LayoutParams paramsClicked = new LinearLayout.LayoutParams
				(LayoutParams.MATCH_PARENT, 0, LL_WEIGHT_OPEN);							//Params mit Layout-Weigth 10
		
		LinearLayout wrapper = (LinearLayout)view.findViewById(R.id.wrapper);
		
		for(int i=0; i<wrapper.getChildCount(); i++){
			LinearLayout ll = (LinearLayout)wrapper.getChildAt(i);
			if(v.getId() != ll.getId()){
				ll.setLayoutParams(paramsAll);											//Allen Seiten ausser der uebergebenen Seite paramsAll zuordnen
			}
			else{
				ll.setLayoutParams(paramsClicked);										//Übergebener Seite paramsClicked zuordnen
			}
		}
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Hier wird bei einem Klick auf einen der Reiter das entsprechende Feld aufgeklappt.
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public void onClick(View v) {
		if(v instanceof LinearLayout)
			setCurrentPage(v);   		
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Die onDrag-Methode ueberprueft, welche Aktion beim Drag-Vorgang gerade stattfindet 
	//und fuehrt den entsprechenden Code aus.
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean onDrag(View v, DragEvent event) {
		final int action = event.getAction();
		FrameLayout fr_parent = (FrameLayout) flButton.getParent();
		switch (action) {
		case DragEvent.ACTION_DRAG_STARTED:												//Wenn Drag-Event gestartet wurde
			if(fr_parent != null){
				flButton.setVisibility(View.INVISIBLE);									//gezogenen FrameLayout-Button unsichtbar machen
			}
			break;
		case DragEvent.ACTION_DRAG_ENTERED:												//Wenn das Drag-Element auf ein Element gezogen wurde, fuer das der onDrag-Listener gesetzt ist
			if(v instanceof LinearLayout){
				setCurrentPage(v);														//Wenn das Drag-Element auf einen der Reiter der Seiten gezogen wurde, diesen aufklappen
			}
			else{																		
				moveView((FrameLayout) v);												
			}
			break;
		case DragEvent.ACTION_DRAG_EXITED:												//Wenn das Drag-Element aus dem Bereich eines Elements getogen wurde, fuer das der onDrag-Listener gesetzt ist			
			reset();																	//FrameLayout-Buttons zuruecksetzen
			break;
		case DragEvent.ACTION_DROP:														//Wird aufgerufen, wenn das Drag-Event mit einem Drop beendet wurde
			flButton.setVisibility(View.VISIBLE);										//gezogener FrameLayout-Button wird wieder sichtbar gemacht
			if(fr_parent != null){
				fr_parent.removeViewAt(0);												//loeschen der Kind-Elemente des Parent-FrameLayouts des gezogenen FrameLayout-Buttons
			}
			if(v instanceof FrameLayout){												//Wenn der FrameLayout-Button auf ein FrameLayout gezogen wurde (also innerhalb einer der Seiten Erste Seite, Zweite Seite, Dritte Seite)
				
				FrameLayout fl = (FrameLayout) v;
				
				button.resizeButton(flButton, buttonSizeBig, textSizeBig);				//Buttongroesse und Textgroesse anpassen
					
				fl.addView(flButton);
			}
			else{																		//Wenn der Button auf einen der Reiter oder aud die Seite Alle Anwendungen gezogen wurde
				
				FrameLayout emptyFl = getFirstEmptyFrameLayout(v.getId());				//Erstes freies FrameLayout ermitteln
				
				if(emptyFl != null){
    				
					if(v.getId() == R.id.row1)											//Wenn LinearLayout = Alle Anwendungen
						button.resizeButton(flButton,buttonSizeSmall,textSizeSmall);	//Button- und Textgroesse anpassen
					else
						button.resizeButton(flButton, buttonSizeBig, textSizeBig);
    				
					emptyFl.addView(flButton);
				}							
			}
			
			break;
		case DragEvent.ACTION_DRAG_ENDED:												//Wird aufgerufen, wenn der Drag beendet wurde
			if(!event.getResult()){														//Wenn der Drag nicht erfolgreich war
				flButton.setVisibility(View.VISIBLE);									//		->gezogenen FrameLayout-Button wieder sichtbar machen		
				reset();																//		->FrameLayout-Buttons zuruecksetzen
			}
			buttonIdsMoved.clear();														//gespeicherte IDs loeschen
			frameIdsMoved.clear();	
			break;
		default:
			break;
		}
		return true;
	}
	
	////////////////////////////////////////////////////////////////////////////////////
	//Die onTouch-Methode started den Drag-Vorgang fuer den beruehrten View.
	////////////////////////////////////////////////////////////////////////////////////
	@Override
	public boolean onTouch(View v, MotionEvent event) {
		view.performClick();
		flButton = (FrameLayout) v;														//globale Variable setzen, damit in der onDrag-Methode auf diese zugegriffen werden kann 
		DragShadowBuilder shadow = new DragShadowBuilder(v);							//Erstellen des DragShadowBuilders
		v.startDrag(null, shadow, null, 0);												//Starten des Drags	
		return false;
	} 
}
